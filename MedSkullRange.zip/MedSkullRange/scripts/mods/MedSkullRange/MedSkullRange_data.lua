local mod = get_mod("MedSkullRange")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "enabled",
				type = "checkbox",
				default_value = true,
				tooltip = "enabled_desc",
			},
			{
				setting_id = "color_r",
				type = "numeric",
				default_value = 255,
				range = { 0, 255 },
				step_size_value = 5,
				tooltip = "color_r_desc",
			},
			{
				setting_id = "color_g",
				type = "numeric",
				default_value = 60,
				range = { 0, 255 },
				step_size_value = 5,
				tooltip = "color_g_desc",
			},
			{
				setting_id = "color_b",
				type = "numeric",
				default_value = 60,
				range = { 0, 255 },
				step_size_value = 5,
				tooltip = "color_b_desc",
			},
		},
	},
}
