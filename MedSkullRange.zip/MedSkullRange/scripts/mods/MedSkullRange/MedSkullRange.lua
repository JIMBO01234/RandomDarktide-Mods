local mod = get_mod("MedSkullRange")

local CompanionServoSkullSettings = require("scripts/settings/companion/companion_servo_skull_settings")
local PlayerUnitStatus            = require("scripts/utilities/attack/player_unit_status")
local SpecialRulesSettings        = require("scripts/settings/ability/special_rules_settings")
local special_rules               = SpecialRulesSettings.special_rules

mod._hooked = false

local function _marker_hook(self, marker)
	if not mod:get("enabled") then
		return
	end
	if not marker or marker.markers_aio_type ~= "player_assistance" then
		return
	end
	local unit = marker.unit
	if not unit or not ALIVE[unit] then
		return
	end
	local widget = marker.widget
	local col = widget and widget.style and widget.style.icon and widget.style.icon.color
	if not col then
		return
	end
	local local_player = Managers.player and Managers.player:local_player_safe(1)
	local player_unit = local_player and local_player.player_unit
	if not player_unit or not ALIVE[player_unit] then
		return
	end
	local te = ScriptUnit.has_extension(player_unit, "talent_system")
	if not te or not te:has_special_rule(special_rules.cryptic_servo_skull_inject_ally) then
		return
	end
	local ude = ScriptUnit.has_extension(unit, "unit_data_system")
	local cs = ude and ude:read_component("character_state")
	if not cs or not PlayerUnitStatus.requires_allied_interaction_help(cs) then
		return
	end
	local asi = ude:read_component("assisted_state_input")
	if asi and PlayerUnitStatus.is_assisted(asi) then
		return
	end
	local ppos = POSITION_LOOKUP[player_unit]
	local epos = POSITION_LOOKUP[unit]
	if not ppos or not epos then
		return
	end
	local max_d = CompanionServoSkullSettings.max_target_distance_range or 15
	if Vector3.distance(ppos, epos) <= max_d then
		return
	end
	col[1] = 255
	col[2] = mod:get("color_r") or 255
	col[3] = mod:get("color_g") or 60
	col[4] = mod:get("color_b") or 60
end

local function _try_hook()
	if mod._hooked then
		return
	end
	local markers_aio = get_mod("markers_aio")
	if markers_aio and markers_aio.update_player_assistance_markers then
		mod._hooked = true
		mod:hook_safe(markers_aio, "update_player_assistance_markers", _marker_hook)
	end
end

mod.on_all_mods_loaded = function()
	_try_hook()
end
