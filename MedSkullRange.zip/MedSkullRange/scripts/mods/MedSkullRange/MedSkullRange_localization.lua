return {
	mod_name = {
		en = "MedSkullRange",
		ru = "MedSkullRange",
	},
	mod_description = {
		en = "Recolors the 'Markers Improved All-in-One' downed-ally marker icon while they are farther than the Medicae servo-skull's actual target-lock range. Requires the Markers Improved All-in-One mod and the Skitarii's Medicae servo-skull talent to do anything.",
		ru = "Перекрашивает значок упавшего союзника из мода 'Markers Improved All-in-One', пока он дальше реальной дистанции захвата цели Медикэ-сервочерепа. Требует мод Markers Improved All-in-One и талант Медикэ-сервочерепа Скитария — иначе ничего не делает.",
	},
	enabled = {
		en = "Enabled",
		ru = "Включено",
	},
	enabled_desc = {
		en = "While an ally still needs help, nobody is already assisting them, and you're farther than the Medicae skull's reach, Markers AIO's downed-ally icon is recoloured to the RGB below instead of its own colour. The moment someone starts helping them, or you get close enough, Markers AIO's own colour takes back over. Does nothing without Markers Improved All-in-One installed, and does nothing without the Medicae talent equipped (no skull, no 'range' to check against).",
		ru = "Пока союзнику всё ещё нужна помощь, никто ему ещё не помогает, а вы дальше дистанции захвата цели Медикэ-черепа — значок упавшего союзника из Markers AIO перекрашивается в RGB ниже вместо своего цвета. Как только кто-то начинает помогать или вы подходите достаточно близко, снова берёт верх собственный цвет Markers AIO. Без установленного Markers Improved All-in-One не делает ничего, и без надетого таланта Медикэ тоже не делает ничего (нет черепа — нет и понятия «дистанция»).",
	},
	color_r = {
		en = "Out-of-range colour: R",
		ru = "Цвет вне радиуса: R",
	},
	color_r_desc = {
		en = "Red channel (0-255) of the out-of-range icon colour. Default 255, 60, 60 is a plain red.",
		ru = "Красный канал (0-255) цвета значка вне радиуса. По умолчанию 255, 60, 60 — обычный красный.",
	},
	color_g = {
		en = "Out-of-range colour: G",
		ru = "Цвет вне радиуса: G",
	},
	color_g_desc = {
		en = "Green channel (0-255) of the out-of-range icon colour.",
		ru = "Зелёный канал (0-255) цвета значка вне радиуса.",
	},
	color_b = {
		en = "Out-of-range colour: B",
		ru = "Синий канал (0-255) цвета значка вне радиуса.",
	},
	color_b_desc = {
		en = "Blue channel (0-255) of the out-of-range icon colour.",
		ru = "Синий канал (0-255) цвета значка вне радиуса.",
	},
}
