return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`MedSkullRange` encountered an error loading the Darktide Mod Framework.")

		new_mod("MedSkullRange", {
			mod_script       = "MedSkullRange/scripts/mods/MedSkullRange/MedSkullRange",
			mod_data         = "MedSkullRange/scripts/mods/MedSkullRange/MedSkullRange_data",
			mod_localization = "MedSkullRange/scripts/mods/MedSkullRange/MedSkullRange_localization",
		})
	end,
	packages = {},
	version = "1.0.0",
}
