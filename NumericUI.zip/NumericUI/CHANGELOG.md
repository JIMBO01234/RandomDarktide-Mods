# NumericUI Changelog

## 26.10.05

Added an `Ammo text colour` setting to change the colour and opacity of the max ammo text.
NumericUI now requires an up-to-date Darktide Mod Framework.
Fixed `Ability text font size` only taking effect after reloading mods or restarting the game.
Fixed the `Ability cooldown format` and `Blitz cooldown format` timers jumping back up when a temporary recharge speed boost ends, such as Redline Capacitors or leaving a Stimm Field.
Fixed the `Ability cooldown format` timer showing a large, rising number during the Skitarius' Precision Stance. It now stays blank while the stance is active.
Fixed the teammate ability cooldown progress bar and counter being off when a teammate's ability cost is changed, for example by Seer's Presence.
Changed the German names of the max ammo settings.
Added a "Percent for Skitarii, timer for others" choice to `Ability cooldown format`. It shows your combat ability recharge as a percentage when you play Skitarii and as a countdown timer on every other class.

## 26.09.29.1

Fixed `Ability cooldown format` showing nothing while the second charge of Fury of the Faithful, or of any other ability with more than one charge, recharges.
Changed the teammate ability cooldown progress bar to split into one segment per ability charge, so you can see how many charges a teammate has left and how far the next one has recharged.
Changed the teammate ability cooldown counter to also count down to a teammate's next charge while they still have one left, shown dimmed until they have none.

## 26.09.29

Fixed a crash after the Darktide 1.13.0 update when your combat ability went on cooldown.
Fixed the teammate ability cooldown counter and progress bar, the "timer" option of `Ability cooldown format`, and `Blitz cooldown format` not working after the Darktide 1.13.0 update.
Fixed `Show amount of ammo and grenades gained` not showing picked-up grenades after the Darktide 1.13.0 update.
Fixed an error when placing a medical crate after the Darktide 1.13.0 update, which stopped `Show medical crate radius` from drawing the radius correctly.
Changed teammate ability cooldown timers to count down faster while something speeds up their ability recharge. They still reach zero exactly when the ability is ready.
Changed the teammate ability cooldown bar to show empty while a teammate's cooldown is paused, as the game's own ability icon does.

## 26.08.26

Cut the amount of work NumericUI does every frame. It previously re-derived your ammo, dodge count, ability cooldown, teammate ammo and boss health from scratch on every rendered frame, repeating work the game had already done. Ammo readouts now update from the game's own ammo events, the ammo pickup preview is worked out when you look at a new pickup instead of continuously, Havoc's reduced ammo pickup capacity is read once per mission instead of being re-parsed every frame, ability cooldowns come from the game's ability system rather than NumericUI's own bookkeeping, and the mission timer, dodge count and boss numbers only rebuild their text when the number on screen actually changes. Teammate ammo numbers now refresh ten times a second rather than every frame; everything else updates exactly as immediately as before. Measured over two full missions, NumericUI's own HUD work dropped from 39.4 to 14.2 microseconds per frame, a 64% reduction, with the ammo readout down 92% per call and the ammo pickup preview down 89%.
Fixed the teammate ability cooldown bar and timer being wrong for anyone who was already on cooldown when you joined. NumericUI guessed the full cooldown length from the first value it happened to see, so a player joining part-way through a cooldown got a bar that filled at the wrong rate. It now reads the real cooldown length from the game.
Fixed an error when a teammate panel was removed while the ability cooldown bar was enabled.
Fixed the max ammo text, the ammo icon and the floating "+N" ammo pickup numbers being shared between your weapon slots instead of tracked per weapon. This could place the ammo icon using another weapon's clip size, or show an ammo pickup on the wrong slot.
Fixed the ammo pickup preview permanently overwriting the game's own pickup data with Havoc's reduced ammo capacity, which left it applied to every ammo pickup for the rest of the session.
Completed the translations. Every mod setting is now localized into all 12 languages Darktide supports, filling in the German, Italian, Spanish, Polish, Brazilian Portuguese, Japanese and Korean entries that were missing entirely along with the remaining Russian, French and Chinese gaps.
Fixed severe frame rate drops while dragging the sliders in the mod settings. Changing any setting rebuilt every HUD element from scratch, and a slider commits a new value on every frame of a drag, so a single drag could rebuild the whole HUD hundreds of times. The dodge count and reset timer position and size settings are now applied straight to the existing widgets without any rebuild, and the rebuild that other settings still need waits until you stop changing them.
Added an optional numeric recharge timer to the Blitz HUD, for Blitzes that regenerate their charges over time, such as the Skitarii Integrated Refraction Emitter, the Ogryn Big Friendly Rock, Assail, and grenades replenished by Demolition Stockpile or Lone Wolf. While you are below your maximum number of charges it shows the time until the next charge arrives, restarts for the following charge as each one lands, and disappears once you are back at full. The remaining time is read from the game's own state rather than from hardcoded durations, so talents, buffs and future balance changes are reflected automatically, and effects that instantly hand you a charge are picked up straight away. Blitzes that recharge through the ability itself and Blitzes that recharge through a talent are both covered, even though the game tracks the two in completely different places. It is off by default; the new `Blitz Cooldown HUD` settings turn it on as either a countdown or a percentage, set its font size, move it horizontally and vertically, and can hide the vanilla background gradient behind it. It is placed to the left of the Blitz icon by default so it does not sit on top of the icon or run into the charge counter.
Added `Horizontal offset` and `Vertical offset` settings to the Dodge Count HUD, so the dodge count number can be repositioned to follow the reset timer bar instead of staying in the middle of the screen. Both default to `0`, which keeps the number exactly where it was before. The debug dodge info readout follows the same offsets and stays below the count.
Added a `Horizontal offset` setting to the Dodge Count Reset Timer HUD, so the timer bar can now be moved sideways as well as up and down. It defaults to `0`, which keeps the bar exactly where it was before. This is mainly useful on ultrawide resolutions, where the bar sat too far towards the middle of the screen with no way to move it back next to the rest of the HUD.
Widened the range of the Dodge Count Reset Timer offsets and made them adjustable in steps of one, so the bar can be placed anywhere on screen instead of being limited to a small vertical nudge.
Separated the Dodge Count Reset Timer from the dodge count itself. The timer bar previously only appeared while `Show dodge count` was also enabled; each can now be turned on without the other, and the timer is no longer calculated at all while it is hidden.

## 0.0.0

Empty changelog.
