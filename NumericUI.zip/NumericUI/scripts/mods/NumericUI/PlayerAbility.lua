local mod = get_mod("NumericUI")
local HudElementPlayerAbilitySettings =
	require("scripts/ui/hud/elements/player_ability/hud_element_player_ability_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")

local math_clamp = math.clamp
local math_floor = math.floor
local string_format = string.format
local table_clone = table.clone

local ABILITY_COOLDOWN_FONT_SIZE_DEFAULT = 30

local style = table_clone(UIFontSettings.hud_body)
style.text_horizontal_alignment = "center"
style.text_vertical_alignment = "center"

style.font_size = mod:get("ability_cooldown_font_size") or ABILITY_COOLDOWN_FONT_SIZE_DEFAULT

-- selene: allow(global_usage)
mod:hook(_G, "dofile", function(func, path)
	local instance = func(path)
	if path == "scripts/ui/hud/elements/player_ability/hud_element_player_ability_vertical_definitions" then
		instance.scenegraph_definition.cooldown = {
			parent = "slot",
			vertical_alignment = "center",
			horizontal_alignment = "center",
			size = HudElementPlayerAbilitySettings.ability_size,
			position = {
				0,
				0,
				10,
			},
		}
		instance.widget_definitions.cooldown_timer = UIWidget.create_definition({
			{
				value_id = "text",
				style_id = "text",
				pass_type = "text",
				style = style,
			},
		}, "cooldown")
	end
	return instance
end)

local function _player_extension(self, system_name)
	local parent = self._parent
	local player = self._data and self._data.player

	if not parent or not player then
		return
	end

	return parent:get_player_extension(player, system_name)
end

local function _remaining_cooldown(self)
	local ability_extension = _player_extension(self, "ability_system")

	if not ability_extension then
		return
	end

	local buff_extension = _player_extension(self, "buff_system")

	return mod.ability_charge_time_remaining(ability_extension, buff_extension, self._ability_type)
end

-- regen progress of the next charge, or nil while regen is paused
local function _recharging_charge_progress(self)
	local ability_extension = _player_extension(self, "ability_system")
	local regen_progress_func = ability_extension and ability_extension.get_ability_resource_regen_progress
	local ability_type = self._ability_type

	if not regen_progress_func or ability_extension:is_ability_resource_regen_paused(ability_type) then
		return
	end

	return regen_progress_func(ability_extension, ability_type)
end

-- Skitarii's archetype name is "cryptic"
local function _is_cryptic_player(self)
	local player = self._data and self._data.player
	if not player then
		return false
	end
	local ok, profile = pcall(player.profile, player)
	local archetype = ok and profile and profile.archetype
	return archetype and (archetype.name == "cryptic" or archetype.breed == "cryptic") or false
end

local function _ability_type_of(self)
	local data = self._data
	return self._ability_type or self._ability_id or (data and (data.ability_type or data.ability_id))
end

-- cached per HUD element: true only for the local Skitarii's combat ability
local function _is_skitarii_combat_ability(self)
	local cached = self._numericui_is_skitarii_combat
	if cached == nil then
		local ability_type = _ability_type_of(self)
		cached = type(ability_type) == "string"
			and ability_type:find("combat_ability", 1, true) ~= nil
			and _is_cryptic_player(self)
		self._numericui_is_skitarii_combat = cached
	end
	return cached
end

-- Progress (0-1) towards the next combat ability charge, read straight from the ability system.
-- Returns nil when no charge is regenerating (all charges full).
local function _skitarii_charge_progress(self)
	local ability_extension = _player_extension(self, "ability_system")
	local ability_type = _ability_type_of(self)

	if not ability_extension or not ability_type then
		return
	end

	-- Darktide 1.13.0+: abilities regenerate as a resource
	local missing_func = ability_extension.missing_ability_resource_until_next_charge
	local progress_func = ability_extension.get_ability_resource_regen_progress

	if missing_func and progress_func then
		local ok_missing, missing = pcall(missing_func, ability_extension, ability_type)
		if not ok_missing or not missing or missing <= 0 then
			return
		end

		local ok_progress, progress = pcall(progress_func, ability_extension, ability_type)
		if ok_progress and progress then
			return math_clamp(progress, 0, 1)
		end
	end

	-- older game versions: fall back to the vanilla HUD's own progress
	local progress = self._ability_progress
	if self._on_cooldown and progress and progress < 1 then
		return progress
	end
end

local function _update_skitarii_percent_text(self, text_widget)
	local content = text_widget.content
	local progress = _skitarii_charge_progress(self)
	local new_text

	if not progress or progress >= 1 then
		content._numericui_last_value = nil
		new_text = " "
	else
		local percent = math_floor(progress * 100)
		if content._numericui_last_value ~= percent then
			content._numericui_last_value = percent
			new_text = string_format("%d%%", percent)
		end
	end

	if new_text and content.text ~= new_text then
		content.text = new_text
		text_widget.dirty = true
	end
end

local function _update_cooldown_text(self)
	local text_widget = self._widgets_by_name.cooldown_timer

	if not text_widget then
		return
	end

	-- the definition above reads the font size only when this file loads, so a changed setting is applied to the
	-- live widget here
	local font_size = mod.setting("ability_cooldown_font_size") or ABILITY_COOLDOWN_FONT_SIZE_DEFAULT
	local text_style = text_widget.style.text

	if text_style._numericui_font_size ~= font_size then
		text_style._numericui_font_size = font_size
		text_style.font_size = font_size
		text_widget.dirty = true
	end

	if mod.setting("ability_cooldown_format") == "skitarii_percent" and _is_skitarii_combat_ability(self) then
		_update_skitarii_percent_text(self, text_widget)

		return
	end

	local content = text_widget.content
	local progress = self._ability_progress
	local on_cooldown = self._on_cooldown
	-- new_text stays nil while the displayed value is unchanged, so the
	-- retained widget is only re-rendered when the text actually changes
	local new_text

	-- since Darktide 1.13.0 vanilla reports a multi-charge ability as ready while it has a
	-- charge left, so read the progress of the recharging charge from the ability itself
	if not on_cooldown and self._has_more_than_one_charge and self._has_charges_left then
		progress = _recharging_charge_progress(self)
		on_cooldown = progress ~= nil
	end

	if not on_cooldown or not progress or progress >= 1 then
		content._numericui_last_value = nil
		new_text = " "
	else
		local ability_cooldown_format = mod.setting("ability_cooldown_format")

		if ability_cooldown_format == "skitarii_percent" then
			ability_cooldown_format = "time"
		end

		if ability_cooldown_format == "percent" then
			local percent = math_floor(progress * 100)
			if content._numericui_last_value ~= percent then
				content._numericui_last_value = percent
				new_text = string_format("%d%%", percent)
			end
		elseif ability_cooldown_format == "time" then
			local time_remaining = _remaining_cooldown(self)

			if not time_remaining then
				content._numericui_last_value = nil
				new_text = " "
			elseif time_remaining <= 1 then
				content._numericui_last_value = nil
				new_text = string_format("%.1f", time_remaining)
			else
				local seconds = math_floor(time_remaining)
				if content._numericui_last_value ~= seconds then
					content._numericui_last_value = seconds
					new_text = string_format("%d", seconds)
				end
			end
		else
			content._numericui_last_value = nil
			new_text = " "
		end
	end

	if new_text and content.text ~= new_text then
		content.text = new_text
		text_widget.dirty = true
	end
end

mod:hook_safe("HudElementPlayerAbility", "_set_progress", function(self)
	local progress = self._ability_progress

	if mod.setting("disable_ability_background_progress") and progress < 1.0 then
		self._widgets_by_name.ability.content.duration_progress = 0.0
	end

	_update_cooldown_text(self)
end)

mod:hook_safe("HudElementPlayerAbility", "_set_widget_state_colors", function(self)
	_update_cooldown_text(self)
end)

mod:hook_safe("HudElementPlayerAbility", "update", function(self)
	if mod.setting("ability_cooldown_format") ~= "skitarii_percent" or not _is_skitarii_combat_ability(self) then
		return
	end

	local text_widget = self._widgets_by_name and self._widgets_by_name.cooldown_timer

	if text_widget then
		_update_skitarii_percent_text(self, text_widget)
	end
end)
