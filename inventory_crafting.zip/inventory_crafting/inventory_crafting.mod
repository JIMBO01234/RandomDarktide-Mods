return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`inventory_crafting` encountered an error loading the Darktide Mod Framework.")

		new_mod("inventory_crafting", {
			mod_script       = "inventory_crafting/scripts/mods/inventory_crafting/inventory_crafting",
			mod_data         = "inventory_crafting/scripts/mods/inventory_crafting/inventory_crafting_data",
			mod_localization = "inventory_crafting/scripts/mods/inventory_crafting/inventory_crafting_localization",
		})
	end,
	packages = {},
}
