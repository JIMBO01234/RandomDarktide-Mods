local mod = get_mod("inventory_crafting")

local CraftingMechanicusSettings = require("scripts/settings/item/crafting_mechanicus_settings")
local PlayerProgressionUnlocks = require("scripts/settings/player/player_progression_unlocks")
local ViewElementGrid = require("scripts/ui/view_elements/view_element_grid/view_element_grid")
local QuickMastery = mod:io_dofile("inventory_crafting/scripts/mods/inventory_crafting/inventory_crafting_mastery")

local recipes = CraftingMechanicusSettings.recipes
local RECIPE_BUTTONS = {
	{
		setting_id = "show_upgrade_item",
		recipe = recipes.upgrade_item,
		curios = true,
	},
	{
		setting_id = "show_upgrade_expertise",
		recipe = recipes.upgrade_expertise,
	},
	{
		setting_id = "show_replace_trait",
		recipe = recipes.replace_trait,
	},
	{
		setting_id = "show_replace_perk",
		recipe = recipes.replace_perk,
		curios = true,
	},
}
local HUB_GAME_MODES = {
	hub = true,
	hub_singleplay = true,
}
-- Row height used by InventoryWeaponsView._setup_weapon_options.
local ROW_PADDING = 20

local crafting_available = function ()
	local game_mode_manager = Managers.state and Managers.state.game_mode

	if not HUB_GAME_MODES[game_mode_manager and game_mode_manager:game_mode_name()] then
		return false
	end

	local mission_board = Managers.data_service and Managers.data_service.mission_board

	if mission_board and mission_board.get_block_reason then
		local has_progression = not mission_board.has_cached_progression_data or mission_board:has_cached_progression_data() ~= false

		if has_progression and mission_board:get_block_reason("hub_facility", PlayerProgressionUnlocks.crafting) then
			return false
		end
	end

	return true
end

local open_recipe = function (view, recipe)
	local item = view._previewed_item

	if not item or Managers.ui:view_active("crafting_view") then
		return
	end

	Managers.ui:open_view("crafting_view", nil, nil, nil, nil, {
		inventory_crafting = {
			view_name = recipe.view_name,
			item = item,
		},
	})
end

local button_entry = function (display_name, on_pressed)
	return {
		display_icon = "",
		widget_type = "button",
		display_name = display_name,
		callback = on_pressed,
	}
end

local extra_buttons = function (view, for_curios)
	local entries = {}

	if not view._is_own_player or not crafting_available() then
		return entries
	end

	for i = 1, #RECIPE_BUTTONS do
		local button = RECIPE_BUTTONS[i]
		local recipe = button.recipe

		if recipe and (button.curios or not for_curios) and mod:get(button.setting_id) ~= false then
			entries[#entries + 1] = button_entry(Localize(recipe.display_name), function ()
				open_recipe(view, recipe)
			end)
		end
	end

	if not for_curios and mod:get("show_quick_mastery") ~= false then
		entries[#entries + 1] = button_entry(mod:localize("button_quick_mastery"), function ()
			QuickMastery.request(view._previewed_item)
		end)
	end

	return entries
end

-- The game only builds the options panel for weapons. Curios get the same panel with their recipes.
local setup_curio_options = function (view)
	local entries = extra_buttons(view, true)

	if #entries == 0 then
		return
	end

	local definitions = view._definitions
	local button_size = definitions.blueprints.button.size
	local top_padding = 30
	local grid_size = {
		button_size[1],
		(button_size[2] + ROW_PADDING) * #entries + top_padding,
	}
	local grid = view:_add_element(ViewElementGrid, "weapon_options", 10, {
		edge_padding = 40,
		scrollbar_width = 7,
		title_height = 0,
		use_is_focused_for_navigation = false,
		use_select_on_focused = true,
		use_terminal_background = true,
		grid_spacing = {
			10,
			10,
		},
		grid_size = grid_size,
		mask_size = {
			grid_size[1] + 40,
			grid_size[2] + 40,
		},
		top_padding = top_padding,
	})

	grid:update_dividers("content/ui/materials/frames/marks_top", {
		413.28,
		58.8,
	}, {
		0,
		-20,
		20,
	})
	grid:present_grid_layout(entries, definitions.blueprints)
	grid:disable_input(true)
	grid:set_visibility(false)

	view._weapon_options_element = grid

	if view._weapon_stats then
		view:_update_weapon_stats_position("weapon_stats_pivot", view._weapon_stats)
	end
end

-- Grow the options grid and append to whatever layout the game builds, instead of copying it.
mod:hook("InventoryWeaponsView", "_setup_weapon_options", function (func, self)
	if self.item_type == "GADGET" then
		func(self)

		if not self._weapon_options_element then
			setup_curio_options(self)
		end

		return
	end

	local entries = extra_buttons(self)

	if #entries == 0 then
		return func(self)
	end

	local extra_height = (self._definitions.blueprints.button.size[2] + ROW_PADDING) * #entries
	local add_element = self._add_element
	local options_grid

	self._add_element = function (view, class, name, layer, context, ...)
		if name == "weapon_options" and context and context.grid_size then
			context.grid_size[2] = context.grid_size[2] + extra_height

			if context.mask_size then
				context.mask_size[2] = context.mask_size[2] + extra_height
			end
		end

		local element = add_element(view, class, name, layer, context, ...)

		if name == "weapon_options" and element then
			local present_grid_layout = element.present_grid_layout

			options_grid = element
			element.present_grid_layout = function (grid, layout, ...)
				local merged = table.clone(layout)

				table.append(merged, entries)

				return present_grid_layout(grid, merged, ...)
			end
		end

		return element
	end

	local ok, err = pcall(func, self)

	self._add_element = nil

	if options_grid then
		options_grid.present_grid_layout = nil
	end

	if not ok then
		error(err)
	end
end)

-- InventoryWeaponsView only shows the options panel for weapon slots.
mod:hook_safe("InventoryWeaponsView", "_preview_item", function (self, item)
	local grid = self._weapon_options_element

	if grid and item and item.item_type == "GADGET" and not self._discard_items_element and not self._item_compare_toggled then
		grid:set_visibility(true)
	end
end)

mod:hook_safe("CraftingView", "init", function (self, settings, context)
	self._inventory_crafting = context and context.inventory_crafting
end)

-- Skip Hadron's menu and open the recipe for the chosen weapon directly.
mod:hook_safe("CraftingView", "on_enter", function (self)
	local data = self._inventory_crafting

	if data then
		self:on_option_button_pressed(nil, {
			callback = function (crafting_view)
				crafting_view:go_to_crafting_view(data.view_name, data.item)
			end,
		})
	end
end)

-- Recipe views go back to Hadron's weapon list. When opened from the inventory, close Hadron
-- instead. The recipe view draws with Hadron's renderer, so it has to close first; Hadron is
-- closed from the update hook once it is gone.
mod:hook("CraftingView", "go_to_crafting_view", function (func, self, view_name, item)
	if not self._inventory_crafting or view_name ~= "select_item_mechanicus" then
		return func(self, view_name, item)
	end

	if not self._inventory_crafting_closing then
		self._inventory_crafting_closing = {
			recipe_view = self._active_view,
		}

		self:_close_active_view()
	end
end)

mod:hook_safe("CraftingView", "update", function (self)
	local closing = self._inventory_crafting_closing

	if not closing or closing.done then
		return
	end

	if closing.recipe_view and Managers.ui:view_active(closing.recipe_view) then
		return
	end

	closing.done = true

	Managers.ui:close_view(self.view_name)
end)

-- Refresh the crafted weapon in the inventory list.
mod:hook("CraftingView", "craft", function (func, self, ...)
	local promise = func(self, ...)

	promise:next(function (result)
		local items = result and result.items or {}

		for i = 1, #items do
			Managers.event:trigger("event_replace_list_item", items[i])
		end
	end):catch(function ()
		return
	end)

	return promise
end)
