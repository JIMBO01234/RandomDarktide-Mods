local mod = get_mod("inventory_crafting")

local checkbox = function (setting_id, default_value)
	return {
		setting_id = setting_id,
		type = "checkbox",
		default_value = default_value,
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			checkbox("show_upgrade_item", true),
			checkbox("show_upgrade_expertise", true),
			checkbox("show_replace_trait", true),
			checkbox("show_replace_perk", true),
			checkbox("show_quick_mastery", true),
			checkbox("mastery_until_max", false),
		},
	},
}
