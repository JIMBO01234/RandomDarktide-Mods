return {
	mod_name = {
		en = "Inventory Crafting",
	},
	mod_description = {
		en = "Hadron's crafting options for weapons and curios, and a quick mastery button, right in the inventory. Mourningstar only.",
	},
	show_upgrade_item = {
		en = "Upgrade button",
	},
	show_upgrade_item_description = {
		en = "Weapons and curios.",
	},
	show_upgrade_expertise = {
		en = "Expertise button",
	},
	show_replace_trait = {
		en = "Replace Blessing button",
	},
	show_replace_perk = {
		en = "Replace Perk button",
	},
	show_replace_perk_description = {
		en = "Weapons and curios.",
	},
	show_quick_mastery = {
		en = "Quick Mastery button",
	},
	show_quick_mastery_description = {
		en = "Buys the weapon from Brunt's Armoury, upgrades it to green and sacrifices that copy. Your own weapon is never sacrificed.",
	},
	mastery_until_max = {
		en = "Quick Mastery: keep going until max",
	},
	mastery_until_max_description = {
		en = "Repeats until mastery 20, you run out of resources, or you press the button again. Spends all mastery points on blessings afterwards. Shows the expected cost and asks before starting.",
	},
	button_quick_mastery = {
		en = "Quick Mastery",
	},

	busy = {
		en = "Quick Mastery is already running.",
	},
	stopping = {
		en = "Stopping after this sacrifice.",
	},
	run_started = {
		en = "Sacrificing until max mastery. Press Quick Mastery again to stop.",
	},
	sacrificed_one = {
		en = "+%d mastery XP (level %d/%d)",
	},
	level_reached = {
		en = "Mastery level %d/%d",
	},
	run_finished = {
		en = "Max mastery reached. %d sacrifices, +%d XP (level %d/%d)",
	},
	run_stopped = {
		en = "Stopped after %d sacrifices, +%d XP (level %d/%d)",
	},
	already_max = {
		en = "Mastery is already maxed.",
	},
	points_spent = {
		en = "Unlocked %d blessing tiers with mastery points.",
	},
	copy_kept = {
		en = "The bought copy is still in your inventory.",
	},

	error_no_mastery = {
		en = "This weapon has no mastery.",
	},
	error_max_level = {
		en = "Mastery is already maxed.",
	},
	error_no_offer = {
		en = "Brunt's Armoury doesn't sell this weapon to this character.",
	},
	error_purchase_cost = {
		en = "Not enough to buy another copy.",
	},
	error_purchase = {
		en = "Couldn't buy a copy from Brunt's Armoury.",
	},
	error_upgrade_cost = {
		en = "Not enough materials to upgrade the copy.",
	},
	error_upgrade = {
		en = "Couldn't upgrade the copy.",
	},
	error_sacrifice = {
		en = "The sacrifice gave no mastery XP.",
	},
	error_points = {
		en = "Couldn't spend mastery points. Use the Masteries menu instead.",
	},

	error_estimate = {
		en = "Couldn't work out the cost.",
	},

	confirm_title = {
		en = "Sacrifice until max mastery?",
	},
	confirm_progress = {
		en = "Mastery level %d/%d, %s XP left.",
	},
	confirm_copies = {
		en = "About %d sacrifices (%s XP each).",
	},
	confirm_copies_worst_case = {
		en = "Up to %d sacrifices (at least %s XP each).",
	},
	confirm_total_cost = {
		en = "Expected cost:",
	},
	confirm_affordable = {
		en = "You can afford %d right now. It stops when you run out.",
	},
	confirm_points = {
		en = "Mastery points are spent on blessings when it's done.",
	},
	confirm_worst_case = {
		en = "This is a worst case until your first sacrifice. After that it uses real numbers.",
	},
	confirm_start = {
		en = "Start",
	},
	confirm_cancel = {
		en = "Cancel",
	},
}