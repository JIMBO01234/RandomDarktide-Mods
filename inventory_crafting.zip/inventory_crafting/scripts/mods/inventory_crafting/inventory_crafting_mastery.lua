local mod = get_mod("inventory_crafting")

local CraftingMechanicusSettings = require("scripts/settings/item/crafting_mechanicus_settings")
local MasterItems = require("scripts/backend/master_items")
local Mastery = require("scripts/utilities/mastery")
local Promise = require("scripts/foundation/utilities/promise")
local WalletSettings = require("scripts/settings/wallet_settings")

local upgrade_recipe = CraftingMechanicusSettings.recipes.upgrade_item
local CURRENCY_ORDER = {
	"credits",
	"plasteel",
	"diamantine",
}
local MIN_SACRIFICE_RARITY = 2
local MAX_SACRIFICES_PER_RUN = 100
local BRUNT_ITEM_RARITY = 1

local active_run

local notify = function (text, is_alert)
	if is_alert then
		Managers.event:trigger("event_add_notification_message", "alert", {
			text = text,
		})
	else
		Managers.event:trigger("event_add_notification_message", "default", text)
	end
end

local fail = function (loc_id)
	return Promise.rejected({
		message = mod:localize(loc_id),
	})
end

local error_text = function (err)
	if type(err) == "table" then
		return tostring(err.message or err.description or err.code)
	end

	return tostring(err)
end

local balance = function (wallets, wallet_type)
	local wallet = wallets:by_type(wallet_type)

	return wallet and wallet.balance and wallet.balance.amount or 0
end

local can_afford = function (wallets, costs)
	for i = 1, #costs do
		if balance(wallets, costs[i].type) < costs[i].amount then
			return false
		end
	end

	return true
end

local sacrifice_rarity = function ()
	local rules = Managers.data_service.crafting:get_sacrifice_mastery_costs()
	local minimum_rarity = rules and rules.minimumRarity

	return minimum_rarity and math.max(minimum_rarity + 1, MIN_SACRIFICE_RARITY) or MIN_SACRIFICE_RARITY
end

local mastery_level = function (mastery_data, added_xp)
	local xp = (mastery_data.current_xp or 0) + (added_xp or 0)

	return math.max(mastery_data.mastery_level or 0, Mastery.get_level_by_xp(mastery_data, xp) or 0)
end

local max_mastery_level = function (mastery_data)
	return mastery_data.mastery_max_level or (mastery_data.milestones and #mastery_data.milestones) or 0
end

local offer_price = function (offer)
	local price = offer.price.amount

	return price.discounted_price or price.amount, price.type
end

-- Brunt's Armoury sells every unlocked weapon. Prefer the same mark, any mark of the family will do.
local find_offer = function (selected_item)
	return Managers.data_service.store:get_credits_goods_store(true):next(function (store)
		local offers = store and store.offers or {}
		local family_offer

		for i = 1, #offers do
			local offer = offers[i]
			local loot_choices = offer.description and offer.description.lootChoices
			local master_item = loot_choices and MasterItems.get_item(loot_choices[1])
			local purchasable = offer.sku and offer.sku.category == "item_instance" and (offer.state == nil or offer.state == "active")

			if master_item and purchasable then
				if master_item.name == selected_item.name then
					return offer
				elseif not family_offer and master_item.parent_pattern == selected_item.parent_pattern then
					family_offer = offer
				end
			end
		end

		return family_offer
	end)
end

local upgrade_to_rarity
upgrade_to_rarity = function (item, rarity, spent)
	if (item.rarity or 0) >= rarity then
		return Promise.resolved(item)
	end

	if not upgrade_recipe.is_valid_item(item) then
		return fail("error_upgrade")
	end

	local costs = upgrade_recipe.get_costs({
		item = item,
	})

	return Managers.data_service.store:combined_wallets():next(function (wallets)
		if not can_afford(wallets, costs) then
			return fail("error_upgrade_cost")
		end

		return Managers.data_service.crafting:upgrade_weapon_rarity(item.gear_id, costs)
	end):next(function (result)
		local upgraded = result and result.items and result.items[1]

		if not upgraded or (upgraded.rarity or 0) <= (item.rarity or 0) then
			return fail("error_upgrade")
		end

		table.append(spent, costs)

		return upgrade_to_rarity(upgraded, rarity, spent)
	end)
end

local buy_and_sacrifice = function (run, mastery_data)
	local store_service = Managers.data_service.store
	local upgrade_costs = {}
	local offer

	return find_offer(run.item):next(function (found)
		if not found then
			return fail("error_no_offer")
		end

		offer = found

		return store_service:combined_wallets()
	end):next(function (wallets)
		local price, currency = offer_price(offer)

		if balance(wallets, currency) < price then
			return fail("error_purchase_cost")
		end

		return store_service:purchase_item(offer)
	end):next(function (result)
		local item_data = result and result.items and result.items[1]
		local item = item_data and MasterItems.get_item_instance(item_data, item_data.uuid)

		-- Only ever sacrifice the copy that was just bought.
		if not item or not item.gear_id or item.gear_id == run.item.gear_id then
			return fail("error_purchase")
		end

		run.bought_item = item

		return upgrade_to_rarity(item, sacrifice_rarity(), upgrade_costs)
	end):next(function (item)
		run.bought_item = item

		return Managers.data_service.crafting:extract_weapon_mastery(run.pattern, {
			item.gear_id,
		})
	end):next(function (result)
		local xp = result and result.amount or 0

		if xp <= 0 then
			return fail("error_sacrifice")
		end

		run.bought_item = nil

		-- Remembered so the cost estimate can use real numbers instead of worst-case ones.
		mod:set("last_sacrifice", {
			xp = xp,
			upgrade_costs = upgrade_costs,
		})

		local level = mastery_level(mastery_data, xp)

		return Managers.data_service.mastery:claim_levels_by_new_exp(mastery_data, xp):next(function ()
			return {
				xp = xp,
				level = level,
			}
		end)
	end)
end

local next_trait_rarity = function (trait_status)
	local highest_owned = 0

	for rarity = 1, #trait_status do
		if trait_status[rarity] == "seen" then
			highest_owned = rarity
		end
	end

	for rarity = highest_owned + 1, #trait_status do
		if trait_status[rarity] ~= "invalid" then
			return rarity
		end
	end
end

-- Same rules as MasteryView: a tier needs enough points and enough points already spent to unlock it.
local spend_mastery_points = function (pattern)
	local mastery_service = Managers.data_service.mastery

	return Managers.data_service.crafting:reset_sticker_book():next(function ()
		return mastery_service:get_mastery_by_pattern(pattern)
	end):next(function (mastery_data)
		if not mastery_data or not mastery_data.traits then
			return 0
		end

		-- The trait tables are shared with the sticker book cache.
		local traits = table.clone(mastery_data.traits)
		local points = Mastery.get_available_points(mastery_data, traits)
		local purchases = {}

		while true do
			local unlocked_rarity = Mastery.get_max_blessing_rarity_unlocked_level_by_points_spent(traits)
			local pick, pick_rarity, pick_cost

			for i = 1, #traits do
				local rarity = next_trait_rarity(traits[i].trait_status)
				local cost = rarity and Mastery.get_trait_cost(rarity)

				if cost and cost <= points and rarity <= unlocked_rarity and (not pick_cost or cost < pick_cost) then
					pick, pick_rarity, pick_cost = i, rarity, cost
				end
			end

			if not pick then
				break
			end

			traits[pick].trait_status[pick_rarity] = "seen"
			points = points - pick_cost
			purchases[#purchases + 1] = {
				trait_name = traits[pick].trait_name,
				rarity = pick_rarity,
				index = pick,
			}
		end

		if #purchases == 0 then
			return 0
		end

		return mastery_service:purchase_traits(pattern, purchases):next(function (failed)
			return #purchases - #(failed or {})
		end)
	end)
end

local run_step
run_step = function (run)
	if run.stop_requested then
		return Promise.resolved()
	end

	return Managers.data_service.mastery:get_mastery_by_pattern(run.pattern):next(function (mastery_data)
		if not mastery_data or table.is_empty(mastery_data) then
			return fail("error_no_mastery")
		end

		local level = mastery_level(mastery_data)

		run.level = level
		run.max_level = max_mastery_level(mastery_data)

		if level >= run.max_level then
			if not run.until_max then
				return fail("error_max_level")
			end

			run.reached_max = true

			return
		end

		return buy_and_sacrifice(run, mastery_data):next(function (sacrifice)
			local xp, new_level = sacrifice.xp, sacrifice.level

			run.count = run.count + 1
			run.total_xp = run.total_xp + xp
			run.level = new_level

			if not run.until_max then
				notify(mod:localize("sacrificed_one", xp, new_level, run.max_level))

				return
			end

			if new_level > level then
				notify(mod:localize("level_reached", new_level, run.max_level))
			end

			if run.count < MAX_SACRIFICES_PER_RUN then
				return run_step(run)
			end
		end)
	end)
end

local run_summary = function (run)
	if run.reached_max and run.count == 0 then
		return mod:localize("already_max")
	end

	local loc_id = run.reached_max and "run_finished" or "run_stopped"

	return mod:localize(loc_id, run.count, run.total_xp, run.level or 0, run.max_level or 0)
end

local start = function (item)
	local pattern = item and item.parent_pattern

	if not pattern then
		return
	end

	if active_run then
		if active_run.until_max and not active_run.stop_requested then
			active_run.stop_requested = true

			notify(mod:localize("stopping"))
		else
			notify(mod:localize("busy"))
		end

		return
	end

	local run = {
		item = item,
		pattern = pattern,
		until_max = mod:get("mastery_until_max") == true,
		count = 0,
		total_xp = 0,
	}

	active_run = run

	if run.until_max then
		notify(mod:localize("run_started"))
	end

	run_step(run):next(function ()
		if run.until_max then
			notify(run_summary(run))
		end
	end):catch(function (err)
		local message = type(err) == "table" and err.message

		if not message or type(message) ~= "string" then
			mod:error("Mastery sacrifice failed: %s", error_text(err))

			message = Localize("loc_popup_description_backend_error")
		end

		if run.bought_item then
			message = message .. "\n" .. mod:localize("copy_kept")
		end

		if run.until_max and run.count > 0 then
			message = message .. "\n" .. run_summary(run)
		end

		notify(message, true)
	end):next(function ()
		if not run.until_max then
			return
		end

		return spend_mastery_points(pattern):next(function (unlocked)
			if unlocked > 0 then
				notify(mod:localize("points_spent", unlocked))
			end
		end):catch(function (err)
			mod:error("Spending mastery points failed: %s", error_text(err))
			notify(mod:localize("error_points"), true)
		end)
	end):next(function ()
		active_run = nil
	end)
end

-- Per sacrifice: XP and upgrade costs from the last real sacrifice, otherwise the lowest XP and
-- highest upgrade cost the game's formulas allow for a fresh Brunt's weapon.
local per_sacrifice_estimate = function ()
	local last = mod:get("last_sacrifice")

	if type(last) == "table" and (last.xp or 0) > 0 then
		return last.xp, last.upgrade_costs or {}, true
	end

	local rules = Managers.data_service.crafting:get_sacrifice_mastery_costs() or {}
	local xp = ((rules.baseReward or 25) + (rules.masteryXpPerExpertiseLevel or 30)) * (rules.sacrifice_muiltiplier or 6)
	local upgrade_costs = {}

	for rarity = BRUNT_ITEM_RARITY, sacrifice_rarity() - 1 do
		table.append(upgrade_costs, upgrade_recipe.get_costs({
			item = {
				item_type = "WEAPON_MELEE",
				rarity = rarity,
			},
		}))
	end

	return xp, upgrade_costs, false
end

local estimate = function (item)
	local pattern = item and item.parent_pattern
	local store_service = Managers.data_service.store
	local result = {}

	if not pattern then
		return Promise.resolved(result)
	end

	return Managers.data_service.mastery:get_mastery_by_pattern(pattern):next(function (mastery_data)
		if not mastery_data or table.is_empty(mastery_data) then
			return Promise.rejected()
		end

		result.level = mastery_level(mastery_data)
		result.max_level = max_mastery_level(mastery_data)
		result.xp_needed = Mastery.get_xp_for_max_level(mastery_data)

		return find_offer(item)
	end):next(function (offer)
		if not offer then
			result.no_offer = true

			return Promise.rejected()
		end

		local xp, upgrade_costs, from_history = per_sacrifice_estimate()
		local price, currency = offer_price(offer)
		local per_copy = {
			[currency] = price,
		}

		for i = 1, #upgrade_costs do
			local cost = upgrade_costs[i]

			per_copy[cost.type] = (per_copy[cost.type] or 0) + cost.amount
		end

		result.xp_per_copy = xp
		result.per_copy = per_copy
		result.from_history = from_history
		result.copies = result.level < result.max_level and math.ceil(result.xp_needed / xp) or 0

		return store_service:combined_wallets()
	end):next(function (wallets)
		local affordable = math.huge

		for wallet_type, amount in pairs(result.per_copy) do
			if amount > 0 then
				affordable = math.min(affordable, math.floor(balance(wallets, wallet_type) / amount))
			end
		end

		result.affordable = affordable

		return result
	end):catch(function ()
		result.failed = true

		return result
	end)
end

local format_number = function (number)
	local grouped = tostring(math.floor(number + 0.5)):reverse():gsub("(%d%d%d)", "%1,"):reverse()

	return (grouped:gsub("^,", ""))
end

local cost_lines = function (per_copy, copies)
	local lines = {}
	local listed = {}

	local add = function (wallet_type)
		local amount = per_copy[wallet_type]

		if amount and amount > 0 and not listed[wallet_type] then
			local settings = WalletSettings[wallet_type]
			local name = settings and Localize(settings.display_name) or wallet_type

			lines[#lines + 1] = string.format("  %s %s", format_number(amount * copies), name)
			listed[wallet_type] = true
		end
	end

	for i = 1, #CURRENCY_ORDER do
		add(CURRENCY_ORDER[i])
	end

	for wallet_type in pairs(per_copy) do
		add(wallet_type)
	end

	return table.concat(lines, "\n")
end

local confirmation_text = function (estimate)
	local copies_id = estimate.from_history and "confirm_copies" or "confirm_copies_worst_case"
	local lines = {
		mod:localize("confirm_progress", estimate.level, estimate.max_level, format_number(estimate.xp_needed)),
		mod:localize(copies_id, estimate.copies, format_number(estimate.xp_per_copy)),
		"",
		mod:localize("confirm_total_cost"),
		cost_lines(estimate.per_copy, estimate.copies),
		"",
	}

	if estimate.affordable < estimate.copies then
		lines[#lines + 1] = mod:localize("confirm_affordable", estimate.affordable)
	end

	lines[#lines + 1] = mod:localize("confirm_points")

	if not estimate.from_history then
		lines[#lines + 1] = mod:localize("confirm_worst_case")
	end

	return table.concat(lines, "\n")
end

local estimating = false

local show_confirmation = function (item, estimate)
	Managers.event:trigger("event_show_ui_popup", {
		title_text_unlocalized = mod:localize("confirm_title"),
		description_text_unlocalized = confirmation_text(estimate),
		options = {
			{
				close_on_pressed = true,
				no_localization = true,
				text = mod:localize("confirm_start"),
				callback = function ()
					start(item)
				end,
			},
			{
				close_on_pressed = true,
				hotkey = "back",
				no_localization = true,
				template_type = "terminal_button_small",
				text = mod:localize("confirm_cancel"),
			},
		},
	})
end

-- Button entry point. A run until max asks for confirmation with the expected cost first.
local request = function (item)
	if not item or not item.parent_pattern then
		return
	end

	if active_run or mod:get("mastery_until_max") ~= true then
		return start(item)
	end

	if estimating then
		return
	end

	estimating = true

	estimate(item):next(function (result)
		estimating = false

		if result.level and result.max_level and result.level >= result.max_level then
			return start(item)
		end

		if result.no_offer then
			notify(mod:localize("error_no_offer"), true)
		elseif result.failed then
			notify(mod:localize("error_estimate"), true)
		else
			show_confirmation(item, result)
		end
	end)
end

return {
	request = request,
}
