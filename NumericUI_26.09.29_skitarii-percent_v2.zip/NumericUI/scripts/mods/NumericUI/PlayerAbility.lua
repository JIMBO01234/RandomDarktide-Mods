local mod = get_mod("NumericUI")
local HudElementPlayerAbilitySettings =
	require("scripts/ui/hud/elements/player_ability/hud_element_player_ability_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")

local math_clamp = math.clamp
local math_floor = math.floor
local string_format = string.format
local table_clone = table.clone

local style = table_clone(UIFontSettings.hud_body)
style.text_horizontal_alignment = "center"
style.text_vertical_alignment = "center"

style.font_size = mod:get("ability_cooldown_font_size")

-- selene: allow(global_usage)
mod:hook(_G, "dofile", function(func, path)
	local instance = func(path)
	if path == "scripts/ui/hud/elements/player_ability/hud_element_player_ability_vertical_definitions" then
		instance.scenegraph_definition.cooldown = {
			parent = "slot",
			vertical_alignment = "center",
			horizontal_alignment = "center",
			size = HudElementPlayerAbilitySettings.ability_size,
			position = {
				0,
				0,
				10,
			},
		}
		instance.widget_definitions.cooldown_timer = UIWidget.create_definition({
			{
				value_id = "text",
				style_id = "text",
				pass_type = "text",
				style = style,
			},
		}, "cooldown")
	end
	return instance
end)

-- Skitarii's archetype name is "cryptic"
local function _is_cryptic_player(self)
	local player = self._data and self._data.player
	if not player then
		return false
	end
	local ok, profile = pcall(player.profile, player)
	local archetype = ok and profile and profile.archetype
	return archetype and (archetype.name == "cryptic" or archetype.breed == "cryptic") or false
end

local function _ability_type_of(self)
	local data = self._data
	return self._ability_type or self._ability_id or (data and (data.ability_type or data.ability_id))
end

-- cached per HUD element: true only for the local Skitarii's combat ability
local function _is_skitarii_combat_ability(self)
	local cached = self._numericui_is_skitarii_combat
	if cached == nil then
		local ability_type = _ability_type_of(self)
		cached = type(ability_type) == "string"
			and ability_type:find("combat_ability", 1, true) ~= nil
			and _is_cryptic_player(self)
		self._numericui_is_skitarii_combat = cached
	end
	return cached
end

-- Progress (0-1) towards the next combat ability charge, read straight from the ability system.
-- Returns nil when no charge is regenerating (all charges full).
local function _skitarii_charge_progress(self)
	local parent = self._parent
	local player = self._data and self._data.player
	local ability_extension = parent and player and parent:get_player_extension(player, "ability_system")
	local ability_type = _ability_type_of(self)

	if not ability_extension or not ability_type then
		return
	end

	-- Darktide 1.13.0+: abilities regenerate as a resource
	local missing_func = ability_extension.missing_ability_resource_until_next_charge
	local progress_func = ability_extension.get_ability_resource_regen_progress

	if missing_func and progress_func then
		local ok_missing, missing = pcall(missing_func, ability_extension, ability_type)
		if not ok_missing or not missing or missing <= 0 then
			return
		end

		local ok_progress, progress = pcall(progress_func, ability_extension, ability_type)
		if ok_progress and progress then
			return math_clamp(progress, 0, 1)
		end
	end

	-- older game versions: fall back to the vanilla HUD's own progress
	local progress = self._ability_progress
	if self._on_cooldown and progress and progress < 1 then
		return progress
	end
end

local function _update_skitarii_percent_text(self, text_widget)
	local content = text_widget.content
	local progress = _skitarii_charge_progress(self)
	local new_text

	if not progress or progress >= 1 then
		content._numericui_last_value = nil
		new_text = " "
	else
		local percent = math_floor(progress * 100)
		if content._numericui_last_value ~= percent then
			content._numericui_last_value = percent
			new_text = string_format("%d%%", percent)
		end
	end

	if new_text and content.text ~= new_text then
		content.text = new_text
		text_widget.dirty = true
	end
end

local function _remaining_cooldown(self)
	local parent = self._parent
	local player = self._data and self._data.player

	if not parent or not player then
		return
	end

	local ability_extension = parent:get_player_extension(player, "ability_system")

	if not ability_extension then
		return
	end

	local buff_extension = parent:get_player_extension(player, "buff_system")

	return mod.ability_charge_time_remaining(ability_extension, buff_extension, self._ability_type)
end

local function _update_cooldown_text(self)
	local text_widget = self._widgets_by_name.cooldown_timer

	if not text_widget then
		return
	end

	if mod.setting("ability_cooldown_format") == "skitarii_percent" and _is_skitarii_combat_ability(self) then
		_update_skitarii_percent_text(self, text_widget)

		return
	end

	local content = text_widget.content
	local progress = self._ability_progress
	local on_cooldown = self._on_cooldown
	-- new_text stays nil while the displayed value is unchanged, so the
	-- retained widget is only re-rendered when the text actually changes
	local new_text

	if not on_cooldown or not progress or progress >= 1 then
		content._numericui_last_value = nil
		new_text = " "
	else
		local ability_cooldown_format = mod.setting("ability_cooldown_format")

		if ability_cooldown_format == "skitarii_percent" then
			ability_cooldown_format = "time"
		end

		if ability_cooldown_format == "percent" then
			local percent = math_floor(progress * 100)
			if content._numericui_last_value ~= percent then
				content._numericui_last_value = percent
				new_text = string_format("%d%%", percent)
			end
		elseif ability_cooldown_format == "time" then
			local time_remaining = _remaining_cooldown(self)

			if not time_remaining then
				content._numericui_last_value = nil
				new_text = " "
			elseif time_remaining <= 1 then
				content._numericui_last_value = nil
				new_text = string_format("%.1f", time_remaining)
			else
				local seconds = math_floor(time_remaining)
				if content._numericui_last_value ~= seconds then
					content._numericui_last_value = seconds
					new_text = string_format("%d", seconds)
				end
			end
		else
			content._numericui_last_value = nil
			new_text = " "
		end
	end

	if new_text and content.text ~= new_text then
		content.text = new_text
		text_widget.dirty = true
	end
end

mod:hook_safe("HudElementPlayerAbility", "_set_progress", function(self)
	local progress = self._ability_progress

	if mod.setting("disable_ability_background_progress") and progress < 1.0 then
		self._widgets_by_name.ability.content.duration_progress = 0.0
	end

	_update_cooldown_text(self)
end)

mod:hook_safe("HudElementPlayerAbility", "_set_widget_state_colors", function(self)
	_update_cooldown_text(self)
end)

mod:hook_safe("HudElementPlayerAbility", "update", function(self)
	if mod.setting("ability_cooldown_format") ~= "skitarii_percent" or not _is_skitarii_combat_ability(self) then
		return
	end

	local text_widget = self._widgets_by_name and self._widgets_by_name.cooldown_timer

	if text_widget then
		_update_skitarii_percent_text(self, text_widget)
	end
end)
