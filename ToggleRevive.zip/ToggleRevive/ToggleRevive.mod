return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`ToggleRevive` encountered an error loading the Darktide Mod Framework.")

		new_mod("ToggleRevive", {
			mod_script       = "ToggleRevive/scripts/mods/ToggleRevive/ToggleRevive",
			mod_data         = "ToggleRevive/scripts/mods/ToggleRevive/ToggleRevive_data",
			mod_localization = "ToggleRevive/scripts/mods/ToggleRevive/ToggleRevive_localization",
		})
	end,
	packages = {},
}
