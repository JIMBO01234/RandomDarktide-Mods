Toggle Revive

Press interact once to revive/rescue/pull up/un-net a teammate, press again or dodge to cancel.

Needs DMF. Drop the ToggleRevive folder in your Darktide mods folder and add
ToggleRevive to mod_load_order.txt (skip that if you use AML).
Settings are split into tabs if you have Alf's DMF Extensions.
