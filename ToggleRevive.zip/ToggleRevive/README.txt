Toggle Revive

Press interact once to revive/rescue/pull up/un-net a teammate, press again or dodge to cancel.

Needs DMF. Drop the ToggleRevive folder in your Darktide mods folder and add
ToggleRevive to mod_load_order.txt (skip that if you use AML).
Optional aim correction towards downed teammates (radius, cone, speed in the Aim tab).
Settings are split into tabs if you have Alf's DMF Extensions.
