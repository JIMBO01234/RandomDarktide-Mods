local mod = get_mod("ToggleRevive")

local types = {
	revive = "toggle_revive",
	rescue = "toggle_rescue",
	pull_up = "toggle_pull_up",
	remove_net = "toggle_remove_net",
}

local pending_t = 0
local forced_t
local suppress = false
local cancelled = false
local dodge_t = 0

local function get_time()
	local tm = Managers.time
	if tm and tm:has_timer("main") then
		return tm:time("main")
	end
	return 0
end

local function reset()
	pending_t = 0
	forced_t = nil
	suppress = false
	cancelled = false
	dodge_t = 0
end

local function enabled_for(interaction_type)
	if not interaction_type then
		return false
	end
	local setting = types[interaction_type]
	if setting then
		return mod:get(setting)
	end
	return mod:get("toggle_other")
end

local function get_interaction()
	local player = Managers.player and Managers.player:local_player_safe(1)
	local unit = player and player.player_unit
	if not unit or not ALIVE[unit] then
		return
	end

	local ext = ScriptUnit.has_extension(unit, "interactor_system")
	local comp = ext and ext._interaction_component
	if not comp then
		return
	end

	return comp.type, comp.target_unit, ext:is_interacting()
end

local function needs_hold(target)
	if not target or not ALIVE[target] then
		return false
	end
	local ext = ScriptUnit.has_extension(target, "interactee_system")
	return ext and ext:hold_required() or false
end

local function is_active()
	local interaction_type, target, interacting = get_interaction()
	return interacting and enabled_for(interaction_type) and needs_hold(target)
end

local function check_hold(held)
	if suppress then
		if held then
			return false
		end
		suppress = false
	end

	if cancelled then
		if is_active() then
			return held
		end
		cancelled = false
	end

	if held then
		return true
	end

	local t = get_time()

	if is_active() then
		forced_t = forced_t or t
		-- just in case something gets stuck
		if t - forced_t > 30 then
			return false
		end
		return true
	end

	forced_t = nil

	-- quick taps can be released before the interaction starts
	return t < pending_t
end

local function cancel()
	suppress = true
	cancelled = true
	pending_t = 0
	forced_t = nil
end

local function on_pressed()
	local interaction_type, target, interacting = get_interaction()

	if interacting then
		if mod:get("cancel_on_press") and is_active() then
			cancel()
		end
	elseif target and enabled_for(interaction_type) and needs_hold(target) then
		pending_t = get_time() + 0.3
	end
end

mod:hook(CLASS.InputService, "get_with_filters", function(func, self, action_name, ...)
	local val = func(self, action_name, ...)

	if self.type ~= "Ingame" then
		return val
	end

	if action_name == "interact_hold" then
		return check_hold(val)
	elseif action_name == "interact_pressed" then
		-- game only starts on a fresh press, so holding E while sliding into someone does nothing
		if not val and mod:get("hold_to_start") and not suppress and func(self, "interact_hold", ...) then
			local interaction_type, target, interacting = get_interaction()
			if not interacting and target and enabled_for(interaction_type) and needs_hold(target) then
				val = true
			end
		end
		if val then
			on_pressed()
		end
	elseif action_name == "dodge" and mod:get("cancel_on_dodge") then
		if val and not cancelled and is_active() then
			cancel()
			dodge_t = get_time() + 0.5
		elseif not val and dodge_t > 0 and not is_active() then
			-- the interacting state eats the dodge, so send it again once we're out
			if get_time() < dodge_t then
				val = true
			end
			dodge_t = 0
		end
	end

	return val
end)

-- chat/menus swap in the null service which reports nothing held
mod:hook(CLASS.NullInputService, "get_with_filters", function(func, self, action_name, ...)
	local val = func(self, action_name, ...)

	if action_name == "interact_hold" and self.type == "Ingame" and mod:get("continue_in_menus") and not suppress and not cancelled and is_active() then
		return true
	end

	return val
end)

mod.on_game_state_changed = function()
	reset()
end

mod.on_disabled = function()
	reset()
end

mod.on_setting_changed = function()
	reset()
end
