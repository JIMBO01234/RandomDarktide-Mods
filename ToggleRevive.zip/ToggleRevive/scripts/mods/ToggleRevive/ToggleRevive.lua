local mod = get_mod("ToggleRevive")

local types = {
	revive = "toggle_revive",
	rescue = "toggle_rescue",
	pull_up = "toggle_pull_up",
	remove_net = "toggle_remove_net",
}

local pending_t = 0
local forced_t
local suppress = false
local cancelled = false
local dodge_t = 0
local queued_t = 0
local last_target
local grace_t = 0

-- the server runs the interaction a few frames behind us, so keep holding after ours finishes
local GRACE = 0.5

local function get_time()
	local tm = Managers.time
	if tm and tm:has_timer("main") then
		return tm:time("main")
	end
	return 0
end

local function reset()
	pending_t = 0
	forced_t = nil
	suppress = false
	cancelled = false
	dodge_t = 0
	queued_t = 0
	last_target = nil
	grace_t = 0
end

local function enabled_for(interaction_type)
	if not interaction_type then
		return false
	end
	local setting = types[interaction_type]
	if setting then
		return mod:get(setting)
	end
	return mod:get("toggle_other")
end

local function get_interaction()
	local player = Managers.player and Managers.player:local_player_safe(1)
	local unit = player and player.player_unit
	if not unit or not ALIVE[unit] then
		return
	end

	local ext = ScriptUnit.has_extension(unit, "interactor_system")
	local comp = ext and ext._interaction_component
	if not comp then
		return
	end

	return comp.type, comp.target_unit, ext:is_interacting()
end

local function needs_hold(target)
	if not target or not ALIVE[target] then
		return false
	end
	local ext = ScriptUnit.has_extension(target, "interactee_system")
	return ext and ext:hold_required() or false
end

local function is_active()
	local interaction_type, target, interacting = get_interaction()
	return interacting and enabled_for(interaction_type) and needs_hold(target), target
end

-- our side finished but the server may not have, and the target still needs help
local function in_grace(target)
	return last_target ~= nil and (not target or target == last_target) and get_time() < grace_t and needs_hold(last_target)
end

-- logs interaction state changes to the console log, to track down stuck interactions
local last_state

local function trace(held, result)
	local player = Managers.player and Managers.player:local_player_safe(1)
	local unit = player and player.player_unit
	local ext = unit and ALIVE[unit] and ScriptUnit.has_extension(unit, "interactor_system")
	local comp = ext and ext._interaction_component
	if not comp then
		return
	end

	local target = comp.target_unit
	local interactee = target and ALIVE[target] and ScriptUnit.has_extension(target, "interactee_system")
	local state = string.format("type=%s state=%s duration=%.2f start=%.2f done=%.2f target_type=%s hold_req=%s held=%s forced=%s suppress=%s cancelled=%s",
		tostring(comp.type), tostring(comp.state), comp.duration or -1, comp.start_time or -1, comp.done_time or -1,
		tostring(interactee and interactee:interaction_type()), tostring(interactee and interactee:hold_required()),
		tostring(held), tostring(result), tostring(suppress), tostring(cancelled))

	if state ~= last_state then
		last_state = state
		mod:info("t=%.2f %s", get_time(), state)
	end
end

local check_hold

local function check_hold_traced(held)
	local result = check_hold(held)
	if mod:get("debug_trace") then
		trace(held, result)
	end
	return result
end

check_hold = function(held)
	if suppress then
		if held then
			return false
		end
		suppress = false
	end

	if cancelled then
		if is_active() then
			return held
		end
		cancelled = false
	end

	if held then
		return true
	end

	local t = get_time()
	local active, target = is_active()

	if active then
		forced_t = forced_t or t
		-- just in case something gets stuck
		if t - forced_t > 30 then
			return false
		end
		last_target = target
		grace_t = t + GRACE
		return true
	end

	forced_t = nil

	if in_grace() then
		return true
	end

	-- quick taps can be released before the interaction starts
	return t < pending_t
end

local function get_local_unit()
	local player = Managers.player and Managers.player:local_player_safe(1)
	local unit = player and player.player_unit
	if unit and ALIVE[unit] then
		return unit
	end
end

local function aim_pos(target)
	if Unit.has_node(target, "j_spine") then
		return Unit.world_position(target, Unit.node(target, "j_spine"))
	end
	return POSITION_LOOKUP[target] + Vector3(0, 0, 0.3)
end

local function blocked(from, to, target)
	local world = Managers.world:world("level_world")
	local physics_world = World.physics_world(world)
	local diff = to - from
	local dist = Vector3.length(diff)
	if dist < 0.05 then
		return false
	end
	local hit, _, hit_dist, _, actor = PhysicsWorld.raycast(physics_world, from, diff / dist, dist, "closest", "collision_filter", "filter_interactable_line_of_sight_check")
	if not hit then
		return false
	end
	if actor and Actor.unit(actor) == target then
		return false
	end
	return dist - hit_dist > 0.5
end

-- closest downed/hogtied/hanging/netted teammate to the crosshair
local function find_target(unit, cam_pos, cam_fwd)
	local interactor = ScriptUnit.has_extension(unit, "interactor_system")
	if not interactor then
		return
	end

	local my_pos = POSITION_LOOKUP[unit]
	local radius = mod:get("aim_radius")
	local cos_half = math.cos(math.rad(mod:get("aim_cone") * 0.5))
	local need_los = mod:get("aim_los")
	local best, best_dot

	for _, player in pairs(Managers.player:players()) do
		local target = player.player_unit
		if target and target ~= unit and ALIVE[target] then
			local ext = ScriptUnit.has_extension(target, "interactee_system")
			local interaction_type = ext and ext:interaction_type()
			local setting = interaction_type and types[interaction_type]

			if setting and mod:get(setting) and Vector3.distance(my_pos, POSITION_LOOKUP[target]) <= radius then
				local pos = aim_pos(target)
				local dir = Vector3.normalize(pos - cam_pos)
				local dot = Vector3.dot(cam_fwd, dir)

				if dot >= cos_half and (not best_dot or dot > best_dot) and interactor:_check_valid_interaction_target(target) and not (need_los and blocked(cam_pos, pos, target)) then
					best, best_dot = target, dot
				end
			end
		end
	end

	return best
end

local function cancel()
	suppress = true
	cancelled = true
	pending_t = 0
	forced_t = nil
	last_target = nil
	grace_t = 0
end

local function on_pressed()
	local interaction_type, target, interacting = get_interaction()

	if interacting then
		if mod:get("cancel_on_press") and is_active() then
			cancel()
		end
	elseif target and enabled_for(interaction_type) and needs_hold(target) then
		pending_t = get_time() + 0.3
		queued_t = 0
	elseif mod:get("aim_enabled") then
		-- nothing in focus yet, give the aim a moment to find someone
		queued_t = get_time() + 0.6
	end
end

mod:hook(CLASS.InputService, "get_with_filters", function(func, self, action_name, ...)
	local val = func(self, action_name, ...)

	if self.type ~= "Ingame" then
		return val
	end

	if action_name == "interact_hold" then
		return check_hold_traced(val)
	elseif action_name == "interact_pressed" then
		-- game only starts on a fresh press, so holding E while sliding into someone does nothing
		local queued = get_time() < queued_t
		if not val and not suppress and (queued or mod:get("hold_to_start") and func(self, "interact_hold", ...)) then
			local interaction_type, target, interacting = get_interaction()
			-- don't restart on someone we just finished, the server's still catching up
			if not interacting and target and enabled_for(interaction_type) and needs_hold(target) and not in_grace(target) then
				val = true
			end
		end
		if val then
			on_pressed()
		end
	elseif action_name == "dodge" and mod:get("cancel_on_dodge") then
		if val and not cancelled and is_active() then
			cancel()
			dodge_t = get_time() + 0.5
		elseif not val and dodge_t > 0 and not is_active() then
			-- the interacting state eats the dodge, so send it again once we're out
			if get_time() < dodge_t then
				val = true
			end
			dodge_t = 0
		end
	end

	return val
end)

-- chat/menus swap in the null service which reports nothing held
mod:hook(CLASS.NullInputService, "get_with_filters", function(func, self, action_name, ...)
	local val = func(self, action_name, ...)

	if action_name == "interact_hold" and self.type == "Ingame" and mod:get("continue_in_menus") and not suppress and not cancelled and (is_active() or in_grace()) then
		return true
	end

	return val
end)

local KEEP_COS = math.cos(math.rad(20))

local function step_angle(cur, want, max_step)
	local delta = (want - cur + math.pi) % (2 * math.pi) - math.pi
	return math.mod_two_pi(cur + math.clamp(delta, -max_step, max_step))
end

local function should_aim(held)
	local trigger = mod:get("aim_trigger")
	local interaction_type, target, interacting = get_interaction()

	if interacting then
		return mod:get("aim_keep") and is_active(), target
	end

	-- already looking at someone we can revive, leave the camera alone
	if target and types[interaction_type] then
		return false
	end

	if trigger == "always" then
		return true
	end

	return held or get_time() < queued_t
end

local function update_aim(self, dt)
	local unit = get_local_unit()
	local fp = self._first_person_component
	local ori = self._orientation
	if not unit or not fp or not ori or suppress then
		return
	end

	local input = Managers.input:get_input_service("Ingame")
	local held = input and input:_get("interact_hold")
	local aim, current = should_aim(held)
	if not aim then
		return
	end

	local cam_pos = fp.position
	local cp = math.cos(ori.pitch)
	local cam_fwd = Vector3(-cp * math.sin(ori.yaw), cp * math.cos(ori.yaw), math.sin(ori.pitch))
	local target = current or find_target(unit, cam_pos, cam_fwd)
	if not target or not ALIVE[target] then
		return
	end

	local dir = Vector3.normalize(aim_pos(target) - cam_pos)

	-- mid revive: don't touch the camera unless you're about to look off them
	if current and Vector3.dot(cam_fwd, dir) > KEEP_COS then
		return
	end
	local want_yaw = math.mod_two_pi(math.atan2(dir.y, dir.x) - math.pi * 0.5)
	local want_pitch = math.mod_two_pi(math.asin(dir.z))
	local max_step = math.rad(mod:get("aim_speed")) * dt

	ori.yaw = step_angle(ori.yaw, want_yaw, max_step)

	local pitch = step_angle(ori.pitch, want_pitch, max_step)
	if self._min_pitch and self._max_pitch then
		pitch = math.clamp((pitch + math.pi) % (2 * math.pi) - math.pi, self._min_pitch, self._max_pitch) % (2 * math.pi)
	end
	ori.pitch = pitch
end

mod:hook_safe("DefaultPlayerOrientation", "pre_update", function(self, main_t, main_dt)
	if not mod:get("aim_enabled") then
		return
	end
	local ok, err = pcall(update_aim, self, main_dt or 0.016)
	if not ok then
		mod:error(err)
		mod:set("aim_enabled", false)
	end
end)

mod.on_game_state_changed = function()
	reset()
end

mod.on_disabled = function()
	reset()
end

mod.on_setting_changed = function()
	reset()
end
