return {
	mod_description = {
		en = "Makes reviving and helping up teammates a toggle instead of a hold.",
	},
	teammates = {
		en = "Teammates",
	},
	toggle_revive = {
		en = "Revive",
	},
	toggle_rescue = {
		en = "Rescue",
	},
	toggle_pull_up = {
		en = "Pull up (ledge)",
	},
	toggle_remove_net = {
		en = "Remove net",
	},
	misc = {
		en = "Misc",
	},
	cancel_on_press = {
		en = "Press again to cancel",
	},
	hold_to_start = {
		en = "Start when already holding interact",
	},
	hold_to_start_description = {
		en = "e.g. holding E while sliding into a downed teammate",
	},
	cancel_on_dodge = {
		en = "Dodge to cancel",
	},
	continue_in_menus = {
		en = "Don't cancel when opening chat",
	},
	continue_in_menus_description = {
		en = "Also applies to the esc menu",
	},
	toggle_other = {
		en = "Toggle all other hold interactions",
	},
	toggle_other_description = {
		en = "Medicae, objective pickups etc.",
	},
}
