return {
	mod_description = {
		en = "Makes reviving and helping up teammates a toggle instead of a hold.",
	},
	teammates = {
		en = "Teammates",
	},
	toggle_revive = {
		en = "Revive",
	},
	toggle_rescue = {
		en = "Rescue",
	},
	toggle_pull_up = {
		en = "Pull up (ledge)",
	},
	toggle_remove_net = {
		en = "Remove net",
	},
	aim = {
		en = "Aim",
	},
	aim_enabled = {
		en = "Aim at downed teammates",
	},
	aim_enabled_description = {
		en = "Turns your camera towards a teammate that needs help so the revive can start",
	},
	aim_trigger = {
		en = "When",
	},
	aim_trigger_interact = {
		en = "Pressing/holding interact",
	},
	aim_trigger_always = {
		en = "Always when in range",
	},
	aim_radius = {
		en = "Radius (m)",
	},
	aim_radius_description = {
		en = "How close the teammate has to be",
	},
	aim_cone = {
		en = "Cone (degrees)",
	},
	aim_cone_description = {
		en = "Only teammates within this angle of your crosshair. 360 = all around you",
	},
	aim_speed = {
		en = "Turn speed (degrees/s)",
	},
	aim_los = {
		en = "Require line of sight",
	},
	aim_keep = {
		en = "Stay on target while reviving",
	},
	aim_keep_description = {
		en = "Only nudges the camera back if you look far enough away to break the revive",
	},
	misc = {
		en = "Misc",
	},
	cancel_on_press = {
		en = "Press again to cancel",
	},
	hold_to_start = {
		en = "Start when already holding interact",
	},
	hold_to_start_description = {
		en = "e.g. holding E while sliding into a downed teammate",
	},
	cancel_on_dodge = {
		en = "Dodge to cancel",
	},
	continue_in_menus = {
		en = "Don't cancel when opening chat",
	},
	continue_in_menus_description = {
		en = "Also applies to the esc menu",
	},
	toggle_other = {
		en = "Toggle all other hold interactions",
	},
	toggle_other_description = {
		en = "Medicae, objective pickups etc.",
	},
}
