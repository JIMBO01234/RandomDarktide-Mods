local mod = get_mod("ToggleRevive")

return {
	name = "Toggle Revive",
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "teammates",
				type = "group",
				tab = "Teammates",
				sub_widgets = {
					{ setting_id = "toggle_revive", type = "checkbox", default_value = true },
					{ setting_id = "toggle_rescue", type = "checkbox", default_value = true },
					{ setting_id = "toggle_pull_up", type = "checkbox", default_value = true },
					{ setting_id = "toggle_remove_net", type = "checkbox", default_value = true },
				},
			},
			{
				setting_id = "aim",
				type = "group",
				tab = "Aim",
				sub_widgets = {
					{ setting_id = "aim_enabled", type = "checkbox", default_value = true },
					{
						setting_id = "aim_trigger",
						type = "dropdown",
						default_value = "interact",
						options = {
							{ text = "aim_trigger_interact", value = "interact" },
							{ text = "aim_trigger_always", value = "always" },
						},
					},
					{ setting_id = "aim_radius", type = "numeric", default_value = 4, range = { 1, 10 }, decimals_number = 1, step_size_value = 0.5 },
					{ setting_id = "aim_cone", type = "numeric", default_value = 120, range = { 20, 360 }, step_size_value = 10 },
					{ setting_id = "aim_speed", type = "numeric", default_value = 540, range = { 90, 1440 }, step_size_value = 30 },
					{ setting_id = "aim_los", type = "checkbox", default_value = true },
					{ setting_id = "aim_keep", type = "checkbox", default_value = true },
				},
			},
			{
				setting_id = "misc",
				type = "group",
				tab = "Misc",
				sub_widgets = {
					{ setting_id = "hold_to_start", type = "checkbox", default_value = true },
					{ setting_id = "cancel_on_press", type = "checkbox", default_value = true },
					{ setting_id = "cancel_on_dodge", type = "checkbox", default_value = true },
					{ setting_id = "continue_in_menus", type = "checkbox", default_value = true },
					{ setting_id = "toggle_other", type = "checkbox", default_value = false },
				},
			},
		},
	},
}
