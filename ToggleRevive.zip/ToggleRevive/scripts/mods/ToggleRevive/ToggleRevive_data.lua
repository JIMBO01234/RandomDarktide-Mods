local mod = get_mod("ToggleRevive")

return {
	name = "Toggle Revive",
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "teammates",
				type = "group",
				tab = "Teammates",
				sub_widgets = {
					{ setting_id = "toggle_revive", type = "checkbox", default_value = true },
					{ setting_id = "toggle_rescue", type = "checkbox", default_value = true },
					{ setting_id = "toggle_pull_up", type = "checkbox", default_value = true },
					{ setting_id = "toggle_remove_net", type = "checkbox", default_value = true },
				},
			},
			{
				setting_id = "misc",
				type = "group",
				tab = "Misc",
				sub_widgets = {
					{ setting_id = "hold_to_start", type = "checkbox", default_value = true },
					{ setting_id = "cancel_on_press", type = "checkbox", default_value = true },
					{ setting_id = "cancel_on_dodge", type = "checkbox", default_value = true },
					{ setting_id = "continue_in_menus", type = "checkbox", default_value = true },
					{ setting_id = "toggle_other", type = "checkbox", default_value = false },
				},
			},
		},
	},
}
