return {
	mod_name = {
		en = "Player Outlines",
		ru = "Контуры игроков",
		["zh-cn"] = "玩家边框轮廓",
	},
	mod_description = {
		en = "Enables you to optionally show the default skeleton-hologram, a highlighted mesh, and an outline, in any combination. The mesh is visible through walls only, but the outline is always visible. Enjoy!",
		["zh-cn"] = "你可以显示默认的玩家全息骨架、高亮模型、高亮轮廓或者以上任意组合。高亮模型只能隔墙显示，但轮廓始终可见。",
		ru = "Позволяет вам опционально отображать стандартную скелет-голограмму, подсвеченный меш и контур в любой комбинации. Меш виден только сквозь стены, но контур виден всегда. Наслаждайтесь!",
	},
	show_hologram = {
		en = "Show Hologram",
		["zh-cn"] = "显示全息骨架",
		ru = "Показывать голограмму",
	},
	show_mesh = {
		en = "Show Mesh",
		["zh-cn"] = "显示模型",
		ru = "Показывать меш",
	},
	show_outline = {
		en = "Show Outline",
		["zh-cn"] = "显示轮廓",
		ru = "Показывать контур",
	},
	show_in_hub = {
		en = "Show in Mourningstar",
		["zh-cn"] = "在哀星号上显示",
		ru = "Показывать в Моунингстар",
	},
	mission_nameplates_max_distance_title = {
		en = "Nameplates Max. Distance",
		["zh-cn"] = "名称标签最大距离",
		ru = "Имена максимальное расстояние",
	},
	mission_nameplates_max_distance_tt = {
		en = "Sets the maximum distance at which players' names will be visible above them during missions. Defaults to 500. Set to zero to hide them entirely.",
		["zh-cn"] = "设置玩家头顶名称的最大显示距离。默认为 500。设置为 0 表示完全隐藏。",
		ru = "Устанавливает максимальное расстояние, на котором имена игроков будут видны над ними во время миссий. По умолчанию 500. Установите ноль, чтобы скрыть их полностью.",
	},
	assist_marker_max_distance_title = {
		en = "Assist Marker Max. Distance",
		["zh-cn"] = "协助标签最大距离",
		ru = "Маркер помощи макс. расстояние",
	},
	assist_marker_max_distance_tt = {
		en = "Sets the maximum distance at which players' assist markers will be visible above them when the player is down. Defaults to 200. Set to zero to hide them entirely.",
		["zh-cn"] = "设置玩家倒地时的协助图标最大显示距离。默认为 200。设置为 0 表示完全隐藏。",
		ru = "Устанавливает максимальное расстояние, на котором маркеры помощи игрокам будут видны над ними, когда игрок лежит. По умолчанию 200. Установите ноль, чтобы скрыть их полностью.",
	},
	class_colors_group = {
		en = "Class Colours",
		["zh-cn"] = "职业颜色",
		ru = "Цвета классов",
	},
	use_class_colors = {
		en = "Use Class Colours",
		["zh-cn"] = "按职业着色",
		ru = "Использовать цвета классов",
	},
	use_class_colors_tt = {
		en = "When enabled, other players' outline and mesh colour comes from the Default Colour below instead of the game's normal player-slot colour. Tick a specific class further down to give just that class its own colour instead of the default - e.g. leave every class unticked except one to make only that class stand out while everyone else shares the default colour.",
		["zh-cn"] = "启用后，其他玩家的轮廓和模型颜色将使用下方的默认颜色，而不是游戏正常的玩家位颜色。可在下方为某个职业单独勾选以使用其专属颜色而非默认颜色——例如只勾选一个职业，使其单独突出，其余职业仍共用默认颜色。",
		ru = "При включении контур и подсветка меша других игроков будут окрашены в цвет по умолчанию (ниже) вместо обычного цвета слота игрока. Отметьте конкретный класс ниже, чтобы задать ему собственный цвет вместо цвета по умолчанию — например, оставьте отмеченным только один класс, чтобы выделить именно его, а остальные будут использовать общий цвет по умолчанию.",
	},
	default_class_color_group = {
		en = "Default Colour",
		["zh-cn"] = "默认颜色",
		ru = "Цвет по умолчанию",
	},
	default_class_color_group_tt = {
		en = "The colour shown for any class that doesn't have its own override enabled below.",
		["zh-cn"] = "适用于下方未单独启用专属颜色的所有职业。",
		ru = "Цвет, отображаемый для любого класса, для которого ниже не включён собственный цвет.",
	},
	color_channel_r = {
		en = "R",
		["zh-cn"] = "R",
		ru = "R",
	},
	color_channel_g = {
		en = "G",
		["zh-cn"] = "G",
		ru = "G",
	},
	color_channel_b = {
		en = "B",
		["zh-cn"] = "B",
		ru = "B",
	},
	class_color_veteran_override_enable = {
		en = "Veteran",
		["zh-cn"] = "老兵",
		ru = "Ветеран",
	},
	class_color_veteran_override_enable_tt = {
		en = "Give Veteran players their own colour instead of the Default Colour above.",
		["zh-cn"] = "为老兵玩家使用专属颜色，而不是上方的默认颜色。",
		ru = "Задать игрокам-ветеранам собственный цвет вместо цвета по умолчанию выше.",
	},
	class_color_zealot_override_enable = {
		en = "Zealot",
		["zh-cn"] = "狂热者",
		ru = "Фанатик",
	},
	class_color_zealot_override_enable_tt = {
		en = "Give Zealot players their own colour instead of the Default Colour above.",
		["zh-cn"] = "为狂热者玩家使用专属颜色，而不是上方的默认颜色。",
		ru = "Задать игрокам-фанатикам собственный цвет вместо цвета по умолчанию выше.",
	},
	class_color_psyker_override_enable = {
		en = "Psyker",
		["zh-cn"] = "赛科皮斯",
		ru = "Псайкер",
	},
	class_color_psyker_override_enable_tt = {
		en = "Give Psyker players their own colour instead of the Default Colour above.",
		["zh-cn"] = "为赛科皮斯玩家使用专属颜色，而不是上方的默认颜色。",
		ru = "Задать игрокам-псайкерам собственный цвет вместо цвета по умолчанию выше.",
	},
	class_color_ogryn_override_enable = {
		en = "Ogryn",
		["zh-cn"] = "欧格林",
		ru = "Огрин",
	},
	class_color_ogryn_override_enable_tt = {
		en = "Give Ogryn players their own colour instead of the Default Colour above.",
		["zh-cn"] = "为欧格林玩家使用专属颜色，而不是上方的默认颜色。",
		ru = "Задать игрокам-огринам собственный цвет вместо цвета по умолчанию выше.",
	},
	class_color_arbites_override_enable = {
		en = "Arbites",
		["zh-cn"] = "仲裁官",
		ru = "Арбитрес",
	},
	class_color_arbites_override_enable_tt = {
		en = "Give Arbites players their own colour instead of the Default Colour above.",
		["zh-cn"] = "为仲裁官玩家使用专属颜色，而不是上方的默认颜色。",
		ru = "Задать игрокам-арбитрес собственный цвет вместо цвета по умолчанию выше.",
	},
	class_color_skitarii_override_enable = {
		en = "Skitarii",
		["zh-cn"] = "赛塔里",
		ru = "Скитарии",
	},
	class_color_skitarii_override_enable_tt = {
		en = "Give Skitarii players their own colour instead of the Default Colour above.",
		["zh-cn"] = "为赛塔里玩家使用专属颜色，而不是上方的默认颜色。",
		ru = "Задать игрокам-скитариям собственный цвет вместо цвета по умолчанию выше.",
	},
	class_color_hive_scum_override_enable = {
		en = "Hive Scum",
		["zh-cn"] = "巢都渣滓",
		ru = "Отребье улья",
	},
	class_color_hive_scum_override_enable_tt = {
		en = "Give Hive Scum players their own colour instead of the Default Colour above.",
		["zh-cn"] = "为巢都渣滓玩家使用专属颜色，而不是上方的默认颜色。",
		ru = "Задать игрокам Отребья улья собственный цвет вместо цвета по умолчанию выше.",
	},
}
