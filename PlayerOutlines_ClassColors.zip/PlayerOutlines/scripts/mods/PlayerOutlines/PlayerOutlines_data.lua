local mod = get_mod("PlayerOutlines")

-- Only used the first time a class's override is turned on; after that the
-- player's own saved RGB values win. Kept distinct per class purely as a
-- convenient starting point if you do enable an override.
local CLASS_COLOR_DEFAULTS = {
	veteran = { 60, 140, 220 },
	zealot = { 200, 40, 40 },
	psyker = { 150, 60, 200 },
	ogryn = { 220, 160, 40 },
	arbites = { 90, 100, 190 },
	skitarii = { 180, 70, 30 },
	hive_scum = { 90, 180, 90 },
}

-- Default shared colour every class uses unless it has its own override
-- enabled below. Imperial Gold-ish, matching the game's own UI accent.
local DEFAULT_CLASS_COLOR = { 230, 190, 90 }

local function numeric_channel(setting_id, default_value)
	return {
		setting_id = setting_id,
		type = "numeric",
		range = { 0, 255 },
		step_size_value = 1,
		default_value = default_value,
		title = "color_channel_" .. setting_id:match("_(%a)$")
	}
end

-- Per-class widget is OFF by default: with no overrides enabled, every class
-- shows the single "Default Colour" above. Enable a class's own checkbox to
-- give just that one class its own colour instead - e.g. leave every class
-- unticked except Ogryn to make only Ogryns stand out while everyone else
-- shares the default colour.
local function class_color_widget(class_name)
	local defaults = CLASS_COLOR_DEFAULTS[class_name]

	return {
		setting_id = "class_color_" .. class_name .. "_override_enable",
		type = "checkbox",
		default_value = false,
		tooltip = "class_color_" .. class_name .. "_override_enable_tt",
		sub_widgets = {
			numeric_channel("class_color_" .. class_name .. "_r", defaults[1]),
			numeric_channel("class_color_" .. class_name .. "_g", defaults[2]),
			numeric_channel("class_color_" .. class_name .. "_b", defaults[3]),
		}
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	options = {
		widgets = {
			{
				setting_id = "show_hologram",
				type = "checkbox",
				default_value = true
			}, {
				setting_id = "show_mesh",
				type = "checkbox",
				default_value = true
			}, {
				setting_id = "show_outline",
				type = "checkbox",
				default_value = true
			}, {
				setting_id = "show_in_hub",
				type = "checkbox",
				default_value = false
			}, {
				setting_id = "class_colors_group",
				type = "group",
				sub_widgets = {
					{
						setting_id = "use_class_colors",
						type = "checkbox",
						default_value = false,
						tooltip = "use_class_colors_tt"
					},
					{
						setting_id = "default_class_color_group",
						type = "group",
						tooltip = "default_class_color_group_tt",
						sub_widgets = {
							numeric_channel("default_class_color_r", DEFAULT_CLASS_COLOR[1]),
							numeric_channel("default_class_color_g", DEFAULT_CLASS_COLOR[2]),
							numeric_channel("default_class_color_b", DEFAULT_CLASS_COLOR[3]),
						}
					},
					class_color_widget("veteran"),
					class_color_widget("zealot"),
					class_color_widget("psyker"),
					class_color_widget("ogryn"),
					class_color_widget("arbites"),
					class_color_widget("skitarii"),
					class_color_widget("hive_scum"),
				}
			}, {
				setting_id = "mission_nameplates_max_distance",
				title = "mission_nameplates_max_distance_title",
				tooltip = "mission_nameplates_max_distance_tt",
				type = "numeric",
				range = { 0, 500 },
				default_value = 500
			}, {
				setting_id = "assist_marker_max_distance",
				title = "assist_marker_max_distance_title",
				tooltip = "assist_marker_max_distance_tt",
				type = "numeric",
				range = { 0, 200 },
				default_value = 200
			}
		}
	}
}
