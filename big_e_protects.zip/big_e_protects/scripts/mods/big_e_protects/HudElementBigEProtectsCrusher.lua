local mod = get_mod("big_e_protects")

local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")
local UISoundEvents = require("scripts/settings/ui/ui_sound_events")

-- Timer for every Crusher / power maul mark whose special powers the weapon for a while
-- (weapon_special_tweak_data.active_duration). Two kinds, by tweak data:
--   cooldown mode (tweak_data.cooldown, WeaponSpecialExplodeOnImpactCooldown: Crusher
--     powermaul_2h_p1_m2, Ogryn powermaul_p1_m1): activating spends the only charge, which
--     comes back at special_active_start_t + active_duration + cooldown, even if a hit ends
--     the powered window early. Counts down to that.
--   active mode (no cooldown, WeaponSpecialExplodeOnImpact: Crusher powermaul_2h_p1_m1,
--     Ogryn powermaul_p1_m2 / m3): can be re-used any time, so counts down the powered
--     window, which ends at active_duration or on the next hit (special_active goes false).
-- Shock mauls (special attack), powermaul_p3 (energy meter), shield mauls (block charges)
-- and the slab shield (stance) have no timed special and are skipped.
local weapon_name_patterns = {
	"^powermaul_2h_",
	"^ogryn_powermaul_p"
}

local settings = {
	container_size = { 160, 72 },
	icon_size = { 128, 48 },
	bar_size = { 140, 8 },
	bar_offset_y = 56,
	fallback_icon = "content/ui/materials/icons/weapons/hud/debug_primary",
	icon_ready_colour = { 255, 216, 229, 207 },
	icon_cooldown_colour = { 140, 115, 121, 109 },
	bar_background_colour = { 180, 0, 0, 0 },
	bar_frame_colour = { 200, 115, 121, 109 },
	bar_ready_colour = { 255, 181, 196, 167 },
	bar_cooldown_colour = { 255, 255, 170, 60 },
	icon_powered_colour = { 255, 120, 200, 255 },
	bar_powered_colour = { 255, 120, 200, 255 },
	text_colour = { 255, 255, 192, 0 }
}

local default_position = { -760, -50, 1 }

local sg_defs = {
	screen = UIWorkspaceSettings.screen,
	crusher = {
		vertical_alignment = "bottom",
		parent = "screen",
		horizontal_alignment = "right",
		size = settings.container_size,
		position = { default_position[1], default_position[2], 1 }
	}
}

local timer_text_style = table.clone(UIFontSettings.hud_body)
timer_text_style.horizontal_alignment = "center"
timer_text_style.vertical_alignment = "top"
timer_text_style.text_horizontal_alignment = "center"
timer_text_style.text_vertical_alignment = "center"
timer_text_style.size = settings.icon_size
timer_text_style.text_color = settings.text_colour
timer_text_style.font_type = "machine_medium"
timer_text_style.font_size = 28
timer_text_style.offset = { 0, 0, 5 }
timer_text_style.drop_shadow = true

local show_icon = function()
	return mod:get_cached("crusher_display_style") ~= "bar_only"
end

local show_bar = function()
	return mod:get_cached("crusher_display_style") ~= "icon_only"
end

local widget_defs = {
	crusher = UIWidget.create_definition({
		{
			value_id = "icon",
			style_id = "icon",
			pass_type = "texture",
			value = settings.fallback_icon,
			style = {
				horizontal_alignment = "center",
				vertical_alignment = "top",
				size = { settings.icon_size[1], settings.icon_size[2] },
				offset = { 0, 0, 2 },
				color = table.clone(settings.icon_ready_colour)
			},
			visibility_function = function(content, style)
				return show_icon()
			end
		}, {
			value_id = "timer_text",
			style_id = "timer_text",
			pass_type = "text",
			value = "",
			style = timer_text_style,
			visibility_function = function(content, style)
				return show_icon()
			end
		}, {
			style_id = "bar_background",
			pass_type = "rect",
			style = {
				horizontal_alignment = "center",
				vertical_alignment = "top",
				size = { settings.bar_size[1], settings.bar_size[2] },
				offset = { 0, settings.bar_offset_y, 1 },
				color = settings.bar_background_colour
			},
			visibility_function = function(content, style)
				return show_bar()
			end
		}, {
			style_id = "bar_frame",
			pass_type = "rect",
			style = {
				horizontal_alignment = "center",
				vertical_alignment = "top",
				size = { settings.bar_size[1] + 4, settings.bar_size[2] + 4 },
				offset = { 0, settings.bar_offset_y - 2, 0 },
				color = settings.bar_frame_colour
			},
			visibility_function = function(content, style)
				return show_bar()
			end
		}, {
			style_id = "bar_fill",
			pass_type = "rect",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "top",
				size = { 0, settings.bar_size[2] },
				offset = { 0, settings.bar_offset_y, 2 },
				color = settings.bar_ready_colour
			},
			visibility_function = function(content, style)
				return show_bar()
			end
		}
	}, "crusher")
}

local HudElementBigEProtectsCrusher = class("HudElementBigEProtectsCrusher", "HudElementBase")

HudElementBigEProtectsCrusher.init = function(self, parent, draw_layer, start_scale, ...)
	HudElementBigEProtectsCrusher.super.init(self, parent, draw_layer, start_scale, {
		scenegraph_definition = sg_defs,
		widget_definitions = widget_defs
	})

	self._player_unit = parent:player_unit()
	self._scale = nil
end

local function apply_layout(self, widget)
	local x = mod:get_cached("crusher_x") or 0
	local y = mod:get_cached("crusher_y") or 0
	local scale = (mod:get_cached("crusher_size") or 100) / 100

	self:set_scenegraph_position("crusher", default_position[1] + x, default_position[2] + y, 1)

	if self._scale == scale then
		return
	end

	self._scale = scale

	-- The scenegraph node keeps its base size; passes are centred on it and scaled around that.
	local style = widget.style
	local container_w = settings.container_size[1]
	local bar_w = settings.bar_size[1] * scale
	local bar_h = settings.bar_size[2] * scale
	local bar_y = settings.bar_offset_y * scale

	style.icon.size = { settings.icon_size[1] * scale, settings.icon_size[2] * scale }
	style.timer_text.size = { settings.icon_size[1] * scale, settings.icon_size[2] * scale }
	style.timer_text.font_size = 28 * scale
	style.bar_background.size = { bar_w, bar_h }
	style.bar_background.offset = { 0, bar_y, 1 }
	style.bar_frame.size = { bar_w + 4, bar_h + 4 }
	style.bar_frame.offset = { 0, bar_y - 2, 0 }
	style.bar_fill.size[2] = bar_h
	style.bar_fill.offset = { (container_w - bar_w) / 2, bar_y, 2 }
	self._bar_width = bar_w
end

local function is_timed_maul(weapon_template)
	local name = weapon_template and weapon_template.name
	local tweak_data = weapon_template and weapon_template.weapon_special_tweak_data

	if not name or not tweak_data or not tweak_data.active_duration then
		return false
	end

	for i = 1, #weapon_name_patterns do
		if string.find(name, weapon_name_patterns[i]) then
			return true
		end
	end

	return false
end

local function fixed_time()
	local extension_manager = Managers.state and Managers.state.extension

	-- special_active_start_t is written on the fixed-frame clock.
	if extension_manager and extension_manager.latest_fixed_t then
		return extension_manager:latest_fixed_t()
	end

	return Managers.time:time("gameplay")
end

local function crusher_state(player_unit)
	if not player_unit or not ALIVE[player_unit] then
		return nil
	end

	local visual_loadout_extension = ScriptUnit.has_extension(player_unit, "visual_loadout_system")
	local unit_data_extension = ScriptUnit.has_extension(player_unit, "unit_data_system")

	if not visual_loadout_extension or not unit_data_extension then
		return nil
	end

	local weapon_template = visual_loadout_extension:weapon_template_from_slot("slot_primary")

	if not is_timed_maul(weapon_template) then
		return nil
	end

	local inventory_component = unit_data_extension:read_component("inventory")
	local slot_component = unit_data_extension:read_component("slot_primary")

	if not slot_component then
		return nil
	end

	local tweak_data = weapon_template.weapon_special_tweak_data
	local item = visual_loadout_extension.item_from_slot and visual_loadout_extension:item_from_slot("slot_primary")
	local active_duration = tweak_data.active_duration
	local cooldown = tweak_data.cooldown
	local start_t = slot_component.special_active_start_t or 0
	local mode, total, remaining = nil, nil, 0

	if cooldown then
		mode = "cooldown"
		total = active_duration + cooldown

		local max_charges = math.max(slot_component.max_num_special_charges or 1, 1)
		local charges = slot_component.num_special_charges or max_charges

		if charges < max_charges then
			remaining = math.clamp(start_t + total - fixed_time(), 0, total)
		end
	else
		mode = "active"
		total = active_duration

		if slot_component.special_active then
			remaining = math.clamp(start_t + total - fixed_time(), 0, total)
		end
	end

	if total <= 0 then
		return nil
	end

	return {
		mode = mode,
		wielded = inventory_component and inventory_component.wielded_slot == "slot_primary",
		remaining = remaining,
		total = total,
		icon = item and item.hud_icon
	}
end

HudElementBigEProtectsCrusher.update = function(self, dt, t, ui_renderer, render_settings, input_service)
	HudElementBigEProtectsCrusher.super.update(self, dt, t, ui_renderer, render_settings, input_service)

	local widget = self._widgets_by_name.crusher
	widget.visible = false
	widget.dirty = true

	if not mod:get_cached("crusher_enabled") then
		return
	end

	local state = crusher_state(self._player_unit)

	if not state then
		self._was_cooling_down = false

		return
	end

	local running = state.remaining > 0
	local cooling_down = state.mode == "cooldown" and running

	if self._was_cooling_down and not cooling_down and mod:get_cached("crusher_ready_sound") then
		Managers.ui:play_2d_sound(UISoundEvents.ability_off_cooldown)
	end

	self._was_cooling_down = cooling_down

	if mod:get_cached("crusher_only_wielded") and not state.wielded then
		return
	end

	if not running and mod:get_cached("crusher_hide_when_ready") then
		return
	end

	apply_layout(self, widget)

	local style = widget.style

	if state.icon and widget.content.icon ~= state.icon then
		widget.content.icon = state.icon
	end

	if cooling_down then
		style.icon.color = settings.icon_cooldown_colour
		style.bar_fill.color = settings.bar_cooldown_colour
		-- Fills up as the charge recovers; full means ready.
		style.bar_fill.size[1] = self._bar_width * (1 - state.remaining / state.total)
		-- Round up so it never reads 0 while still on cooldown.
		widget.content.timer_text = string.format("%d", math.max(math.ceil(state.remaining - 1e-6), 1))
	elseif running then
		-- Active mode: drains as the powered window runs out.
		style.icon.color = settings.icon_powered_colour
		style.bar_fill.color = settings.bar_powered_colour
		style.bar_fill.size[1] = self._bar_width * state.remaining / state.total
		widget.content.timer_text = string.format("%.1f", math.max(math.ceil(state.remaining * 10 - 1e-6) / 10, 0.1))
	elseif state.mode == "cooldown" then
		style.icon.color = settings.icon_ready_colour
		style.bar_fill.color = settings.bar_ready_colour
		style.bar_fill.size[1] = self._bar_width
		widget.content.timer_text = ""
	else
		-- Active mode, not powered: always usable, nothing to count.
		style.icon.color = settings.icon_ready_colour
		style.bar_fill.size[1] = 0
		widget.content.timer_text = ""
	end

	widget.visible = true
end

HudElementBigEProtectsCrusher.draw = function(self, dt, t, ui_renderer, render_settings, input_service)
	local opacity_percent = mod:get_cached("crusher_opacity") or 100
	local previous_alpha = render_settings and render_settings.alpha_multiplier

	if render_settings then
		render_settings.alpha_multiplier = (previous_alpha or 1) * opacity_percent / 100
	end

	HudElementBigEProtectsCrusher.super.draw(self, dt, t, ui_renderer, render_settings, input_service)

	if render_settings then
		render_settings.alpha_multiplier = previous_alpha
	end
end

return HudElementBigEProtectsCrusher
