return {
	mod_name = {
		en = "BigEProtects",
		["zh-cn"] = "BigEProtects",
	},
	mod_description = {
		en = "Adds an icon like your class ability icon, but it shows the status of your Holy Revenant buff.",
		["zh-cn"] = "添加一个狂信徒镰刀死神被动能力的状态图标，类似角色主动能力。",
	},
	gradual_background_update = {
		en = "Gradual Background Update",
		["zh-cn"] = "动态更新背景",
	},
	gradual_background_update_description = {
		en = "Causes the icon to update its background colour gradually and vertically as its cooldown progresses.",
		["zh-cn"] = "随着能力冷却进度，逐渐在垂直方向更新图标背景颜色。",
	},
	use_ability_frame = {
		en = "Use Ability Frame"
	},
	use_ability_frame_description = {
		en = "Instead of the basic square frame, displays the icon in a frame similar to that of the class ability frame. Dev Note: I couldn't get it to look quite right, hence the black areas, but hey at least there's an option now."
	},
	undying_border = {
		en = "Undying Timer Border",
	},
	undying_border_description = {
		en = "While you're unkillable, from the passive triggering or from Zealous Pilgrim after using your combat ability, draws a gold border around the icon that ticks down clockwise as the undying time runs out.",
	},
	undying_border_shape = {
		en = "Undying Border Shape",
	},
	undying_border_shape_description = {
		en = "Square, or a hexagon like the combat ability frame.",
	},
	undying_border_shape_square = {
		en = "Square",
	},
	undying_border_shape_hexagon = {
		en = "Hexagon",
	},
	undying_border_colour = {
		en = "Undying Border Colour",
	},
	undying_border_colour_description = {
		en = "Colour and transparency of the undying border. Default is gold.",
	},
	undying_border_thickness = {
		en = "Undying Border Thickness",
	},
	hud_position = {
		en = "HUD Position",
		["zh-cn"] = "HUD 位置",
	},
	hud_x = {
		en = "X Position",
		["zh-cn"] = "X 位置",
	},
	hud_y = {
		en = "Y Position",
		["zh-cn"] = "Y 位置",
	},
	hud_size = {
		en = "Icon Size",
		["zh-cn"] = "图标大小",
	},
	hud_opacity = {
		en = "Icon Opacity",
		["zh-cn"] = "图标不透明度",
	},
	hud_opacity_description = {
		en = "Adjusts the transparency of the icon. Lower values make it more see-through, 100 is fully opaque.",
		["zh-cn"] = "调整图标的透明度，数值越低图标越透明，100 为完全不透明。",
	},
	percent_unit = {
		en = "%%",
		["zh-cn"] = "%%",
	},
	crusher_settings = {
		en = "Crusher / Power Maul Special Timer",
	},
	crusher_enabled = {
		en = "Show Special Timer",
	},
	crusher_enabled_description = {
		en = "Shows a separate icon and bar while a Crusher or Ogryn power maul is equipped.\nMarks with a cooldown (Crusher Mk VII, one Ogryn power maul mark) count down until the special can be used again; the orange bar fills up as it recharges.\nMarks without one count down the powered window instead; the blue bar drains until the power-up ends or you land a hit.",
	},
	crusher_display_style = {
		en = "Display Style",
	},
	crusher_style_icon_and_bar = {
		en = "Icon and Bar",
	},
	crusher_style_icon_only = {
		en = "Icon Only",
	},
	crusher_style_bar_only = {
		en = "Bar Only",
	},
	crusher_only_wielded = {
		en = "Only While Wielded",
	},
	crusher_only_wielded_description = {
		en = "Hide the special timer while you have your ranged weapon out.",
	},
	crusher_hide_when_ready = {
		en = "Only While Counting Down",
	},
	crusher_hide_when_ready_description = {
		en = "Hide the timer unless it is counting down (on cooldown, or powered for marks without a cooldown).",
	},
	crusher_ready_sound = {
		en = "Ready Sound",
	},
	crusher_ready_sound_description = {
		en = "Plays the ability-ready sound when the special comes off cooldown (marks with a cooldown only).",
	},
	crusher_x = {
		en = "Timer X Position",
	},
	crusher_y = {
		en = "Timer Y Position",
	},
	crusher_size = {
		en = "Special Timer Size",
	},
	crusher_opacity = {
		en = "Special Timer Opacity",
	},
	dev_mode = {
		en = "Developer Mode",
		["zh-cn"] = "开发者模式",
	},
	dev_mode_description = {
		en = "Enables commands and output for dev and debugging purposes. This is probably not very useful for most players but hey you can enable it if you're curious.",
		["zh-cn"] = "启用开发者调试用的命令和输出。对于多数玩家来说没有实际作用，但如果你很好奇可以尝试一下。",
	}
}
