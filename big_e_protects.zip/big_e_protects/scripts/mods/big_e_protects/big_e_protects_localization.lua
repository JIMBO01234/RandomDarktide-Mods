return {
	mod_name = {
		en = "BigEProtects",
		["zh-cn"] = "BigEProtects",
	},
	mod_description = {
		en = "Adds an icon like your class ability icon, but it shows the status of your Holy Revenant buff.",
		["zh-cn"] = "添加一个狂信徒镰刀死神被动能力的状态图标，类似角色主动能力。",
	},
	gradual_background_update = {
		en = "Gradual Background Update",
		["zh-cn"] = "动态更新背景",
	},
	gradual_background_update_description = {
		en = "Causes the icon to update its background colour gradually and vertically as its cooldown progresses.",
		["zh-cn"] = "随着能力冷却进度，逐渐在垂直方向更新图标背景颜色。",
	},
	use_ability_frame = {
		en = "Use Ability Frame"
	},
	use_ability_frame_description = {
		en = "Instead of the basic square frame, displays the icon in a frame similar to that of the class ability frame. Dev Note: I couldn't get it to look quite right, hence the black areas, but hey at least there's an option now."
	},
	hud_position = {
		en = "HUD Position",
		["zh-cn"] = "HUD 位置",
	},
	hud_x = {
		en = "X Position",
		["zh-cn"] = "X 位置",
	},
	hud_y = {
		en = "Y Position",
		["zh-cn"] = "Y 位置",
	},
	hud_size = {
		en = "Icon Size",
		["zh-cn"] = "图标大小",
	},
	hud_opacity = {
		en = "Icon Opacity",
		["zh-cn"] = "图标不透明度",
	},
	hud_opacity_description = {
		en = "Adjusts the transparency of the icon. Lower values make it more see-through, 100 is fully opaque.",
		["zh-cn"] = "调整图标的透明度，数值越低图标越透明，100 为完全不透明。",
	},
	percent_unit = {
		en = "%%",
		["zh-cn"] = "%%",
	},
	dev_mode = {
		en = "Developer Mode",
		["zh-cn"] = "开发者模式",
	},
	dev_mode_description = {
		en = "Enables commands and output for dev and debugging purposes. This is probably not very useful for most players but hey you can enable it if you're curious.",
		["zh-cn"] = "启用开发者调试用的命令和输出。对于多数玩家来说没有实际作用，但如果你很好奇可以尝试一下。",
	}
}
