local mod = get_mod("big_e_protects")

local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")
local UISoundEvents = require("scripts/settings/ui/ui_sound_events")

local UIHudSettings = require("scripts/settings/ui/ui_hud_settings")
local get_hud_color = UIHudSettings.get_hud_color

local buff_name_hr = "zealot_resist_death_improved_with_leech"
local buff_name_ud = "zealot_resist_death"
-- Zealous Pilgrim: unkillable for a while after using the combat ability.
local buff_name_pilgrim = "zealot_resist_death_temp"

local settings = {
	icon_size = { 92, 80 },
	icon_margin = 20,
	frame = {
		size = { 128, 128 },
		glow_colour = { 255, 255, 255, 255 },
		active_colour = { 255, 181, 196, 167 },
		inactive_colour = { 255, 115, 121, 109 }
	},
	triangles = {
		offset = { 25, 40 },
		colour = { 0, 0, 0, 255 }
	},
	icon_path = "content/ui/textures/icons/talents/zealot_2/zealot_2_base_2",
	undying_border = {
		basic_size = { 92, 92 },
		-- Flat-topped hexagon like the combat ability frame; side points sit a quarter
		-- of the width in from the top/bottom corners.
		basic_hexagon_size = { 104, 92 },
		hexagon_inset = 0.25,
		ability_frame_padding = 12,
		colour = { 255, 255, 190, 0 },
		fallback_active_duration = 5
	}
}

local default_icon_position = {
	-450 - settings.icon_size[1] - settings.icon_margin,
	-40,
	1
}

settings.icon_position = {
	default_icon_position[1],
	default_icon_position[2],
	1
}

local sg_defs = {
	screen = UIWorkspaceSettings.screen,
	icon = {
		vertical_alignment = "bottom",
		parent = "screen",
		horizontal_alignment = "right",
		size = settings.icon_size,
		position = settings.icon_position
	}
}

local counter_text_base_color = { 255, 255, 192, 0 }

local counter_text_style = table.clone(UIFontSettings.hud_body)
counter_text_style.horizontal_alignment = "center"
counter_text_style.vertical_alignment = "center"
counter_text_style.text_horizontal_alignment = "center"
counter_text_style.text_vertical_alignment = "center"
counter_text_style.size = settings.icon_size
counter_text_style.text_color = counter_text_base_color
counter_text_style.font_type = "machine_medium"
counter_text_style.font_size = 32
counter_text_style.offset = { 0, 0, 2 }
counter_text_style.drop_shadow = true

local is_hexagon_border = function()
	return mod:get_cached("undying_border_shape") == "hexagon"
end

local undying_border_visible = function(content, style)
	return content.undying_active and mod:get_cached("undying_border") and not is_hexagon_border()
end

local undying_hexagon_visible = function(content, style)
	return content.undying_active and mod:get_cached("undying_border") and is_hexagon_border()
end

local undying_border_pass = function(style_id)
	return {
		style_id = style_id,
		pass_type = "rect",
		style = {
			horizontal_alignment = "left",
			vertical_alignment = "top",
			offset = { 0, 0, 6 },
			size = { 0, 0 },
			color = settings.undying_border.colour
		},
		visibility_function = undying_border_visible
	}
end

-- Each hexagon edge is a quad drawn as two triangles: undying_hex_<edge>_a / _b.
local undying_hexagon_pass = function(style_id)
	return {
		style_id = style_id,
		pass_type = "triangle",
		style = {
			offset = { 0, 0, 6 },
			color = settings.undying_border.colour,
			triangle_corners = { { 0, 0 }, { 0, 0 }, { 0, 0 } }
		},
		visibility_function = undying_hexagon_visible
	}
end

local icon_passes = {
	undying_border_pass("undying_border_top"),
	undying_border_pass("undying_border_right"),
	undying_border_pass("undying_border_bottom"),
	undying_border_pass("undying_border_left")
}

for edge = 1, 6 do
	icon_passes[#icon_passes + 1] = undying_hexagon_pass("undying_hex_" .. edge .. "_a")
	icon_passes[#icon_passes + 1] = undying_hexagon_pass("undying_hex_" .. edge .. "_b")
end

local frame_passes = {
	{
		value_id = "counter_text",
		style_id = "counter_text",
		pass_type = "text",
		value = "",
		style = counter_text_style
	}, {
		style_id = "ability_frame_container",
		pass_type = "texture",
		value = "content/ui/materials/icons/talents/hud/combat_container",
		style = {
			material_values = {
				progress = 1,
				talent_icon = settings.icon_path
			},
			offset = { 0, 0, 0 },
			color = { 255, 126, 255, 255 }
		},
		visibility_function = function(content, style)
			return mod:get_cached("use_ability_frame")
		end
	}, {
		value = "content/ui/materials/icons/talents/hud/combat_frame_inner",
		style_id = "ability_frame_inner",
		pass_type = "texture",
		style = {
			vertical_alignment = "center",
			horizontal_alignment = "center",
			offset = { 0, 0, 3 },
			color = settings.frame.active_colour,
			size = settings.frame.size
		},
		visibility_function = function(content, style)
			return mod:get_cached("use_ability_frame")
		end
	}, {
		value = "content/ui/materials/icons/buffs/hud/buff_frame",
		style_id = "basic_frame",
		pass_type = "texture",
		style = {
			vertical_alignment = "center",
			horizontal_alignment = "center",
			size = { 118, 118 },
			offset = { 0, 0, 3 },
			color = { 220, 216, 229, 207 }
		},
		visibility_function = function(content, style)
			return not mod:get_cached("use_ability_frame")
		end
	}, {
		value = "content/ui/materials/icons/buffs/hud/buff_container_with_background",
		style_id = "basic_frame_container",
		pass_type = "texture",
		style = {
			vertical_alignment = "center",
			horizontal_alignment = "center",
			material_values = {
				progress = 1,
				talent_icon = settings.icon_path
			},
			offset = { 0, 0, 0 },
			size = { 72, 72 },
			color = settings.frame.active_colour
		},
		visibility_function = function(content, style)
			return not mod:get_cached("use_ability_frame")
		end
	}, {
		value = "content/ui/materials/effects/hud/combat_talent_glow",
		style_id = "ability_frame_glow",
		pass_type = "texture",
		style = {
			vertical_alignment = "center",
			horizontal_alignment = "center",
			offset = { 0, 0, 4 },
			color = settings.frame.glow_colour,
			size = settings.frame.size
		},
		visibility_function = function(content, style)
			return mod:get_cached("use_ability_frame")
		end
	}, {
		style_id = "triangle_top_left",
		pass_type = "triangle",
		style = {
			offset = { 0, 0, 1 },
			color = settings.triangles.colour,
			triangle_corners = {
				{ 0, 0 },
				{ settings.triangles.offset[1], 0 },
				{ 0, settings.triangles.offset[2] }
			}
		},
		visibility_function = function(content, style)
			return mod:get_cached("use_ability_frame")
		end
	}, {
		style_id = "triangle_top_right",
		pass_type = "triangle",
		style = {
			offset = { settings.icon_size[1], 0, 1 },
			color = settings.triangles.colour,
			triangle_corners = {
				{ 0, 0 },
				{ -settings.triangles.offset[1], 0 },
				{ 0, settings.triangles.offset[2] }
			}
		},
		visibility_function = function(content, style)
			return mod:get_cached("use_ability_frame")
		end
	}, {
		style_id = "triangle_bottom_left",
		pass_type = "triangle",
		style = {
			offset = { 0, settings.icon_size[2], 1 },
			color = settings.triangles.colour,
			triangle_corners = {
				{ 0, 0 },
				{ settings.triangles.offset[1], 0 },
				{ 0, -settings.triangles.offset[2] }
			}
		},
		visibility_function = function(content, style)
			return mod:get_cached("use_ability_frame")
		end
	}, {
		style_id = "triangle_bottom_right",
		pass_type = "triangle",
		style = {
			offset = { settings.icon_size[1], settings.icon_size[2], 1 },
			color = settings.triangles.colour,
			triangle_corners = {
				{ 0, 0 },
				{ -settings.triangles.offset[1], 0 },
				{ 0, -settings.triangles.offset[2] }
			}
		},
		visibility_function = function(content, style)
			return mod:get_cached("use_ability_frame")
		end
	}
}

for i = 1, #frame_passes do
	icon_passes[#icon_passes + 1] = frame_passes[i]
end

local widget_defs = {
	icon = UIWidget.create_definition(icon_passes, "icon")
}

local HudElementBigEProtects = class("HudElementBigEProtects", "HudElementBase")

HudElementBigEProtects.init = function(self, parent, draw_layer, start_scale, ...)
	HudElementBigEProtects.super.init(self, parent, draw_layer, start_scale, {
		scenegraph_definition = sg_defs,
		widget_definitions = widget_defs
	})

	self._player_unit = parent:player_unit()
end

local function apply_hud_layout(self, widget)
	local x = mod:get_cached("hud_x") or 0
	local y = mod:get_cached("hud_y") or 0
	local size_percent = mod:get_cached("hud_size") or 100
	local scale = size_percent / 100

	self:set_scenegraph_position("icon", default_icon_position[1] + x, default_icon_position[2] + y, 1)

	local function scaled_size(size)
		return { size[1] * scale, size[2] * scale }
	end

	widget.style.counter_text.size = scaled_size(settings.icon_size)
	widget.style.counter_text.font_size = 32 * scale
	widget.style.ability_frame_inner.size = scaled_size(settings.frame.size)
	widget.style.basic_frame.size = scaled_size({ 118, 118 })
	widget.style.basic_frame_container.size = scaled_size({ 72, 72 })
	widget.style.ability_frame_glow.size = scaled_size(settings.frame.size)

	local triangle_x = settings.triangles.offset[1] * scale
	local triangle_y = settings.triangles.offset[2] * scale
	local icon_w = settings.icon_size[1] * scale
	local icon_h = settings.icon_size[2] * scale

	widget.style.triangle_top_left.triangle_corners = {
		{ 0, 0 }, { triangle_x, 0 }, { 0, triangle_y }
	}
	widget.style.triangle_top_right.offset = { icon_w, 0, 1 }
	widget.style.triangle_top_right.triangle_corners = {
		{ 0, 0 }, { -triangle_x, 0 }, { 0, triangle_y }
	}
	widget.style.triangle_bottom_left.offset = { 0, icon_h, 1 }
	widget.style.triangle_bottom_left.triangle_corners = {
		{ 0, 0 }, { triangle_x, 0 }, { 0, -triangle_y }
	}
	widget.style.triangle_bottom_right.offset = { icon_w, icon_h, 1 }
	widget.style.triangle_bottom_right.triangle_corners = {
		{ 0, 0 }, { -triangle_x, 0 }, { 0, -triangle_y }
	}
end

local function collapse_triangle(triangle_style)
	local corners = triangle_style.triangle_corners

	for i = 1, 3 do
		corners[i][1], corners[i][2] = 0, 0
	end
end

local function set_triangle(triangle_style, ax, ay, bx, by, cx, cy)
	local corners = triangle_style.triangle_corners

	corners[1][1], corners[1][2] = ax, ay
	corners[2][1], corners[2][2] = bx, by
	corners[3][1], corners[3][2] = cx, cy
end

-- Hexagon version of the drain: same clockwise path from the top-left corner. Each edge
-- is the still-visible stretch of that side, thickened inwards towards the centre.
local function apply_undying_hexagon(style, fraction, border_w, border_h, thickness)
	local left = (settings.icon_size[1] - border_w) / 2
	local top = (settings.icon_size[2] - border_h) / 2
	local inset = border_w * settings.undying_border.hexagon_inset
	local centre_x = left + border_w / 2
	local centre_y = top + border_h / 2
	local points = {
		{ left + inset, top },
		{ left + border_w - inset, top },
		{ left + border_w, centre_y },
		{ left + border_w - inset, top + border_h },
		{ left + inset, top + border_h },
		{ left, centre_y }
	}

	local lengths = {}
	local perimeter = 0

	for edge = 1, 6 do
		local from, to = points[edge], points[edge % 6 + 1]
		local length = math.sqrt((to[1] - from[1]) ^ 2 + (to[2] - from[2]) ^ 2)

		lengths[edge] = length
		perimeter = perimeter + length
	end

	local drained = perimeter * (1 - math.clamp(fraction, 0, 1))
	local start = 0

	for edge = 1, 6 do
		local from, to = points[edge], points[edge % 6 + 1]
		local length = lengths[edge]
		local gone = math.clamp(drained - start, 0, length)
		local style_a = style["undying_hex_" .. edge .. "_a"]
		local style_b = style["undying_hex_" .. edge .. "_b"]

		start = start + length

		if length - gone <= 0.01 then
			collapse_triangle(style_a)
			collapse_triangle(style_b)
		else
			local dir_x = (to[1] - from[1]) / length
			local dir_y = (to[2] - from[2]) / length
			-- Perpendicular pointing at the centre, so the band grows inwards.
			local normal_x, normal_y = -dir_y, dir_x
			local mid_x = (from[1] + to[1]) / 2
			local mid_y = (from[2] + to[2]) / 2

			if normal_x * (centre_x - mid_x) + normal_y * (centre_y - mid_y) < 0 then
				normal_x, normal_y = -normal_x, -normal_y
			end

			local ax = from[1] + dir_x * gone
			local ay = from[2] + dir_y * gone
			local bx, by = to[1], to[2]
			local ix, iy = normal_x * thickness, normal_y * thickness

			set_triangle(style_a, ax, ay, bx, by, bx + ix, by + iy)
			set_triangle(style_b, ax, ay, bx + ix, by + iy, ax + ix, ay + iy)
		end
	end
end

-- Gold border around the icon that drains clockwise from the top-left corner as the
-- undying window runs out. fraction is the share of the window still left (0-1).
local undying_style_ids = {
	"undying_border_top",
	"undying_border_right",
	"undying_border_bottom",
	"undying_border_left"
}

for edge = 1, 6 do
	undying_style_ids[#undying_style_ids + 1] = "undying_hex_" .. edge .. "_a"
	undying_style_ids[#undying_style_ids + 1] = "undying_hex_" .. edge .. "_b"
end

-- Colour from the picker ({ a, r, g, b }), or the default gold if the stored value is bad.
local function undying_colour()
	local colour = mod:get_cached("undying_border_colour")

	if type(colour) == "table" and type(colour[1]) == "number" and type(colour[2]) == "number"
		and type(colour[3]) == "number" and type(colour[4]) == "number" then
		return colour
	end

	return settings.undying_border.colour
end

local function apply_undying_border(widget, fraction)
	local style = widget.style
	local colour = undying_colour()

	for i = 1, #undying_style_ids do
		style[undying_style_ids[i]].color = colour
	end

	local scale = (mod:get_cached("hud_size") or 100) / 100
	local thickness = (mod:get_cached("undying_border_thickness") or 6) * scale
	local border_w, border_h

	if mod:get_cached("use_ability_frame") then
		local padding = settings.undying_border.ability_frame_padding
		border_w = (settings.icon_size[1] + padding) * scale
		border_h = (settings.icon_size[2] + padding) * scale
	elseif is_hexagon_border() then
		border_w = settings.undying_border.basic_hexagon_size[1] * scale
		border_h = settings.undying_border.basic_hexagon_size[2] * scale
	else
		border_w = settings.undying_border.basic_size[1] * scale
		border_h = settings.undying_border.basic_size[2] * scale
	end

	if is_hexagon_border() then
		apply_undying_hexagon(style, fraction, border_w, border_h, thickness)

		return
	end

	-- Passes are laid out against the unscaled scenegraph node, centred like the frames.
	local left = (settings.icon_size[1] - border_w) / 2
	local top = (settings.icon_size[2] - border_h) / 2
	local perimeter = 2 * (border_w + border_h)
	local drained = perimeter * (1 - math.clamp(fraction, 0, 1))

	-- How much of a segment (starting at path position `start`) has already drained.
	local function gone(start, length)
		return math.clamp(drained - start, 0, length)
	end

	local top_gone = gone(0, border_w)
	local right_gone = gone(border_w, border_h)
	local bottom_gone = gone(border_w + border_h, border_w)
	local left_gone = gone(2 * border_w + border_h, border_h)

	-- Top runs left to right, so it drains from the left.
	style.undying_border_top.offset[1] = left + top_gone
	style.undying_border_top.offset[2] = top
	style.undying_border_top.size = { border_w - top_gone, thickness }

	-- Right runs top to bottom, so it drains from the top.
	style.undying_border_right.offset[1] = left + border_w - thickness
	style.undying_border_right.offset[2] = top + right_gone
	style.undying_border_right.size = { thickness, border_h - right_gone }

	-- Bottom runs right to left, so it drains from the right.
	style.undying_border_bottom.offset[1] = left
	style.undying_border_bottom.offset[2] = top + border_h - thickness
	style.undying_border_bottom.size = { border_w - bottom_gone, thickness }

	-- Left runs bottom to top, so it drains from the bottom.
	style.undying_border_left.offset[1] = left
	style.undying_border_left.offset[2] = top
	style.undying_border_left.size = { thickness, border_h - left_gone }
end

-- ProcBuff exposes its (talent-adjusted) durations through these; fall back to the
-- template if a game update renames them.
local function buff_durations(buff, template)
	local active = buff._active_duration and buff:_active_duration() or template.active_duration
	local cooldown = buff._cooldown_duration and buff:_cooldown_duration() or template.cooldown_duration

	return active or settings.undying_border.fallback_active_duration, cooldown or 0
end

HudElementBigEProtects.update = function(self, dt, t, ui_renderer,
		render_settings, input_service)
	HudElementBigEProtects.super.update(self, dt, t, ui_renderer,
		render_settings, input_service)

	local widget = self._widgets_by_name.icon
	apply_hud_layout(self, widget)
	widget.visible = false
	widget.content.undying_active = false

	if self._player_unit then
		local buff_extension = ScriptUnit.extension(self._player_unit, "buff_system")

		if buff_extension and buff_extension._buffs then
			-- Whichever undying source has the most time left drives the gold border.
			local undying_remaining, undying_fraction = 0, 0

			for i = 1, #buff_extension._buffs do
				local buff = buff_extension._buffs[i]
				local template = buff._template

				if buff._template_name == buff_name_pilgrim then
					-- Zealous Pilgrim: a plain timed buff, so its own duration progress (1 -> 0)
					-- already accounts for any extra duration.
					local fraction = buff.duration_progress and buff:duration_progress() or 0
					local duration = buff.duration and buff:duration() or template.duration or 1
					local remaining = fraction * math.max(duration, 0.01)

					if fraction > 0 and remaining > undying_remaining then
						undying_remaining = remaining
						undying_fraction = fraction
					end
				end

				if buff._template_name == buff_name_hr or buff._template_name == buff_name_ud then
					local active_duration, cooldown_duration = buff_durations(buff, template)
					local cd = cooldown_duration + active_duration
					local active_start_time = buff._active_start_time
					local lapsed = Managers.time:time("gameplay") - active_start_time

					if lapsed >= 0 and lapsed < active_duration and active_duration > 0 then
						local remaining = active_duration - lapsed

						if remaining > undying_remaining then
							undying_remaining = remaining
							undying_fraction = remaining / active_duration
						end
					end

					if lapsed < cd then
						if mod:get("gradual_background_update") then
							local pc = lapsed / cd
							widget.style.ability_frame_container.material_values.progress = pc
							widget.style.basic_frame_container.material_values.progress = pc
						else
							widget.style.ability_frame_container.material_values.progress = 0
							widget.style.basic_frame_container.material_values.progress = 0
						end

						widget.style.ability_frame_inner.color = settings.frame.inactive_colour
						widget.style.ability_frame_container.color = get_hud_color("color_tint_main_4", 200)
						widget.style.basic_frame_container.color = settings.frame.inactive_colour
						widget.style.basic_frame.color = settings.frame.inactive_colour
						widget.style.ability_frame_glow.visible = false
						widget.content.counter_text = string.format("%.0f", (cd - lapsed))
					elseif widget.style.ability_frame_container.material_values.progress ~= 1 then
						widget.style.basic_frame_container.material_values.progress = 1
						widget.style.ability_frame_container.material_values.progress = 1
						widget.style.ability_frame_container.color = settings.frame.active_colour
						widget.style.ability_frame_inner.color = settings.frame.active_colour
						widget.style.basic_frame_container.color = settings.frame.active_colour
						widget.style.basic_frame.color = { 220, 216, 229, 207 }
						widget.style.ability_frame_glow.visible = true
						widget.content.counter_text = " "
						Managers.ui:play_2d_sound(UISoundEvents.ability_off_cooldown)
					end

					widget.visible = true
				end
			end

			if undying_remaining > 0 then
				widget.content.undying_active = true
				apply_undying_border(widget, undying_fraction)
			end
		end
	end

	widget.dirty = true
end

HudElementBigEProtects.draw = function(self, dt, t, ui_renderer, render_settings, input_service)
	local opacity_percent = mod:get_cached("hud_opacity") or 100

	if opacity_percent ~= 100 and render_settings then
		render_settings.alpha_multiplier = opacity_percent / 100
	end

	HudElementBigEProtects.super.draw(self, dt, t, ui_renderer, render_settings, input_service)
end

return HudElementBigEProtects
