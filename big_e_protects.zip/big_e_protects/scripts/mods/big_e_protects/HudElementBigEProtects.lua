local mod = get_mod("big_e_protects")

local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")
local UISoundEvents = require("scripts/settings/ui/ui_sound_events")

local UIHudSettings = require("scripts/settings/ui/ui_hud_settings")
local get_hud_color = UIHudSettings.get_hud_color

local buff_name_hr = "zealot_resist_death_improved_with_leech"
local buff_name_ud = "zealot_resist_death"

local settings = {
	icon_size = { 92, 80 },
	icon_margin = 20,
	frame = {
		size = { 128, 128 },
		glow_colour = { 255, 255, 255, 255 },
		active_colour = { 255, 181, 196, 167 },
		inactive_colour = { 255, 115, 121, 109 }
	},
	triangles = {
		offset = { 25, 40 },
		colour = { 0, 0, 0, 255 }
	},
	icon_path = "content/ui/textures/icons/talents/zealot_2/zealot_2_base_2"
}

local default_icon_position = {
	-450 - settings.icon_size[1] - settings.icon_margin,
	-40,
	1
}

settings.icon_position = {
	default_icon_position[1],
	default_icon_position[2],
	1
}

local sg_defs = {
	screen = UIWorkspaceSettings.screen,
	icon = {
		vertical_alignment = "bottom",
		parent = "screen",
		horizontal_alignment = "right",
		size = settings.icon_size,
		position = settings.icon_position
	}
}

local counter_text_base_color = { 255, 255, 192, 0 }

local counter_text_style = table.clone(UIFontSettings.hud_body)
counter_text_style.horizontal_alignment = "center"
counter_text_style.vertical_alignment = "center"
counter_text_style.text_horizontal_alignment = "center"
counter_text_style.text_vertical_alignment = "center"
counter_text_style.size = settings.icon_size
counter_text_style.text_color = counter_text_base_color
counter_text_style.font_type = "machine_medium"
counter_text_style.font_size = 32
counter_text_style.offset = { 0, 0, 2 }
counter_text_style.drop_shadow = true

local widget_defs = {
	icon = UIWidget.create_definition({
		{
			value_id = "counter_text",
			style_id = "counter_text",
			pass_type = "text",
			value = "",
			style = counter_text_style
		}, {
			style_id = "ability_frame_container",
			pass_type = "texture",
			value = "content/ui/materials/icons/talents/hud/combat_container",
			style = {
				material_values = {
					progress = 1,
					talent_icon = settings.icon_path
				},
				offset = { 0, 0, 0 },
				color = { 255, 126, 255, 255 }
			},
			visibility_function = function(content, style)
				return mod:get_cached("use_ability_frame")
			end
		}, {
			value = "content/ui/materials/icons/talents/hud/combat_frame_inner",
			style_id = "ability_frame_inner",
			pass_type = "texture",
			style = {
				vertical_alignment = "center",
				horizontal_alignment = "center",
				offset = { 0, 0, 3 },
				color = settings.frame.active_colour,
				size = settings.frame.size
			},
			visibility_function = function(content, style)
				return mod:get_cached("use_ability_frame")
			end
		}, {
			value = "content/ui/materials/icons/buffs/hud/buff_frame",
			style_id = "basic_frame",
			pass_type = "texture",
			style = {
				vertical_alignment = "center",
				horizontal_alignment = "center",
				size = { 118, 118 },
				offset = { 0, 0, 3 },
				color = { 220, 216, 229, 207 }
			},
			visibility_function = function(content, style)
				return not mod:get_cached("use_ability_frame")
			end
		}, {
			value = "content/ui/materials/icons/buffs/hud/buff_container_with_background",
			style_id = "basic_frame_container",
			pass_type = "texture",
			style = {
				vertical_alignment = "center",
				horizontal_alignment = "center",
				material_values = {
					progress = 1,
					talent_icon = settings.icon_path
				},
				offset = { 0, 0, 0 },
				size = { 72, 72 },
				color = settings.frame.active_colour
			},
			visibility_function = function(content, style)
				return not mod:get_cached("use_ability_frame")
			end
		}, {
			value = "content/ui/materials/effects/hud/combat_talent_glow",
			style_id = "ability_frame_glow",
			pass_type = "texture",
			style = {
				vertical_alignment = "center",
				horizontal_alignment = "center",
				offset = { 0, 0, 4 },
				color = settings.frame.glow_colour,
				size = settings.frame.size
			},
			visibility_function = function(content, style)
				return mod:get_cached("use_ability_frame")
			end
		}, {
			style_id = "triangle_top_left",
			pass_type = "triangle",
			style = {
				offset = { 0, 0, 1 },
				color = settings.triangles.colour,
				triangle_corners = {
					{ 0, 0 },
					{ settings.triangles.offset[1], 0 },
					{ 0, settings.triangles.offset[2] }
				}
			},
			visibility_function = function(content, style)
				return mod:get_cached("use_ability_frame")
			end
		}, {
			style_id = "triangle_top_right",
			pass_type = "triangle",
			style = {
				offset = { settings.icon_size[1], 0, 1 },
				color = settings.triangles.colour,
				triangle_corners = {
					{ 0, 0 },
					{ -settings.triangles.offset[1], 0 },
					{ 0, settings.triangles.offset[2] }
				}
			},
			visibility_function = function(content, style)
				return mod:get_cached("use_ability_frame")
			end
		}, {
			style_id = "triangle_bottom_left",
			pass_type = "triangle",
			style = {
				offset = { 0, settings.icon_size[2], 1 },
				color = settings.triangles.colour,
				triangle_corners = {
					{ 0, 0 },
					{ settings.triangles.offset[1], 0 },
					{ 0, -settings.triangles.offset[2] }
				}
			},
			visibility_function = function(content, style)
				return mod:get_cached("use_ability_frame")
			end
		}, {
			style_id = "triangle_bottom_right",
			pass_type = "triangle",
			style = {
				offset = { settings.icon_size[1], settings.icon_size[2], 1 },
				color = settings.triangles.colour,
				triangle_corners = {
					{ 0, 0 },
					{ -settings.triangles.offset[1], 0 },
					{ 0, -settings.triangles.offset[2] }
				}
			},
			visibility_function = function(content, style)
				return mod:get_cached("use_ability_frame")
			end
		}
	}, "icon")
}

local HudElementBigEProtects = class("HudElementBigEProtects", "HudElementBase")

HudElementBigEProtects.init = function(self, parent, draw_layer, start_scale, ...)
	HudElementBigEProtects.super.init(self, parent, draw_layer, start_scale, {
		scenegraph_definition = sg_defs,
		widget_definitions = widget_defs
	})

	self._player_unit = parent:player_unit()
end

local function apply_hud_layout(self, widget)
	local x = mod:get_cached("hud_x") or 0
	local y = mod:get_cached("hud_y") or 0
	local size_percent = mod:get_cached("hud_size") or 100
	local scale = size_percent / 100

	self:set_scenegraph_position("icon", default_icon_position[1] + x, default_icon_position[2] + y, 1)

	local function scaled_size(size)
		return { size[1] * scale, size[2] * scale }
	end

	widget.style.counter_text.size = scaled_size(settings.icon_size)
	widget.style.counter_text.font_size = 32 * scale
	widget.style.ability_frame_inner.size = scaled_size(settings.frame.size)
	widget.style.basic_frame.size = scaled_size({ 118, 118 })
	widget.style.basic_frame_container.size = scaled_size({ 72, 72 })
	widget.style.ability_frame_glow.size = scaled_size(settings.frame.size)

	local triangle_x = settings.triangles.offset[1] * scale
	local triangle_y = settings.triangles.offset[2] * scale
	local icon_w = settings.icon_size[1] * scale
	local icon_h = settings.icon_size[2] * scale

	widget.style.triangle_top_left.triangle_corners = {
		{ 0, 0 }, { triangle_x, 0 }, { 0, triangle_y }
	}
	widget.style.triangle_top_right.offset = { icon_w, 0, 1 }
	widget.style.triangle_top_right.triangle_corners = {
		{ 0, 0 }, { -triangle_x, 0 }, { 0, triangle_y }
	}
	widget.style.triangle_bottom_left.offset = { 0, icon_h, 1 }
	widget.style.triangle_bottom_left.triangle_corners = {
		{ 0, 0 }, { triangle_x, 0 }, { 0, -triangle_y }
	}
	widget.style.triangle_bottom_right.offset = { icon_w, icon_h, 1 }
	widget.style.triangle_bottom_right.triangle_corners = {
		{ 0, 0 }, { -triangle_x, 0 }, { 0, -triangle_y }
	}
end

HudElementBigEProtects.update = function(self, dt, t, ui_renderer,
		render_settings, input_service)
	HudElementBigEProtects.super.update(self, dt, t, ui_renderer,
		render_settings, input_service)

	local widget = self._widgets_by_name.icon
	apply_hud_layout(self, widget)
	widget.visible = false

	if self._player_unit then
		local buff_extension = ScriptUnit.extension(self._player_unit, "buff_system")

		if buff_extension and buff_extension._buffs then
			for i = 1, #buff_extension._buffs do
				local buff = buff_extension._buffs[i]
				local template = buff._template

				if buff._template_name == buff_name_hr or buff._template_name == buff_name_ud then
					local cd = template.cooldown_duration + 5
					local active_start_time = buff._active_start_time
					local lapsed = Managers.time:time("gameplay") - active_start_time

					if lapsed < cd then
						if mod:get("gradual_background_update") then
							local pc = lapsed / cd
							widget.style.ability_frame_container.material_values.progress = pc
							widget.style.basic_frame_container.material_values.progress = pc
						else
							widget.style.ability_frame_container.material_values.progress = 0
							widget.style.basic_frame_container.material_values.progress = 0
						end

						widget.style.ability_frame_inner.color = settings.frame.inactive_colour
						widget.style.ability_frame_container.color = get_hud_color("color_tint_main_4", 200)
						widget.style.basic_frame_container.color = settings.frame.inactive_colour
						widget.style.basic_frame.color = settings.frame.inactive_colour
						widget.style.ability_frame_glow.visible = false
						widget.content.counter_text = string.format("%.0f", (cd - lapsed))
					elseif widget.style.ability_frame_container.material_values.progress ~= 1 then
						widget.style.basic_frame_container.material_values.progress = 1
						widget.style.ability_frame_container.material_values.progress = 1
						widget.style.ability_frame_container.color = settings.frame.active_colour
						widget.style.ability_frame_inner.color = settings.frame.active_colour
						widget.style.basic_frame_container.color = settings.frame.active_colour
						widget.style.basic_frame.color = { 220, 216, 229, 207 }
						widget.style.ability_frame_glow.visible = true
						widget.content.counter_text = " "
						Managers.ui:play_2d_sound(UISoundEvents.ability_off_cooldown)
					end

					widget.visible = true
				end
			end
		end
	end

	widget.dirty = true
end

HudElementBigEProtects.draw = function(self, dt, t, ui_renderer, render_settings, input_service)
	local opacity_percent = mod:get_cached("hud_opacity") or 100

	if opacity_percent ~= 100 and render_settings then
		render_settings.alpha_multiplier = opacity_percent / 100
	end

	HudElementBigEProtects.super.draw(self, dt, t, ui_renderer, render_settings, input_service)
end

return HudElementBigEProtects
