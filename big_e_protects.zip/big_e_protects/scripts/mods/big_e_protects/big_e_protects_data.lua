local mod = get_mod("big_e_protects")

-- Cache settings when they change.
mod.on_setting_changed = function(id)
	mod.settings_cache[id] = mod:get(id)
end

mod.get_cached = function(self, id)
	return self.settings_cache[id]
end

local settings = {
	{
		setting_id = "gradual_background_update",
		type = "checkbox",
		default_value = false,
	}, {
		setting_id = "use_ability_frame",
		type = "checkbox",
		default_value = false
	}, {
		setting_id = "undying_border",
		type = "checkbox",
		default_value = true
	}, {
		setting_id = "undying_border_shape",
		type = "dropdown",
		default_value = "square",
		options = {
			{ text = "undying_border_shape_square", value = "square" },
			{ text = "undying_border_shape_hexagon", value = "hexagon" }
		}
	}, {
		setting_id = "undying_border_colour",
		type = "color",
		default_value = { 255, 255, 190, 0 }, -- ARGB gold
		has_alpha = true
	}, {
		setting_id = "undying_border_thickness",
		type = "numeric",
		default_value = 6,
		range = { 1, 12 },
		decimals_number = 0
	}, {
		setting_id = "hud_position",
		type = "group",
		sub_widgets = {
			{
				setting_id = "hud_x",
				type = "numeric",
				default_value = 0,
				range = { -1000, 1000 },
				decimals_number = 0
			}, {
				setting_id = "hud_y",
				type = "numeric",
				default_value = 0,
				range = { -1000, 1000 },
				decimals_number = 0
			}
		}
	}, {
		setting_id = "hud_size",
		type = "numeric",
		default_value = 100,
		range = { 25, 200 },
		decimals_number = 0,
		unit_text = "percent_unit"
	}, {
		setting_id = "hud_opacity",
		type = "numeric",
		default_value = 100,
		range = { 0, 100 },
		decimals_number = 0,
		unit_text = "percent_unit"
	}, {
		setting_id = "crusher_settings",
		type = "group",
		sub_widgets = {
			{
				setting_id = "crusher_enabled",
				type = "checkbox",
				default_value = true
			}, {
				setting_id = "crusher_display_style",
				type = "dropdown",
				default_value = "icon_and_bar",
				options = {
					{ text = "crusher_style_icon_and_bar", value = "icon_and_bar" },
					{ text = "crusher_style_icon_only", value = "icon_only" },
					{ text = "crusher_style_bar_only", value = "bar_only" }
				}
			}, {
				setting_id = "crusher_only_wielded",
				type = "checkbox",
				default_value = false
			}, {
				setting_id = "crusher_hide_when_ready",
				type = "checkbox",
				default_value = false
			}, {
				setting_id = "crusher_ready_sound",
				type = "checkbox",
				default_value = true
			}, {
				setting_id = "crusher_x",
				type = "numeric",
				default_value = 0,
				range = { -2000, 2000 },
				decimals_number = 0
			}, {
				setting_id = "crusher_y",
				type = "numeric",
				default_value = 0,
				range = { -1200, 1200 },
				decimals_number = 0
			}, {
				setting_id = "crusher_size",
				type = "numeric",
				default_value = 100,
				range = { 25, 200 },
				decimals_number = 0,
				unit_text = "percent_unit"
			}, {
				setting_id = "crusher_opacity",
				type = "numeric",
				default_value = 100,
				range = { 0, 100 },
				decimals_number = 0,
				unit_text = "percent_unit"
			}
		}
	}, {
		setting_id = "dev_mode",
		type = "checkbox",
		default_value = false
	}
}

mod.settings_cache = {}

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	options = { widgets = settings }
}
