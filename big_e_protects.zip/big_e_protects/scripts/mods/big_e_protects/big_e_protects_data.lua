local mod = get_mod("big_e_protects")

-- Cache settings when they change.
mod.on_setting_changed = function(id)
	mod.settings_cache[id] = mod:get(id)
end

mod.get_cached = function(self, id)
	return self.settings_cache[id]
end

local settings = {
	{
		setting_id = "gradual_background_update",
		type = "checkbox",
		default_value = false,
	}, {
		setting_id = "use_ability_frame",
		type = "checkbox",
		default_value = false
	}, {
		setting_id = "hud_position",
		type = "group",
		sub_widgets = {
			{
				setting_id = "hud_x",
				type = "numeric",
				default_value = 0,
				range = { -1000, 1000 },
				decimals_number = 0
			}, {
				setting_id = "hud_y",
				type = "numeric",
				default_value = 0,
				range = { -1000, 1000 },
				decimals_number = 0
			}
		}
	}, {
		setting_id = "hud_size",
		type = "numeric",
		default_value = 100,
		range = { 25, 200 },
		decimals_number = 0,
		unit_text = "percent_unit"
	}, {
		setting_id = "hud_opacity",
		type = "numeric",
		default_value = 100,
		range = { 0, 100 },
		decimals_number = 0,
		unit_text = "percent_unit"
	}, {
		setting_id = "dev_mode",
		type = "checkbox",
		default_value = false
	}
}

mod.settings_cache = {}

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	options = { widgets = settings }
}
