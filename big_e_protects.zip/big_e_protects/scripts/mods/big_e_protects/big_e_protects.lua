local mod = get_mod("big_e_protects")
local fn = "big_e_protects/scripts/mods/big_e_protects/HudElementBigEProtects"
local class_name = "HudElementBigEProtects"

local hr_el = {
	class_name = class_name,
	filename = fn,
	use_hud_scale = true,
	use_retained_mode = true,
	visibility_groups = {
		"alive",
		"communication_wheel",
		"tactical_overlay"
	}
}

local crusher_fn = "big_e_protects/scripts/mods/big_e_protects/HudElementBigEProtectsCrusher"
local crusher_class_name = "HudElementBigEProtectsCrusher"

local crusher_el = {
	class_name = crusher_class_name,
	filename = crusher_fn,
	use_hud_scale = true,
	use_retained_mode = true,
	visibility_groups = {
		"alive",
		"communication_wheel",
		"tactical_overlay"
	}
}

mod:add_require_path(fn)
mod:add_require_path(crusher_fn)

local dev_echo = function(str)
	if mod:get_cached("dev_mode") then
		mod:echo(str)
	end
end

local is_in_hub = function()
	if Managers and Managers.state and Managers.state.game_mode and
			Managers.state.game_mode.game_mode_name then
		return Managers.state.game_mode:game_mode_name() == "hub"
	end

	return true -- Safer than false IMO
end

mod:hook("UIHud", "init", function(func, self, els, ...)
	if not is_in_hub() then
		for i = #els, 1, -1 do
			local v = els[i]

			if v.class_name == class_name or v.class_name == crusher_class_name then
				dev_echo("Removing existing element...")
				table.remove(els, i)
			end
		end

		dev_echo("Adding elements...")
		table.insert(els, hr_el)
		table.insert(els, crusher_el)
	end

	return func(self, els, ...)
end)

mod.on_all_mods_loaded = function()
	local settings_names = {
		"gradual_background_update",
		"use_ability_frame",
		"undying_border",
		"undying_border_shape",
		"undying_border_colour",
		"undying_border_thickness",
		"hud_x",
		"hud_y",
		"hud_size",
		"hud_opacity",
		"crusher_enabled",
		"crusher_display_style",
		"crusher_only_wielded",
		"crusher_hide_when_ready",
		"crusher_ready_sound",
		"crusher_x",
		"crusher_y",
		"crusher_size",
		"crusher_opacity",
		"dev_mode"
	}

	for _, v in ipairs(settings_names) do
		mod.settings_cache[v] = mod:get(v)
	end
end
