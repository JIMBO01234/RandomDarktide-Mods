local mod = get_mod("big_e_protects")
local fn = "big_e_protects/scripts/mods/big_e_protects/HudElementBigEProtects"
local class_name = "HudElementBigEProtects"

local hr_el = {
	class_name = class_name,
	filename = fn,
	use_hud_scale = true,
	use_retained_mode = true,
	visibility_groups = {
		"alive",
		"communication_wheel",
		"tactical_overlay"
	}
}

mod:add_require_path(fn)

local dev_echo = function(str)
	if mod:get_cached("dev_mode") then
		mod:echo(str)
	end
end

local is_in_hub = function()
	if Managers and Managers.state and Managers.state.game_mode and
			Managers.state.game_mode.game_mode_name then
		return Managers.state.game_mode:game_mode_name() == "hub"
	end

	return true -- Safer than false IMO
end

mod:hook("UIHud", "init", function(func, self, els, ...)
	if not is_in_hub() then
		for i, v in ipairs(els) do
			if v.class_name == class_name then
				dev_echo("Removing existing element...")
				table.remove(els, i)
				break
			end
		end

		dev_echo("Adding element...")
		table.insert(els, hr_el)
	end

	return func(self, els, ...)
end)

mod.on_all_mods_loaded = function()
	local settings_names = {
		"gradual_background_update",
		"use_ability_frame",
		"hud_x",
		"hud_y",
		"hud_size",
		"hud_opacity",
		"dev_mode"
	}

	for _, v in ipairs(settings_names) do
		mod.settings_cache[v] = mod:get(v)
	end
end
