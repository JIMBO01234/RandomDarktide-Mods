return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`big_e_protects` encountered an error loading the Darktide Mod Framework.")

		new_mod("big_e_protects", {
			mod_script       = "big_e_protects/scripts/mods/big_e_protects/big_e_protects",
			mod_data         = "big_e_protects/scripts/mods/big_e_protects/big_e_protects_data",
			mod_localization = "big_e_protects/scripts/mods/big_e_protects/big_e_protects_localization",
		})
	end,
	packages = {},
}
