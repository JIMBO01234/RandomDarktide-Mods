return {
	mod_name = {
		en = "Discord Transmission",
	},
	mod_description = {
		en = "Incoming Transmission popup for Discord friends who are talking. Needs the bridge from the companion folder running.",
	},
	show_self = {
		en = "Show my own transmissions",
	},
	show_discord_only = {
		en = "Show friends who aren't in the game",
	},
	show_discord_only_description = {
		en = "Uses their custom image or Discord avatar.",
	},
	picture = {
		en = "Picture",
	},
	picture_description = {
		en = "Friends who aren't in the game have no operative and get their Discord picture instead.",
	},
	picture_custom_operative = {
		en = "Custom image, else operative",
	},
	picture_custom_discord = {
		en = "Custom image, else Discord picture",
	},
	picture_operative = {
		en = "Operative",
	},
	picture_discord = {
		en = "Discord picture",
	},
	hold_time = {
		en = "Hold time (seconds)",
	},
	hold_time_description = {
		en = "How long the popup stays after someone stops talking.",
	},
	offset_y = {
		en = "Vertical position",
	},
	offset_y_description = {
		en = "The game's own transmission popup sits at 300.",
	},
	scale = {
		en = "Size",
	},
	opacity = {
		en = "Opacity",
	},
	unit_percent = {
		en = "%%",
	},
	command_description = {
		en = "Show who the Discord bridge hears and who is around you.",
	},
	status_no_bridge = {
		en = "Bridge is not running.",
	},
	status_speaker = {
		en = "Speaking: %s -> %s",
	},
	status_player = {
		en = "Player: %s (%s)",
	},
}
