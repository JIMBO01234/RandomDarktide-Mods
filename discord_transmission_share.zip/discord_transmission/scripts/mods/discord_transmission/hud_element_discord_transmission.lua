local mod = get_mod("discord_transmission")

local HudElementMissionSpeakerPopupSettings = require("scripts/ui/hud/elements/mission_speaker_popup/hud_element_mission_speaker_popup_settings")
local UISettings = require("scripts/settings/ui/ui_settings")
local Definitions = mod:io_dofile("discord_transmission/scripts/mods/discord_transmission/hud_element_discord_transmission_definitions")

local DEFAULT_FRAME_TEXTURE = "content/ui/textures/nameplates/portrait_frames/default"
local EDGE_OFFSET = -50

local HudElementDiscordTransmission = class("HudElementDiscordTransmission", "HudElementBase")

-- texture nil shows the placeholder silhouette.
local set_portrait_texture = function (slot, texture, rows, columns, grid_index)
	local widget = slot.widgets.popup
	local material_values = widget.style.portrait.material_values

	material_values.use_placeholder_texture = texture and 0 or 1
	material_values.rows = rows or 1
	material_values.columns = columns or 1
	material_values.grid_index = grid_index or 0
	material_values.texture_icon = texture
	widget.content.portrait = slot.frame_material or UISettings.portrait_frame_default_material
end

HudElementDiscordTransmission.init = function (self, parent, draw_layer, start_scale)
	HudElementDiscordTransmission.super.init(self, parent, draw_layer, start_scale, Definitions)

	local num_bars = HudElementMissionSpeakerPopupSettings.bar_amount
	local bar_offset = HudElementMissionSpeakerPopupSettings.bar_offset
	local bar_size = HudElementMissionSpeakerPopupSettings.bar_size
	local bar_spacing = HudElementMissionSpeakerPopupSettings.bar_spacing
	local widgets_by_name = self._widgets_by_name
	local slots = {}

	for slot_index = 1, Definitions.slot_count do
		local widgets = {
			popup = widgets_by_name["popup_" .. slot_index],
			name_text = widgets_by_name["name_text_" .. slot_index],
			title_text = widgets_by_name["title_text_" .. slot_index],
		}
		local bar_widgets = {}

		for bar_index = 1, num_bars do
			local widget = widgets_by_name["bar_" .. slot_index .. "_" .. bar_index]

			widget.offset = {
				bar_offset[1] - (bar_size[1] + bar_spacing) * (bar_index - 1),
				bar_offset[2],
				bar_offset[3],
			}
			bar_widgets[bar_index] = widget
			widgets["bar_" .. bar_index] = widget
		end

		-- Idle slots are still drawn, just invisible.
		for _, widget in pairs(widgets) do
			widget.alpha_multiplier = 0
		end

		slots[slot_index] = {
			scenegraph_id = "background_" .. slot_index,
			widgets = widgets,
			bar_widgets = bar_widgets,
		}
	end

	self._slots = slots
end

HudElementDiscordTransmission.destroy = function (self, ui_renderer)
	for _, slot in ipairs(self._slots) do
		self:_unload_portrait(slot)
		self:_unload_image(slot)
		self:_unload_frame(slot)
	end

	HudElementDiscordTransmission.super.destroy(self, ui_renderer)
end

-- Size setting on top of the HUD scale.
HudElementDiscordTransmission._with_scale = function (self, render_settings, func, ...)
	local scale = render_settings.scale
	local inverse_scale = render_settings.inverse_scale
	local new_scale = (scale or 1) * self._scale

	render_settings.scale = new_scale
	render_settings.inverse_scale = 1 / new_scale

	func(self, ...)

	render_settings.scale = scale
	render_settings.inverse_scale = inverse_scale
end

HudElementDiscordTransmission.update = function (self, dt, t, ui_renderer, render_settings, input_service)
	self:_sync_position()
	self:_sync_active_speakers()
	self:_with_scale(render_settings, HudElementDiscordTransmission.super.update, dt, t, ui_renderer, render_settings, input_service)

	local visible = false

	for _, slot in ipairs(self._slots) do
		if slot.animation_id and not self:_is_animation_active(slot.animation_id) then
			slot.animation_id = nil
		end

		visible = visible or slot.entry ~= nil or slot.animation_id ~= nil
	end

	self._visible = visible

	local bar_timer = self._bar_timer or 0

	if bar_timer <= 0 then
		for _, slot in ipairs(self._slots) do
			if slot.entry then
				self:_update_bar_value(slot)
			end
		end

		bar_timer = 0.1
	else
		bar_timer = bar_timer - dt
	end

	self._bar_timer = bar_timer
end

HudElementDiscordTransmission._sync_position = function (self)
	local offset_y = mod:get("offset_y")
	local scale = mod:get("scale") / 100

	if offset_y ~= self._offset_y or scale ~= self._scale then
		self._offset_y = offset_y
		self._scale = scale

		-- Positions scale too, keep the stack where it was.
		for slot_index, slot in ipairs(self._slots) do
			self:set_scenegraph_position(slot.scenegraph_id, EDGE_OFFSET / scale, offset_y / scale + Definitions.slot_spacing * (slot_index - 1))
		end
	end
end

HudElementDiscordTransmission._update_bar_value = function (self, slot)
	local bar_widgets = slot.bar_widgets
	local anim_progress = math.min((1 + math.sin(Application.time_since_launch() * 6) * 0.5) * math.random_range(0.3, 0.8), 1)
	local bar_height = HudElementMissionSpeakerPopupSettings.bar_size[2]

	for i = #bar_widgets, 1, -1 do
		local new_bar_height

		if i > 1 then
			new_bar_height = bar_widgets[i - 1].style.bar.size[2]
		else
			new_bar_height = bar_height * anim_progress
		end

		bar_widgets[i].style.bar.size[2] = new_bar_height
	end
end

HudElementDiscordTransmission._sync_active_speakers = function (self)
	local speakers = mod.active_speakers()
	local slots = self._slots

	for _, slot in ipairs(slots) do
		if slot.entry and not table.contains(speakers, slot.entry) then
			slot.entry = nil

			self:_slot_stop(slot)
		end
	end

	for i = 1, #speakers do
		local entry = speakers[i]
		local entry_slot, free_slot

		for _, slot in ipairs(slots) do
			if slot.entry == entry then
				entry_slot = slot

				break
			end

			free_slot = free_slot or not slot.entry and slot or nil
		end

		if entry_slot then
			self:_show_speaker(entry_slot, entry)
		elseif free_slot then
			free_slot.entry = entry

			self:_slot_start(free_slot, entry)
		end
	end
end

HudElementDiscordTransmission._slot_stop = function (self, slot)
	if slot.animation_id then
		self:_stop_animation(slot.animation_id)
	end

	slot.animation_id = self:_start_animation("popup_exit", slot.widgets)
end

HudElementDiscordTransmission._slot_start = function (self, slot, entry)
	if slot.animation_id then
		self:_stop_animation(slot.animation_id)
	end

	self:_show_speaker(slot, entry)

	slot.animation_id = self:_start_animation("popup_enter", slot.widgets)
end

-- Images stay loaded after the speaker stops, the exit animation still needs them.
HudElementDiscordTransmission._show_speaker = function (self, slot, entry)
	slot.widgets.name_text.content.name_text = entry.name or ""

	if slot.shown and entry.player == slot.shown_player and entry.image == slot.shown_image then
		return
	end

	local profile = entry.player and entry.player:profile()

	slot.shown = true
	slot.shown_player = entry.player
	slot.shown_image = entry.image

	self:_load_frame(slot, profile)

	if entry.image then
		self:_unload_portrait(slot)
		self:_load_image(slot, entry.image)
	elseif profile then
		self:_unload_image(slot)
		self:_load_portrait(slot, profile)
	else
		self:_unload_image(slot)
		self:_unload_portrait(slot)
		set_portrait_texture(slot, nil)
	end
end

HudElementDiscordTransmission._load_portrait = function (self, slot, profile)
	if slot.portrait_load_id and slot.portrait_character_id == profile.character_id and Managers.ui:portrait_has_request(slot.portrait_load_id) then
		return
	end

	self:_unload_portrait(slot)
	set_portrait_texture(slot, nil)

	-- Callbacks of a replaced request are ignored.
	local token = {}

	slot.portrait_token = token
	slot.portrait_character_id = profile.character_id
	slot.portrait_load_id = Managers.ui:load_profile_portrait(profile, function (grid_index, rows, columns, render_target)
		if slot.portrait_token == token then
			set_portrait_texture(slot, render_target, rows, columns, grid_index - 1)
		end
	end, nil, function ()
		if slot.portrait_token == token then
			set_portrait_texture(slot, nil)
		end
	end)
end

HudElementDiscordTransmission._unload_portrait = function (self, slot)
	local portrait_load_id = slot.portrait_load_id

	slot.portrait_token = nil
	slot.portrait_load_id = nil
	slot.portrait_character_id = nil

	if portrait_load_id then
		Managers.ui:unload_profile_portrait(portrait_load_id)
	end
end

HudElementDiscordTransmission._load_image = function (self, slot, url)
	if slot.image_url == url then
		return
	end

	self:_unload_image(slot)
	set_portrait_texture(slot, nil)

	local token = {}

	slot.image_token = token
	slot.image_url = url

	-- No auth, the backend would otherwise send the game's login along.
	Managers.url_loader:load_texture(url, false, "discord_transmission"):next(function (data)
		if slot.image_token == token and not self.__deleted then
			slot.widgets.popup.style.image.material_values.texture_map = data.texture
		end
	end, function ()
	end)
end

HudElementDiscordTransmission._unload_image = function (self, slot)
	local image_url = slot.image_url

	slot.image_token = nil
	slot.image_url = nil
	-- Has to let go of the texture before it is freed.
	slot.widgets.popup.style.image.material_values.texture_map = nil

	if image_url then
		Managers.url_loader:unload_texture(image_url)
	end
end

-- Equipped portrait frame, also around custom images.
HudElementDiscordTransmission._load_frame = function (self, slot, profile)
	local frame_item = profile and profile.loadout and profile.loadout.slot_portrait_frame

	if frame_item == slot.frame_item then
		return
	end

	self:_unload_frame(slot)

	if not frame_item then
		return
	end

	local token = {}

	slot.frame_token = token
	slot.frame_item = frame_item
	slot.frame_load_id = Managers.ui:load_item_icon(frame_item, function (item)
		if slot.frame_token ~= token or self.__deleted then
			return
		end

		local widget = slot.widgets.popup
		local material_values = widget.style.portrait.material_values

		if item.icon_material and item.icon_material ~= "" then
			slot.frame_material = item.icon_material
			material_values.portrait_frame_texture = nil
		else
			slot.frame_material = nil
			material_values.portrait_frame_texture = item.icon or DEFAULT_FRAME_TEXTURE
		end

		widget.content.portrait = slot.frame_material or UISettings.portrait_frame_default_material
	end)
end

HudElementDiscordTransmission._unload_frame = function (self, slot)
	local frame_load_id = slot.frame_load_id
	local widget = slot.widgets.popup

	slot.frame_token = nil
	slot.frame_item = nil
	slot.frame_load_id = nil
	slot.frame_material = nil
	widget.style.portrait.material_values.portrait_frame_texture = DEFAULT_FRAME_TEXTURE
	widget.content.portrait = UISettings.portrait_frame_default_material

	if frame_load_id then
		Managers.ui:unload_item_icon(frame_load_id)
	end
end

HudElementDiscordTransmission.draw = function (self, dt, t, ui_renderer, render_settings, input_service)
	if not self._visible then
		return
	end

	self:_with_scale(render_settings, HudElementDiscordTransmission.super.draw, dt, t, ui_renderer, render_settings, input_service)
end

HudElementDiscordTransmission._draw_widgets = function (self, dt, t, input_service, ui_renderer, render_settings)
	local alpha_multiplier = render_settings.alpha_multiplier

	render_settings.alpha_multiplier = (alpha_multiplier or 1) * mod:get("opacity") / 100

	HudElementDiscordTransmission.super._draw_widgets(self, dt, t, input_service, ui_renderer, render_settings)

	render_settings.alpha_multiplier = alpha_multiplier
end

return HudElementDiscordTransmission
