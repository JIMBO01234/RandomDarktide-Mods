-- Based on hud_element_mission_speaker_popup_definitions, one popup per slot.
local HudElementMissionSpeakerPopupSettings = require("scripts/ui/hud/elements/mission_speaker_popup/hud_element_mission_speaker_popup_settings")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")
local UIHudSettings = require("scripts/settings/ui/ui_hud_settings")
local UISettings = require("scripts/settings/ui/ui_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")

local SLOT_COUNT = 4
local SLOT_SPACING = 110

local portrait_size = HudElementMissionSpeakerPopupSettings.portrait_size
local bar_size = HudElementMissionSpeakerPopupSettings.bar_size
local scenegraph_definition = {
	screen = UIWorkspaceSettings.screen,
}
local name_text_style = table.clone(UIFontSettings.hud_body)

name_text_style.horizontal_alignment = "right"
name_text_style.vertical_alignment = "top"
name_text_style.text_horizontal_alignment = "right"
name_text_style.text_vertical_alignment = "bottom"
name_text_style.size = {
	650,
	40,
}
name_text_style.offset = {
	-(portrait_size[1] + 20),
	15,
	2,
}
name_text_style.drop_shadow = true
name_text_style.font_size = 24

local title_text_style = table.clone(name_text_style)

title_text_style.offset = {
	-(portrait_size[1] + 20),
	-10,
	2,
}
title_text_style.text_color = UIHudSettings.color_tint_main_2

local widget_definitions = {}

for slot_index = 1, SLOT_COUNT do
	local scenegraph_id = "background_" .. slot_index

	scenegraph_definition[scenegraph_id] = {
		horizontal_alignment = "right",
		parent = "screen",
		vertical_alignment = "top",
		size = portrait_size,
		position = {
			-50,
			410 + SLOT_SPACING * (slot_index - 1),
			20,
		},
	}
	widget_definitions["popup_" .. slot_index] = UIWidget.create_definition({
		{
			pass_type = "texture",
			style_id = "portrait",
			value_id = "portrait",
			value = UISettings.portrait_frame_default_material,
			style = {
				material_values = {
					columns = 1,
					grid_index = 1,
					portrait_frame_texture = "content/ui/textures/nameplates/portrait_frames/default",
					rows = 1,
					use_placeholder_texture = 1,
				},
			},
		},
		-- Downloaded images crash the portrait material, they get their own pass on top of it.
		{
			pass_type = "texture",
			style_id = "image",
			value = "content/ui/materials/base/ui_default_base",
			style = {
				horizontal_alignment = "center",
				vertical_alignment = "center",
				size = {
					portrait_size[1] - 12,
					portrait_size[2] - 12,
				},
				offset = {
					0,
					0,
					1,
				},
				material_values = {},
			},
			visibility_function = function (content, style)
				return style.material_values.texture_map ~= nil
			end,
		},
	}, scenegraph_id)
	widget_definitions["name_text_" .. slot_index] = UIWidget.create_definition({
		{
			pass_type = "text",
			style_id = "name_text",
			value = "",
			value_id = "name_text",
			style = name_text_style,
		},
	}, scenegraph_id)
	widget_definitions["title_text_" .. slot_index] = UIWidget.create_definition({
		{
			pass_type = "text",
			style_id = "title_text",
			value_id = "title_text",
			value = Localize("loc_mission_speaker_title_text"),
			style = title_text_style,
		},
	}, scenegraph_id)

	for bar_index = 1, HudElementMissionSpeakerPopupSettings.bar_amount do
		widget_definitions["bar_" .. slot_index .. "_" .. bar_index] = UIWidget.create_definition({
			{
				pass_type = "texture",
				style_id = "background",
				value = "content/ui/materials/backgrounds/default_square",
				style = {
					horizontal_alignment = "center",
					vertical_alignment = "bottom",
					size = bar_size,
					color = UIHudSettings.color_tint_main_4,
					offset = {
						0,
						0,
						0,
					},
				},
			},
			{
				pass_type = "texture",
				style_id = "bar",
				value = "content/ui/materials/backgrounds/default_square",
				style = {
					horizontal_alignment = "center",
					vertical_alignment = "bottom",
					size = {
						bar_size[1],
						bar_size[2],
					},
					color = UIHudSettings.color_tint_main_2,
					offset = {
						0,
						0,
						1,
					},
				},
			},
			{
				pass_type = "texture",
				style_id = "frame",
				value = "content/ui/materials/frames/line_light",
				style = {
					horizontal_alignment = "center",
					vertical_alignment = "bottom",
					size = bar_size,
					color = UIHudSettings.color_tint_main_3,
					size_addition = {
						4,
						4,
					},
					offset = {
						0,
						2,
						2,
					},
				},
			},
		}, scenegraph_id)
	end
end

-- Started with a single slot's widgets.
local animations = {
	popup_enter = {
		{
			end_time = 0,
			name = "hide everything",
			start_time = 0,
			init = function (parent, ui_scenegraph, scenegraph_definition, widgets)
				for _, widget in pairs(widgets) do
					widget.alpha_multiplier = 0
				end
			end,
		},
		{
			end_time = 0.15,
			name = "icon_fade_in",
			start_time = 0,
			update = function (parent, ui_scenegraph, scenegraph_definition, widgets, progress)
				local anim_progress = math.easeOutCubic(progress)
				local popup_widget = widgets.popup

				popup_widget.alpha_multiplier = anim_progress
				popup_widget.offset[1] = 50 - 50 * anim_progress
			end,
		},
		{
			end_time = 0.25,
			name = "text_fade_in",
			start_time = 0.05,
			update = function (parent, ui_scenegraph, scenegraph_definition, widgets, progress)
				local anim_progress = math.easeCubic(progress)

				for key, widget in pairs(widgets) do
					if key ~= "popup" then
						widget.alpha_multiplier = anim_progress
					end
				end
			end,
		},
	},
	popup_exit = {
		{
			end_time = 0.3,
			name = "text_fade_out",
			start_time = 0,
			update = function (parent, ui_scenegraph, scenegraph_definition, widgets, progress)
				local anim_progress = 1 - math.easeOutCubic(progress)

				for key, widget in pairs(widgets) do
					if key ~= "popup" then
						widget.alpha_multiplier = anim_progress
					end
				end
			end,
		},
		{
			end_time = 1,
			name = "icon_fade_out",
			start_time = 0.5,
			update = function (parent, ui_scenegraph, scenegraph_definition, widgets, progress)
				local anim_progress = 1 - math.easeOutCubic(progress)
				local popup_widget = widgets.popup

				popup_widget.alpha_multiplier = anim_progress
				popup_widget.offset[1] = 50 - 50 * anim_progress
			end,
		},
	},
}

return {
	animations = animations,
	widget_definitions = widget_definitions,
	scenegraph_definition = scenegraph_definition,
	slot_count = SLOT_COUNT,
	slot_spacing = SLOT_SPACING,
}
