local mod = get_mod("discord_transmission")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "show_self",
				type = "checkbox",
				default_value = false,
			},
			{
				setting_id = "show_discord_only",
				type = "checkbox",
				default_value = true,
			},
			{
				setting_id = "picture",
				type = "dropdown",
				default_value = "custom_operative",
				options = {
					{ text = "picture_custom_operative", value = "custom_operative" },
					{ text = "picture_custom_discord", value = "custom_discord" },
					{ text = "picture_operative", value = "operative" },
					{ text = "picture_discord", value = "discord" },
				},
			},
			{
				setting_id = "hold_time",
				type = "numeric",
				default_value = 0.8,
				range = { 0, 3 },
				decimals_number = 1,
			},
			{
				setting_id = "offset_y",
				type = "numeric",
				default_value = 410,
				range = { 0, 900 },
			},
			{
				setting_id = "scale",
				type = "numeric",
				default_value = 100,
				range = { 40, 150 },
				unit_text = "unit_percent",
			},
			{
				setting_id = "opacity",
				type = "numeric",
				default_value = 100,
				range = { 10, 100 },
				unit_text = "unit_percent",
			},
		},
	},
}
