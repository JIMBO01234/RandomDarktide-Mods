# Writes who is talking in your Discord voice channel to a file the discord_transmission mod reads.
# Talks to the local Discord client the same way the StreamKit overlay does.

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$AliasPath = Join-Path $PSScriptRoot 'aliases.txt'
$TokenPath = Join-Path $PSScriptRoot 'token.dat'
$ImageDir = Join-Path (Split-Path $PSScriptRoot -Parent) 'images'
$ImagePorts = 41730..41739
$ImageTypes = @{ '.png' = 'image/png'; '.jpg' = 'image/jpeg'; '.jpeg' = 'image/jpeg' }
$StateDir = Join-Path $env:APPDATA 'Fatshark\Darktide'
$StatePath = Join-Path $StateDir 'discord_transmission_state.txt'
$Utf8 = New-Object System.Text.UTF8Encoding $false
$NoCancel = [Threading.CancellationToken]::None
$StreamKitClientId = '207646673902501888'
$StreamKitOrigin = 'https://streamkit.discord.com'
$StreamKitTokenUrl = 'https://streamkit.discord.com/overlay/token'
$Scopes = @('rpc', 'messages.read', 'rpc.notifications.read')
$Ports = 6463..6472
$ChannelEvents = @('SPEAKING_START', 'SPEAKING_STOP', 'VOICE_STATE_CREATE', 'VOICE_STATE_UPDATE', 'VOICE_STATE_DELETE')
$HeartbeatSeconds = 2

$script:Socket = $null
$script:Members = @{}
$script:Speaking = New-Object System.Collections.ArrayList
$script:Aliases = @{}
$script:ChannelId = $null
$script:ChannelChanged = $false
$script:Dirty = $true
$script:LastWrite = [DateTime]::MinValue
$script:MyId = $null
$script:ImageServer = $null
$script:ImagePort = $null

# aliases.txt lines: discord name = in-game name
function Read-Aliases {
	$script:Aliases = @{}

	if (-not (Test-Path $AliasPath)) {
		return
	}

	foreach ($line in Get-Content $AliasPath -Encoding UTF8) {
		if ($line -match '^\s*#' -or $line -notmatch '=') {
			continue
		}

		$key, $value = $line -split '=', 2
		$key = $key.Trim().ToLowerInvariant()
		$value = $value.Trim()

		if ($key -and $value) {
			if (-not $script:Aliases.ContainsKey($key)) {
				$script:Aliases[$key] = New-Object System.Collections.ArrayList
			}

			[void]$script:Aliases[$key].Add($value)
		}
	}
}

# The game can only load images from a url, so the images folder is served on localhost.
function Start-ImageServer {
	foreach ($port in $ImagePorts) {
		try {
			$listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, $port)
			$listener.Start()
			$script:ImageServer = $listener
			$script:ImagePort = $port

			return
		}
		catch {
		}
	}

	Write-Host "Could not start the image server, custom images are off." -ForegroundColor Yellow
}

function Send-Images {
	$server = $script:ImageServer

	if (-not $server) {
		return
	}

	while ($server.Pending()) {
		$client = $server.AcceptTcpClient()

		try {
			$client.ReceiveTimeout = 1000
			$client.SendTimeout = 2000

			$stream = $client.GetStream()
			$reader = New-Object IO.StreamReader($stream, [Text.Encoding]::ASCII)
			$request = $reader.ReadLine()

			# Read the rest of the request, closing with unread data can cut off the response.
			while ($true) {
				$line = $reader.ReadLine()

				if (-not $line) {
					break
				}
			}

			$status = '404 Not Found'
			$type = 'text/plain'
			$body = New-Object byte[] 0

			if ($request -match '^GET /([^ ?]+)') {
				$name = [Uri]::UnescapeDataString($Matches[1])
				$path = Join-Path $ImageDir $name
				$extension = [IO.Path]::GetExtension($name).ToLowerInvariant()

				if ($name -notmatch '[\\/:]|\.\.' -and $ImageTypes.ContainsKey($extension) -and (Test-Path -LiteralPath $path -PathType Leaf)) {
					$status = '200 OK'
					$type = $ImageTypes[$extension]
					$body = [IO.File]::ReadAllBytes($path)
				}
			}

			$header = $Utf8.GetBytes("HTTP/1.1 $status`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n")

			$stream.Write($header, 0, $header.Length)
			$stream.Write($body, 0, $body.Length)
		}
		catch {
		}
		finally {
			$client.Close()
		}
	}
}

# images\<discord name>.png, any of their names works.
function Find-Image($names) {
	if (-not $script:ImagePort -or -not (Test-Path $ImageDir)) {
		return $null
	}

	$files = Get-ChildItem -LiteralPath $ImageDir -File | Where-Object { $ImageTypes.ContainsKey($_.Extension.ToLowerInvariant()) }

	foreach ($name in $names) {
		$file = $files | Where-Object { $_.BaseName -ieq $name } | Select-Object -First 1

		if ($file) {
			# Changes with the file so the game doesn't keep its cached copy.
			return "http://127.0.0.1:$($script:ImagePort)/$([Uri]::EscapeDataString($file.Name))?v=$($file.LastWriteTimeUtc.Ticks)"
		}
	}

	return $null
}

function Write-State {
	$lines = New-Object System.Collections.ArrayList
	[void]$lines.Add([DateTimeOffset]::UtcNow.ToUnixTimeSeconds().ToString())

	foreach ($userId in $script:Speaking) {
		$member = $script:Members[$userId]

		if (-not $member) {
			continue
		}

		$fields = New-Object System.Collections.ArrayList
		$fields.AddRange($member.names)
		[void]$fields.Add("id=$userId")

		if ($userId -eq $script:MyId) {
			[void]$fields.Add('self=1')
		}

		$image = Find-Image $member.names

		if ($image) {
			[void]$fields.Add("img=$image")
		}

		if ($member.avatar) {
			[void]$fields.Add("avatar=$($member.avatar)")
		}

		[void]$lines.Add(($fields -join "`t"))
	}

	[void]$lines.Add('END')

	try {
		[IO.File]::WriteAllText($StatePath, ($lines -join "`n") + "`n", $Utf8)
		$script:Dirty = $false
		$script:LastWrite = [DateTime]::UtcNow
	}
	catch {
		# Game has the file open, next pass retries.
	}
}

function Update-State {
	Send-Images

	if ($script:Dirty -or ([DateTime]::UtcNow - $script:LastWrite).TotalSeconds -ge $HeartbeatSeconds) {
		Write-State
	}
}

function Clear-Voice {
	$script:Members = @{}
	$script:Speaking.Clear()
	$script:Dirty = $true
}

function Set-Member($voiceState) {
	$user = $voiceState.user

	if (-not $user -or -not $user.id) {
		return
	}

	$names = New-Object System.Collections.ArrayList

	foreach ($name in @($voiceState.nick, $user.global_name, $user.username)) {
		if ($name) {
			$clean = ([string]$name -replace '[\t\r\n]', ' ').Trim()

			if ($clean -and -not $names.Contains($clean)) {
				[void]$names.Add($clean)
			}
		}
	}

	foreach ($name in @($names)) {
		$aliases = $script:Aliases[$name.ToLowerInvariant()]

		if ($aliases) {
			foreach ($alias in $aliases) {
				if (-not $names.Contains($alias)) {
					[void]$names.Add($alias)
				}
			}
		}
	}

	if (-not $script:Members.ContainsKey([string]$user.id)) {
		Write-Host "  + $($names -join ' / ')"
	}

	$avatar = $null

	if ($user.avatar) {
		$avatar = "https://cdn.discordapp.com/avatars/$($user.id)/$($user.avatar).png?size=128"
	}

	$script:Members[[string]$user.id] = @{ names = $names; avatar = $avatar }
}

function Send-Message($payload) {
	$body = $Utf8.GetBytes(($payload | ConvertTo-Json -Compress -Depth 6))
	$segment = New-Object System.ArraySegment[byte] -ArgumentList @(, $body)

	$script:Socket.SendAsync($segment, [Net.WebSockets.WebSocketMessageType]::Text, $true, $NoCancel).Wait()
}

function Read-Message {
	$buffer = New-Object byte[] 16384
	$segment = New-Object System.ArraySegment[byte] -ArgumentList @(, $buffer)
	$stream = New-Object IO.MemoryStream

	while ($true) {
		$task = $script:Socket.ReceiveAsync($segment, $NoCancel)

		while (-not $task.Wait(100)) {
			Update-State
		}

		$result = $task.Result

		if ($result.MessageType -eq [Net.WebSockets.WebSocketMessageType]::Close) {
			throw "Discord closed the connection."
		}

		$stream.Write($buffer, 0, $result.Count)

		if ($result.EndOfMessage) {
			break
		}
	}

	return $Utf8.GetString($stream.ToArray()) | ConvertFrom-Json
}

function Receive-Event($data) {
	$payload = $data.data

	switch ($data.evt) {
		'SPEAKING_START' {
			$userId = [string]$payload.user_id

			if (-not $script:Speaking.Contains($userId)) {
				[void]$script:Speaking.Add($userId)
				$script:Dirty = $true
			}
		}
		'SPEAKING_STOP' {
			$script:Speaking.Remove([string]$payload.user_id)
			$script:Dirty = $true
		}
		'VOICE_STATE_CREATE' {
			Set-Member $payload
		}
		'VOICE_STATE_UPDATE' {
			Set-Member $payload
		}
		'VOICE_STATE_DELETE' {
			if ($payload.user -and $payload.user.id) {
				$userId = [string]$payload.user.id

				$script:Members.Remove($userId)
				$script:Speaking.Remove($userId)
				$script:Dirty = $true
			}
		}
		'VOICE_CHANNEL_SELECT' {
			$script:ChannelChanged = $true
		}
	}

	Update-State
}

function Invoke-Rpc([string]$cmd, $arguments, [string]$evt) {
	$nonce = [guid]::NewGuid().ToString()
	$payload = @{ cmd = $cmd; nonce = $nonce; args = $arguments }

	if ($evt) {
		$payload.evt = $evt
	}

	Send-Message $payload

	while ($true) {
		$data = Read-Message

		if ($data.nonce -eq $nonce) {
			if ($data.evt -eq 'ERROR') {
				throw "Discord rejected ${cmd}: $($data.data.message) (code $($data.data.code))"
			}

			return $data.data
		}

		Receive-Event $data
	}
}

# DPAPI, only readable by this Windows user.
function Save-Token([string]$accessToken) {
	$accessToken | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString | Set-Content $TokenPath -Encoding ASCII
}

function Read-Token {
	if (-not (Test-Path $TokenPath)) {
		return $null
	}

	try {
		$secure = (Get-Content $TokenPath -Raw).Trim() | ConvertTo-SecureString

		return (New-Object Net.NetworkCredential('', $secure)).Password
	}
	catch {
		return $null
	}
}

function Request-Authorization {
	Write-Host "If Discord shows an Authorize prompt for StreamKit Overlay, accept it."

	# No retry, that would spam the Authorize prompt.
	try {
		$response = Invoke-Rpc 'AUTHORIZE' @{ client_id = $StreamKitClientId; scopes = $Scopes; prompt = 'none' }
		$body = @{ code = [string]$response.code } | ConvertTo-Json -Compress
		$token = Invoke-RestMethod -Method Post -Uri $StreamKitTokenUrl -ContentType 'application/json' -Body $body

		if (-not $token.access_token) {
			throw "StreamKit returned no access token."
		}

		Save-Token $token.access_token

		return [string]$token.access_token
	}
	catch {
		Write-Host "Authorization failed: $($_.Exception.Message)" -ForegroundColor Red
		exit 1
	}
}

function Connect-Discord {
	foreach ($port in $Ports) {
		$socket = New-Object Net.WebSockets.ClientWebSocket
		$socket.Options.SetRequestHeader('Origin', $StreamKitOrigin)

		try {
			$socket.ConnectAsync([Uri]"ws://127.0.0.1:$port/?v=1&client_id=$StreamKitClientId", $NoCancel).Wait()
			$script:Socket = $socket

			break
		}
		catch {
			$socket.Dispose()
		}
	}

	if (-not $script:Socket) {
		throw "Discord is not running."
	}

	$ready = Read-Message

	if ($ready.evt -ne 'READY') {
		throw "Unexpected handshake reply from Discord."
	}

	$accessToken = Read-Token
	$auth = $null

	if ($accessToken) {
		try {
			$auth = Invoke-Rpc 'AUTHENTICATE' @{ access_token = $accessToken }
		}
		catch {
			# Saved token expired.
			if ($_.Exception.Message -notlike 'Discord rejected AUTHENTICATE*') {
				throw
			}
		}
	}

	if (-not $auth) {
		$auth = Invoke-Rpc 'AUTHENTICATE' @{ access_token = (Request-Authorization) }
	}

	$script:MyId = [string]$auth.user.id
}

function Join-Channel {
	if ($script:ChannelId) {
		foreach ($evt in $ChannelEvents) {
			try {
				[void](Invoke-Rpc 'UNSUBSCRIBE' @{ channel_id = $script:ChannelId } $evt)
			}
			catch {
			}
		}
	}

	$script:ChannelChanged = $false
	$script:ChannelId = $null
	Clear-Voice
	Read-Aliases

	$channel = Invoke-Rpc 'GET_SELECTED_VOICE_CHANNEL' @{}

	if (-not $channel -or -not $channel.id) {
		Write-Host "Not in a voice channel."
		Update-State

		return
	}

	$script:ChannelId = [string]$channel.id
	Write-Host "Listening in '$($channel.name)'."

	foreach ($voiceState in @($channel.voice_states)) {
		if ($voiceState) {
			Set-Member $voiceState
		}
	}

	foreach ($evt in $ChannelEvents) {
		[void](Invoke-Rpc 'SUBSCRIBE' @{ channel_id = $script:ChannelId } $evt)
	}

	Update-State
}

function Start-Session {
	Connect-Discord
	Write-Host "Connected to Discord."

	[void](Invoke-Rpc 'SUBSCRIBE' @{} 'VOICE_CHANNEL_SELECT')
	Join-Channel

	while ($true) {
		Receive-Event (Read-Message)

		if ($script:ChannelChanged) {
			Join-Channel
		}
	}
}

# Only one bridge at a time.
$mutex = New-Object Threading.Mutex($false, 'DarktideDiscordTransmissionBridge')

try {
	if (-not $mutex.WaitOne(0)) {
		Write-Host "The bridge is already running." -ForegroundColor Yellow
		exit 0
	}
}
catch [Threading.AbandonedMutexException] {
	# Previous bridge was killed, the mutex is ours now.
}

if (-not (Test-Path $StateDir)) {
	[void](New-Item -ItemType Directory -Force $StateDir)
}

Start-ImageServer
Write-Host "Discord Transmission bridge. Keep this window open while playing, Ctrl+C to quit."

try {
	while ($true) {
		try {
			Start-Session
		}
		catch {
			$message = $_.Exception.Message

			if ($_.Exception.InnerException) {
				$message = $_.Exception.InnerException.Message
			}

			Write-Host "$message Retrying in 5 seconds." -ForegroundColor Yellow
		}

		if ($script:Socket) {
			$script:Socket.Dispose()
			$script:Socket = $null
		}

		$script:ChannelId = $null
		Clear-Voice
		Write-State
		Start-Sleep -Seconds 5
	}
}
finally {
	Clear-Voice
	Write-State

	if ($script:ImageServer) {
		$script:ImageServer.Stop()
	}

	$mutex.ReleaseMutex()
}
