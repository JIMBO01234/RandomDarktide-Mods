return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`discord_transmission` encountered an error loading the Darktide Mod Framework.")

		new_mod("discord_transmission", {
			mod_script       = "discord_transmission/scripts/mods/discord_transmission/discord_transmission",
			mod_data         = "discord_transmission/scripts/mods/discord_transmission/discord_transmission_data",
			mod_localization = "discord_transmission/scripts/mods/discord_transmission/discord_transmission_localization",
		})
	end,
	packages = {},
}
