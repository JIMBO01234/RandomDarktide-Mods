@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = (New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup') + '\Discord Transmission bridge.lnk'); $s.TargetPath = 'powershell.exe'; $s.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%~dp0companion\discord_bridge.ps1\"'; $s.WorkingDirectory = '%~dp0'; $s.WindowStyle = 7; $s.Save(); Get-CimInstance Win32_Process -Filter \"Name = 'powershell.exe'\" | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like '*discord_bridge.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
start "" /min powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0companion\discord_bridge.ps1"
echo Done. The bridge is running in the background and will start with Windows.
echo You can close this window.
pause
