@echo off
powershell -NoProfile -Command "Remove-Item ([Environment]::GetFolderPath('Startup') + '\Discord Transmission bridge.lnk') -ErrorAction SilentlyContinue; Get-CimInstance Win32_Process -Filter \"Name = 'powershell.exe'\" | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like '*discord_bridge.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
echo Auto-start removed and the background bridge stopped.
pause
