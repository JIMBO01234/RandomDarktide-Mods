local mod = get_mod("discord_transmission")

local _io = Mods.lua.io
local _os = Mods.lua.os

-- Written by companion/discord_bridge.ps1, at least every 2 seconds.
local STATE_PATH = _os.getenv("APPDATA") .. "\\Fatshark\\Darktide\\discord_transmission_state.txt"
local POLL_INTERVAL = 0.05
local STALE_SECONDS = 10

local speakers = {}
local bridge_running = false
local active_speakers = {}
local entries = {}
local clock = 0
local poll_timer = 0

local normalize = function (name)
	if not name then
		return nil
	end

	-- Account names come with colour tags and a platform icon glyph.
	name = string.gsub(name, "{#.-}", "")
	name = string.gsub(name, "\238[\128-\191][\128-\191]", "")
	name = string.gsub(name, "^%s*(.-)%s*$", "%1")
	name = string.lower(name)

	return name ~= "" and name or nil
end

local read_state = function ()
	local file = _io.open(STATE_PATH, "r")

	if not file then
		bridge_running = false
		speakers = {}

		return
	end

	local text = file:read("*a") or ""

	file:close()

	local lines = {}

	for line in string.gmatch(text, "[^\r\n]+") do
		lines[#lines + 1] = line
	end

	local timestamp = tonumber(lines[1])

	-- Half written file, keep what we had.
	if not timestamp or lines[#lines] ~= "END" then
		return
	end

	bridge_running = _os.time() - timestamp <= STALE_SECONDS
	speakers = {}

	if not bridge_running then
		return
	end

	-- Discord names, then id=, self=, img= (custom image) and avatar= fields.
	for i = 2, #lines - 1 do
		local speaker = {
			names = {},
		}

		for field in string.gmatch(lines[i], "[^\t]+") do
			local key, value = string.match(field, "^(%a+)=(.+)$")

			if key == "id" or key == "self" or key == "img" or key == "avatar" then
				speaker[key] = value
			else
				local name = normalize(field)

				speaker.label = speaker.label or field

				if name then
					speaker.names[name] = true
				end
			end
		end

		speakers[#speakers + 1] = speaker
	end
end

local account_name = function (player)
	local account_id = player:account_id()
	local player_info = account_id and Managers.data_service.social:get_player_info_by_account_id(account_id)

	return player_info and normalize(player_info:user_display_name(true))
end

local matches_player = function (speaker, player)
	local names = speaker.names
	local character_name = normalize(player:name())
	local name = account_name(player)

	return character_name and names[character_name] or name and names[name] or false
end

local find_player = function (speaker)
	for _, player in pairs(Managers.player:human_players()) do
		if matches_player(speaker, player) then
			return player
		end
	end
end

-- nil means the operative portrait. Without an operative it falls back to the Discord picture.
local speaker_image = function (speaker, player)
	local picture = mod:get("picture")
	local image

	if picture == "custom_operative" or picture == "custom_discord" then
		image = speaker.img
	end

	if not image and (picture == "custom_discord" or picture == "discord" or not player) then
		image = speaker.avatar
	end

	return image
end

mod.active_speakers = function ()
	return active_speakers
end

mod.update = function (dt)
	clock = clock + dt
	poll_timer = poll_timer - dt

	if poll_timer > 0 then
		return
	end

	poll_timer = POLL_INTERVAL

	read_state()

	local show_self = mod:get("show_self")
	local show_discord_only = mod:get("show_discord_only")

	for i = 1, #speakers do
		local speaker = speakers[i]
		local player = find_player(speaker)
		local id = speaker.id or speaker.label

		if id and (show_self or not speaker.self) and (player or show_discord_only) then
			local entry = entries[id]

			if not entry then
				entry = {
					id = id,
				}
				entries[id] = entry
				active_speakers[#active_speakers + 1] = entry
			end

			entry.player = player
			entry.name = player and player:name() or speaker.label
			entry.image = speaker_image(speaker, player)
			entry.last_spoke = clock
		end
	end

	local hold_time = mod:get("hold_time")

	for i = #active_speakers, 1, -1 do
		local entry = active_speakers[i]

		if clock - entry.last_spoke >= hold_time then
			table.remove(active_speakers, i)

			entries[entry.id] = nil
		end
	end
end

mod.on_disabled = function ()
	active_speakers = {}
	entries = {}
end

mod:command("discord_transmission", mod:localize("command_description"), function ()
	read_state()

	if not bridge_running then
		mod:echo(mod:localize("status_no_bridge"))

		return
	end

	for i = 1, #speakers do
		local player = find_player(speakers[i])

		mod:echo(mod:localize("status_speaker", speakers[i].label, player and player:name() or "?"))
	end

	for _, player in pairs(Managers.player:human_players()) do
		mod:echo(mod:localize("status_player", tostring(player:name()), tostring(account_name(player))))
	end
end)

mod:register_hud_element({
	class_name = "HudElementDiscordTransmission",
	filename = "discord_transmission/scripts/mods/discord_transmission/hud_element_discord_transmission",
	use_hud_scale = true,
	visibility_groups = {
		"dead",
		"alive",
		"communication_wheel",
		"tactical_overlay",
	},
})
