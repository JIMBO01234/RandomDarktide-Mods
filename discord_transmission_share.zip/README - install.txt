Discord Transmission
====================
Shows an "Incoming Transmission" popup with your friend's operative when they talk in your Discord voice channel.

Install
-------
You need the Darktide Mod Loader and Darktide Mod Framework (DMF) already working.

1. Put the discord_transmission folder into Darktide's mods folder.
2. Open mods\mod_load_order.txt and add a line at the bottom: discord_transmission
3. With the Discord desktop app open, double-click autostart_install.bat (in the discord_transmission folder).
4. Discord asks you to authorize "StreamKit Overlay". Accept it. Only happens once.
5. Close the window that opened, join a voice channel and start the game.

That's it. The bridge now runs in the background with no window and starts by itself every time you
log in to Windows, so you never have to think about it again.

To turn it off, run autostart_remove.bat.

If the popups don't show up, run start_bridge.bat instead. It does the same thing in a visible window,
so you can see what the bridge is doing (it should say "Listening in '<channel>'" and list who is in
the call). Close that window when you're done and run autostart_install.bat again.

Names
-----
A friend's popup shows their operative when their Discord username, display name or server nickname
is the same as their Steam name or their character name. For everyone else add a line to
companion\aliases.txt:

    discord name = in-game name

then leave and rejoin the voice channel. Friends who aren't in your game get a popup with their
Discord profile picture instead.

Type /discord_transmission in game chat to see who the bridge hears and the exact names of the
players around you.

Images
------
To give someone your own picture, put a PNG or JPG named after their Discord username or display name
in the images folder, for example images\biscuitmomma.png.

The "Picture" mod option picks what the popup shows: custom image else operative (default), custom
image else Discord picture, always the operative, or always the Discord picture.

Settings
--------
Mod options in game: show your own transmissions, show friends who aren't in the game, picture,
hold time, position, size and opacity.

Notes
-----
- Only you see the popups. Friends who want them need the mod and the bridge too.
- The bridge uses the same local connection as Discord's StreamKit overlay. It isn't an official API
  and can break if Discord changes it.
- companion\token.dat appears after the first run and is your saved Discord login. Don't share it.
