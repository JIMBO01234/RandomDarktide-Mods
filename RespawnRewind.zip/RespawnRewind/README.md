# Respawn Rewind

A client-side Darktide (DMF) mod. While a teammate is dead or awaiting respawn, it marks where they
will respawn and the point on the path to stay behind to pull that respawn to a closer beacon. Purely
local and client-reliable: it reads only client-available data (respawn beacon units, the main path,
player state), so it works in a live mission. Darktide runs missions on dedicated servers, so
every player is a client and nobody is the server except in solo play.

## What it shows (only while a teammate is down/dead)

- **Respawn marker** (light blue, through walls): the beacon where a dead teammate will respawn, with
  distance. It is computed from the game's own selection rule (the nearest beacon far enough ahead of
  the furthest-ahead living player), so it is correct in a live mission, not only under solo play.
- **Hold-back marker** (green, through walls): the main-path point the living players should stay
  behind to pull the respawn to the nearest earlier beacon, shown as both a point+label (distance,
  through walls) and a line drawn across the path at that point (up-close, exact width). When the
  active beacon is already the earliest one, no hold-back marker is shown (there is nothing earlier to
  pull to).

## Settings (F4 mod menu)

Enabled, Show run-back point, Marker size, Markers through walls, Show distance on markers.

## How it works

Dead players respawn at a beacon the game picks by main-path distance: the nearest beacon at least 25m
of path distance ahead of the furthest-ahead living player. The mod reads the beacon units and the main
path on the client and applies the same rule, so its marker matches what the game will do. Holding the
party back lowers that furthest-ahead distance, which can pull the respawn to an earlier beacon; the
hold-back marker is the line to stay behind for that.

Three details of the game's rule that are easy to miss, all confirmed against
`respawn_beacon_system.lua`:

- **The choice is latched, not recomputed.** `fixed_update` reads
  `self._priority_respawn_beacon or self._current_active_respawn_beacon` and only calls
  `_find_optimal_beacon` when both are nil. Once a respawn has happened the beacon is frozen for the
  rest of the episode. The mod latches the same way and clears on its own episode boundary, because the
  game's clear signal (hogtied player count reaching zero) covers a different population than the
  awaiting-respawn players this mod tracks.
- **There are two rules, chosen by path type.** `_find_optimal_beacon` branches on
  `Managers.state.main_path:path_type()`. Only `"linear"` uses the main-path rule above; anything else
  uses `_find_nearest_beacon_with_distance`, which takes the beacon closest to the midpoint of the
  living squad in a straight line. `path_type` is a plain getter with no server gate, so it is readable
  here. On a non-linear path there is no point on a route to stand behind, so no hold-back marker is
  drawn.
- **Safe-zone beacons are matched, not excluded.** The game compares each beacon's `safe_zone()` against
  the system's `_safe_zone_spawn` flag, which the scripted safe-zone sections flip.

All main-path math goes through `MainPathQueries` (an `EngineOptimized` query registered on every
client). The `MainPathManager` methods (`ahead_unit`, `travel_distance_from_position`) are dead on
clients: they depend on nav spawn points that only the server builds, and Darktide missions run on
dedicated servers. The furthest-ahead distance is computed locally by projecting every living player
unit onto the path and taking the max.

### Known blind spot

`_priority_respawn_beacon` overrides everything when a mission forces a specific beacon, but
`make_respawn_beacon_priority` opens with `if not self._is_server then return end`, so on a client it is
always nil. A scripted section that forces a beacon will be mispredicted and there is no client-side
signal that it happened.

## Notes

- Refresh cadence is about 0.3s for the point markers and their labels; the drawn hold-back line is
  re-queued every real frame (see 1.3.2) so it doesn't flicker between ticks. Markers and the line
  clear on rescue/respawn and on mission end.
- No pacing prediction, no full path drawing, no offline cache. Through-wall world markers for the
  long-range signal; the hold-back threshold additionally gets a real drawn line since 1.3.2.
- **Client-side and non-cheat.** This is a publish candidate, unlike the through-wall enemy mods.

## Changelog

- **1.3.2** *(untested change — see note below)*: The hold-back marker now also draws as a line across
  the main path at the threshold, instead of only a point. The point+label marker (through-wall,
  long-range, carries the "Run back | 29m" / "Stay behind | -12m" text) is unchanged and still there;
  the line is additional, and only reads clearly up close. Uses the engine's `LineObject` debug-line
  primitive (`World.create_line_object` / `LineObject.add_line` / `LineObject.dispatch`), confirmed
  against the public Stingray engine Lua reference (the engine family this game is built on) but, unlike
  every other piece of this mod, **not** confirmed against Darktide's own decompiled scripts — this is
  new, lower-confidence ground. Every call into it is pcall-guarded and falls back to "no line, point
  marker unaffected" rather than erroring. Run `rr_line` in a live mission to see whether it actually
  drew anything and why not if it didn't.
- **1.3.1**: Stopped wrapping `HudElementWorldMarkers.update` to re-register the marker template. That
  hook ran every frame and called through to the base update, which walks every world marker the game
  and every other mod has registered, so a profiler charged all of it to this mod. Reported on Nexus as
  0.7ms/frame while the mod's own per-refresh work measures about 25 microseconds (`rr_perf`). Whether
  it appeared at all depended on load order, since a monitor can only wrap hooks from mods that load
  after it. Now hooks `_template_by_type`, which the game calls at marker-add time, costs nothing per
  frame, and is a stronger guarantee than the update hook was.
  Added a run-back safety margin setting, **defaulted to 0**. Our beacon distances cannot match the
  game's: `PathTypeLinear._information_from_position` projects onto the segment belonging to the nav
  spawn-point group a position sits in, and `nav_spawn_points()` is server-only, so the fallback is an
  unconstrained `closest_position` that lands further along. Measured 146.1 against a game value of at
  most 138.9 on one map. The margin subtracts from both the selection threshold and the hold-back line
  from one place, so the marker and the prediction cannot disagree. Left at 0 pending a measurement
  across more than one map.
- **1.3.0**: Added the map-practice layout: every respawn point and the line that governs it, shown at
  once, off by default, with toggles for the points, the lines and the numbering. Placed once per
  mission and never refreshed, so it costs nothing per tick.
  Fixed the run-back point being wrong where the route runs wide. Progress was credited only when a
  player was within `ON_PATH_MAX_OFFSET` of the route centre, and past the first beacon on one map that
  offset reads 22m, so progress froze at 91.4 while the player walked on to 127.0. The mod then fed a
  stale distance into the beacon rule and predicted a nearer respawn than the game chose. A projection
  is now believed if it is near the route OR continuous with the last credited value (within
  `MAX_STEP`), which keeps the objective-room protection intact because that failure is a jump, not a
  drift. Verified against two missions: predicted beacon 2 with a downed bot holding the team's
  furthest-ahead position, predicted beacon 1 once the living bot followed the player back, and the
  game agreed both times.
- **1.2.1**: Corrected the 1.2.0 latch. `fixed_update` reads
  `self._priority_respawn_beacon or self._current_active_respawn_beacon` before calling
  `_find_optimal_beacon`, which reads as a latch for the whole respawn, but a few lines later in the
  same tick `_update_hogtied_players` clears `_current_active_respawn_beacon` whenever the hogtied
  count is zero. So the hold survives only while somebody is hogtied; an ordinary death re-picks every
  tick from the live ahead-distance, and that live re-pick IS the hold-back mechanic. 1.2.0 froze it.
  The latch is now conditional on a hogtied player, read from the same replicated `character_state`
  component as `dead`. Also: the hold-back marker now reports a signed offset against its line with a
  switching label ("Run back | 29m" past it, "Stay behind | -12m" behind it), since the old label read
  as an instruction to travel when it was really slack. Awaiting-respawn is detected from
  `character_state.state_name == "dead"` rather than waiting for the player unit to disappear.
- **1.2.0**: Matched three parts of the game's beacon rule the mod was missing, all read from
  `respawn_beacon_system.lua`. The chosen beacon is now latched for the respawn episode instead of
  recomputed every tick: the game reads
  `self._priority_respawn_beacon or self._current_active_respawn_beacon` and only re-picks when both
  are nil, so recomputing walked the marker forward while the game stayed put. `path_type` is now
  honoured, because `_find_optimal_beacon` uses a different rule entirely on non-linear paths (nearest
  beacon to the midpoint of the living squad, no main path involved) and the mod had been applying the
  linear rule everywhere. Safe-zone beacons are matched against the system's `_safe_zone_spawn` flag
  rather than excluded outright, which is what the game does. `rr_beacons` now reports `path_type`,
  `safe_zone` and `latched`. Verified in a live run: team progress advanced from 84.8 to 189.1 while
  the marked beacon held at 146.1.
- **1.1.1**: Fixed the predicted beacon jumping forward early on maps with a locked objective room.
  Team progress was taken by projecting each player onto the nearest point of the main path, which
  answers "which bit of the route is closest to you", not "how far have you got". An objective room
  sits off the route, so a player inside one projects onto whatever path point is nearest, often well
  ahead of where they have actually reached. The game does not advance there, so the mod disagreed
  with it. Progress is now only credited when the player is demonstrably near the path, holding the
  last trusted position otherwise.
- **1.1.0**: Fixed the mod doing nothing in live missions. 1.0.0 read main-path distances through
  `MainPathManager` (`ahead_unit`, `travel_distance_from_position`), which silently return nil on
  clients because their nav-spawn-point inputs are server-only. Since live missions run on dedicated
  servers, the mod only ever worked under SoloPlay, which is how it passed testing. All main-path
  math now goes through the client-safe `MainPathQueries`, and the furthest-ahead distance is
  computed locally from living player positions. Also fixed a finiteness guard that accepted nil.
- **1.0.0**: Initial build.

## Credits

The respawn beacon model (beacon fields, the ahead-distance selection rule) was understood by reading
**RitualZones** (Nexus 687, LAUR3HTE). Implementation is original and built on the game's own systems.
If ever published, credit LAUR3HTE, check Nexus permissions, and consider a courtesy note (the same
gate as RitualDangerZones).
