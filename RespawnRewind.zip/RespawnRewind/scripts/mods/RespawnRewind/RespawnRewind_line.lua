-- Draws the hold-back threshold as an actual line across the main path, instead of only a point.
--
-- CONFIDENCE NOTE, read before touching this file: every other piece of main-path/beacon math in
-- this mod is pinned against decompiled game source (respawn_beacon_system.lua, main_path_queries).
-- This file is not. LineObject (World.create_line_object / LineObject.add_line / LineObject.dispatch
-- / LineObject.reset / World.destroy_line_object) is confirmed against the public Stingray engine Lua
-- reference -- the engine family Darktide is built on -- but has NOT been confirmed against Darktide's
-- own scripts, and Fatshark's mod sandbox may not expose all of it. Everything here is pcall-guarded
-- and degrades to "no line drawn" rather than erroring if any call is missing or behaves differently.
-- Run `rr_line` in a live mission to see what actually happened.
--
-- The world marker (icon + text label, in markers.lua) is left in place alongside this: it is the
-- through-wall, long-range, distance-labelled signal, and this line only reads clearly up close. This
-- is additive to that, not a replacement for it.

local mod = get_mod("RespawnRewind")

local Line = {}

local line_object = nil
local line_world = nil
local have_content = false -- true once add_line has succeeded for the current position/direction
local last_error = nil

local function record_error(where, err)
	last_error = string.format("%s: %s", where, tostring(err))
end

-- The world to draw in, taken from the local player's own unit so this never has to guess a world
-- name. Re-resolved on demand rather than cached across missions, since the unit (and its world) is
-- replaced on every mission load and every respawn.
local function get_world()
	local players = Managers.player
	local player = players and players.local_player and players:local_player(1)
	local unit = player and player.player_unit
	if not (unit and Unit.alive(unit)) then
		return nil
	end
	local ok, world = pcall(Unit.world, unit)
	if ok and world then
		return world
	end
	if not ok then
		record_error("Unit.world", world)
	end
	return nil
end

local function is_finite_number(n)
	return type(n) == "number" and n == n and n ~= math.huge and n ~= -math.huge
end

local function is_finite_vector(v)
	if not v or not Vector3 or not Vector3.x then
		return false
	end
	local ok, x = pcall(Vector3.x, v)
	if not ok then
		return false
	end
	return is_finite_number(x) and is_finite_number(Vector3.y(v)) and is_finite_number(Vector3.z(v))
end

-- (Re)creates the line object if we don't have one for the world we're currently in. A mission change
-- swaps the world out from under a stale line_object, so this is checked, not assumed, every call.
local function ensure_line_object()
	local world = get_world()
	if not world then
		return nil
	end
	if line_object and line_world == world then
		return line_object
	end
	if line_object and line_world then
		pcall(World.destroy_line_object, line_world, line_object)
	end
	local ok, obj = pcall(World.create_line_object, world)
	if not ok or not obj then
		if not ok then
			record_error("World.create_line_object", obj)
		end
		line_object, line_world, have_content = nil, nil, false
		return nil
	end
	line_object, line_world, have_content = obj, world, false
	return line_object
end

-- Endpoints of a line centred on `position`, spanning `width` metres, perpendicular to `direction`
-- (the path's direction of travel at that point; does not need to be normalized). Perpendicular is
-- direction x up, which is the across-the-corridor axis on a normal (non-vertical) path.
local function endpoints(position, direction, width)
	if not (is_finite_vector(position) and is_finite_vector(direction) and type(width) == "number" and width > 0) then
		return nil, nil
	end
	local ok_cross, side = pcall(Vector3.cross, direction, Vector3(0, 0, 1))
	if not ok_cross or not is_finite_vector(side) then
		return nil, nil
	end
	local ok_len, side_len = pcall(Vector3.length, side)
	if not ok_len or not is_finite_number(side_len) or side_len < 0.001 then
		return nil, nil -- direction was vertical (or unreadable): no meaningful "across" axis
	end
	local scale = (width * 0.5) / side_len
	local ok_half, half = pcall(function()
		return Vector3(Vector3.x(side) * scale, Vector3.y(side) * scale, Vector3.z(side) * scale)
	end)
	if not ok_half or not is_finite_vector(half) then
		return nil, nil
	end
	local ok_pts, from, to = pcall(function()
		return position - half, position + half
	end)
	if not ok_pts or not is_finite_vector(from) or not is_finite_vector(to) then
		return nil, nil
	end
	return from, to
end

-- Set (or move) the line. Safe to call every refresh; rebuilding a single line is cheap and this is
-- only called on the mod's throttled tick, not every frame.
function Line.set(position, direction, color, width)
	local obj = ensure_line_object()
	if not obj then
		have_content = false
		return
	end
	local from, to = endpoints(position, direction, width)
	if not from or not to then
		pcall(LineObject.reset, obj)
		have_content = false
		return
	end
	color = color or { 255, 120, 220, 120 } -- { alpha, r, g, b }, matching the rest of the mod
	local ok = pcall(function()
		LineObject.reset(obj)
		local col = Color(color[1], color[2], color[3], color[4])
		LineObject.add_line(obj, col, from, to)
	end)
	if not ok then
		record_error("LineObject.add_line", "see log")
		have_content = false
		return
	end
	have_content = true
end

function Line.clear()
	if line_object then
		pcall(LineObject.reset, line_object)
	end
	have_content = false
end

-- Full teardown: only for mod-disable / mission-end, not the ordinary per-episode clear. Destroying
-- and recreating the line object every respawn would be wasteful; Line.clear() is what runs then.
function Line.teardown()
	if line_object and line_world then
		pcall(LineObject.reset, line_object)
		pcall(World.destroy_line_object, line_world, line_object)
	end
	line_object, line_world, have_content = nil, nil, false
end

-- Lines added to a line object are not re-rendered on their own; the object has to be dispatched every
-- frame it should be visible. This is the cheap part (queueing an already-built line), so it is called
-- from the real per-frame update, not the mod's throttled tick.
function Line.render_frame()
	if not (line_object and line_world and have_content) then
		return
	end
	local ok, err = pcall(LineObject.dispatch, line_world, line_object)
	if not ok then
		record_error("LineObject.dispatch", err)
	end
end

function Line.diagnostics()
	return {
		has_world = line_world ~= nil,
		has_line_object = line_object ~= nil,
		have_content = have_content,
		last_error = last_error,
	}
end

return Line
