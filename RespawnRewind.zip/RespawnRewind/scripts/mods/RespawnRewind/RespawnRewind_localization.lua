return {
	mod_name = { en = "Respawn Rewind" },
	mod_description = { en = "While a teammate is dead or awaiting respawn, marks where they will respawn and the point to stay behind to pull the respawn to a closer beacon. Client-side." },

	enabled = { en = "Enabled" },
	show_runback = { en = "Show run-back point" },
	runback_margin = { en = "Safety margin (metres). Higher means the mod assumes the worse respawn" },
	practice_group    = { en = "Map practice" },
	practice_enabled  = { en = "Show the respawn layout" },
	practice_beacons  = { en = "Show respawn points" },
	practice_lines    = { en = "Show the lines between them" },
	practice_numbers  = { en = "Number them" },
	marker_size = { en = "Marker size" },
	through_walls = { en = "Markers through walls" },
	show_distance = { en = "Show distance on markers" },
}
