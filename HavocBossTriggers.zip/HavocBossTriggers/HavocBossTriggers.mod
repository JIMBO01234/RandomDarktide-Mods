return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`HavocBossTriggers` encountered an error loading the Darktide Mod Framework.")

		new_mod("HavocBossTriggers", {
			mod_script       = "HavocBossTriggers/scripts/mods/HavocBossTriggers/HavocBossTriggers",
			mod_data         = "HavocBossTriggers/scripts/mods/HavocBossTriggers/HavocBossTriggers_data",
			mod_localization = "HavocBossTriggers/scripts/mods/HavocBossTriggers/HavocBossTriggers_localization",
		})
	end,
	packages = {},
}
