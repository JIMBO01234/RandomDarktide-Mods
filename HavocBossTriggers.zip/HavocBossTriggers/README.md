## Why is this Mod?
Its meant for People trying to get into havoc without extensive Map and trigger Layout knowledge. This Mod will help you bring more intent into your gameplan.


## What this Mod does

- Spawn points: red for bosses, purple for daemonhosts, labelled with their section (S1, S2...)
- Trigger points on the path, with a gate drawn across it. The next one ahead is white and says NEXT.
- Boss patrol triggers in yellow (off by default), 20m before the normal trigger
- Option to show all triggers, the next one of each type, or only the single next one


## Additional Stuff to know

- A boss spawns when the lead player gets within 40m (along the main path) of its spawner.
- Side Paths get their own trigger lines on the floor. The mod scans the map in the background at mission start (can take a bit on big maps), so they show up after a few seconds. Passed triggers still get removed even if you're on a side path
- Scripted bosses (terror events, set pieces) aren't covered.
- Progress is estimated from player positions, so it can be a few metres off.
- Works on normal difficulties too if you turn off "Only in Havoc".

## Commands

- `/hbt_info` summary and debug info
- `/hbt_list` every spawner with its trigger distance
