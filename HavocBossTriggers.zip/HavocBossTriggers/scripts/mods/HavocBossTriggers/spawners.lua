-- Boss spawns come from MonsterSpawner level units (scripts/components/monster_spawner.lua).
-- Monster pacing uses at most one spawner per section and spawns it once the lead player
-- is within spawn_distance (40m) of it along the main path. Boss patrols trigger 20m earlier.
-- Which spawners get rolled is server side, so everything here is a potential spawn.

local mod = get_mod("HavocBossTriggers")

local Spawners = {}
local Progress = mod:io_dofile("HavocBossTriggers/scripts/mods/HavocBossTriggers/progress")

local COMPONENT_NAME = "MonsterSpawner"
local CONNECTION_NODE = "main_path_connection"

local SPAWN_DISTANCE, PATROL_EXTRA = 40, 20
do
	local ok, ms = pcall(require, "scripts/settings/monster/monster_settings")
	if ok and type(ms) == "table" then
		SPAWN_DISTANCE = tonumber(ms.spawn_distance) or SPAWN_DISTANCE
		PATROL_EXTRA = tonumber(ms.boss_patrol_extra_spawn_distance) or PATROL_EXTRA
	end
end

local MainPathQueries = nil
local function mpq()
	if MainPathQueries == nil then
		local ok, m = pcall(require, "scripts/utilities/main_path_queries")
		MainPathQueries = ok and m or false
	end
	return MainPathQueries or nil
end

local function is_finite_number(n)
	return type(n) == "number" and n == n and n ~= math.huge and n ~= -math.huge
end

local function path_registered(m)
	if not m or not m.is_main_path_registered then
		return false
	end
	local ok, r = pcall(m.is_main_path_registered)
	return ok and r and true or false
end

local function component_system()
	local em = Managers.state and Managers.state.extension
	if not em then
		return nil
	end
	local ok, sys = pcall(em.system, em, "component_system")
	return ok and sys or nil
end

local function box(v)
	return v and Vector3Box(v) or nil
end

-- position and travel direction on the main path at distance d
local function path_point(m, d)
	local total = nil
	if m.total_path_distance then
		local ok, t = pcall(m.total_path_distance)
		total = ok and is_finite_number(t) and t or nil
	end
	local at = math.max(d, 0)
	if total then
		at = math.min(at, total)
	end
	local ok, pos = pcall(m.position_from_distance, at)
	if not ok or not pos then
		return nil, nil
	end
	local ok_b, behind = pcall(m.position_from_distance, math.max(at - 2, 0))
	local ok_a, ahead = pcall(m.position_from_distance, at + 2)
	local dir = nil
	if ok_b and ok_a and behind and ahead then
		local ok_d, v = pcall(function()
			local diff = ahead - behind
			if Vector3.length(diff) < 0.01 then
				return nil
			end
			return Vector3.normalize(diff)
		end)
		dir = ok_d and v or nil
	end
	return box(pos), box(dir)
end

local cache = {
	system = nil,
	unit_count = -1,
	list = nil,
	sections = nil,
}

local function read_record(m, cs, unit)
	if not (unit and Unit.alive(unit)) then
		return nil
	end
	local ok_c, components = pcall(cs.get_components, cs, unit, COMPONENT_NAME)
	local comp = ok_c and type(components) == "table" and components[1] or nil
	if not comp or not comp.get_data then
		return nil
	end
	local ok_t, spawn_type = pcall(comp.get_data, comp, unit, "spawn_type")
	local ok_s, section = pcall(comp.get_data, comp, unit, "section")
	spawn_type = ok_t and spawn_type or "monsters"
	section = ok_s and tonumber(section) or nil

	local node = 1
	local ok_h, has = pcall(Unit.has_node, unit, CONNECTION_NODE)
	if ok_h and has then
		local ok_n, n = pcall(Unit.node, unit, CONNECTION_NODE)
		if ok_n and n then
			node = n
		end
	end
	local ok_p, connection = pcall(Unit.world_position, unit, node)
	local ok_w, spawn_pos = pcall(Unit.world_position, unit, 1)
	if not (ok_p and connection and ok_w and spawn_pos) then
		return nil
	end
	local ok_cp, _, travel = pcall(m.closest_position, connection)
	if not ok_cp or not is_finite_number(travel) then
		return nil
	end

	local trigger = travel - SPAWN_DISTANCE
	local trigger_pos, trigger_dir = path_point(m, trigger)
	local rec = {
		unit = unit,
		spawn_type = spawn_type,
		section = section,
		travel = travel,
		spawn_pos = box(spawn_pos),
		trigger = trigger,
		trigger_pos = trigger_pos,
		trigger_dir = trigger_dir,
	}
	if spawn_type == "monsters" then
		rec.patrol_trigger = trigger - PATROL_EXTRA
		rec.patrol_pos, rec.patrol_dir = path_point(m, rec.patrol_trigger)
	end
	return rec
end

local function build(m, cs, units)
	local list = {}
	local seen_sections = { monsters = {}, witches = {} }
	local sections = { monsters = 0, witches = 0 }
	for i = 1, #units do
		local rec = read_record(m, cs, units[i])
		if rec then
			list[#list + 1] = rec
			local bucket = seen_sections[rec.spawn_type]
			if bucket and rec.section and not bucket[rec.section] then
				bucket[rec.section] = true
				sections[rec.spawn_type] = sections[rec.spawn_type] + 1
			end
		end
	end
	table.sort(list, function(a, b)
		return a.trigger < b.trigger
	end)
	for i = 1, #list do
		list[i].index = i
	end
	return list, sections
end

function Spawners.list()
	local m = mpq()
	if not path_registered(m) then
		return nil
	end
	local cs = component_system()
	if not cs or not cs.get_units_from_component_name then
		return nil
	end
	local ok, units = pcall(cs.get_units_from_component_name, cs, COMPONENT_NAME)
	if not ok or type(units) ~= "table" then
		return nil
	end
	if cache.list and cache.system == cs and cache.unit_count == #units then
		return cache.list, cache.sections
	end
	if cache.system ~= cs then
		Progress.reset()
	end
	cache.list, cache.sections = build(m, cs, units)
	cache.system = cs
	cache.unit_count = #units
	return cache.list, cache.sections
end

function Spawners.track()
	Progress.track()
end

function Spawners.ahead()
	return Progress.ahead()
end

function Spawners.furthest()
	return Progress.furthest()
end

function Spawners.progress_method()
	return Progress.method()
end

function Spawners.havoc_data()
	local diff = Managers.state and Managers.state.difficulty
	if not diff or not diff.get_parsed_havoc_data then
		return nil
	end
	local ok, data = pcall(diff.get_parsed_havoc_data, diff)
	return ok and data or nil
end

local function range_of(v)
	if type(v) == "table" then
		return tonumber(v[1]) or 0, tonumber(v[2]) or 0
	end
	local n = tonumber(v) or 0
	return n, n
end

function Spawners.expected()
	if not Spawners.havoc_data() then
		return nil
	end
	local ok, result = pcall(function()
		local PacingTemplates = require("scripts/managers/pacing/pacing_templates")
		local templates = PacingTemplates.havoc.monster_pacing_template.challenge_templates
		local diff = Managers.state.difficulty
		local entry = diff:get_table_entry_by_challenge(templates)
		local mlo, mhi = range_of(entry.num_spawns.monsters)
		local wlo, whi = range_of(entry.num_spawns.witches)
		local add = 0
		local game_mode = Managers.state.game_mode and Managers.state.game_mode:game_mode()
		local havoc = game_mode and game_mode.extension and game_mode:extension("havoc")
		if havoc and havoc.get_modifier_value then
			add = tonumber(havoc:get_modifier_value("add_num_monsters")) or 0
		end
		local out = {
			monsters = { mlo + add, mhi + add },
			witches = { wlo, whi },
			add_num_monsters = add,
		}
		local bp = entry.boss_patrols and entry.boss_patrols.num_boss_patrols_range
		if bp then
			out.patrols = { tonumber(bp[1]) or 0, tonumber(bp[2]) or 0 }
		end
		return out
	end)
	return ok and result or nil
end

function Spawners.constants()
	return SPAWN_DISTANCE, PATROL_EXTRA
end

function Spawners.reset()
	cache.system, cache.unit_count, cache.list, cache.sections = nil, -1, nil, nil
	Progress.reset()
end

return Spawners
