local mod = get_mod("HavocBossTriggers")

local BASE = "HavocBossTriggers/scripts/mods/HavocBossTriggers/"
local Spawners = mod:io_dofile(BASE .. "spawners")
local Markers = mod:io_dofile(BASE .. "markers")
local Boundary = mod:io_dofile(BASE .. "boundary")

Boundary.init(Spawners.progress_module())
Markers.set_boundary(Boundary)

local TICK_INTERVAL = 0.3
local cooldown = 0
local clock = 0
local hidden = false
local announced_for = nil
local active = false
local current_list = nil

local function in_gameplay()
	if not (Managers.state and Managers.state.extension) then
		return false
	end
	local game_mode = Managers.state.game_mode
	if game_mode and game_mode.game_mode_name then
		local ok, name = pcall(game_mode.game_mode_name, game_mode)
		if ok and name == "hub" then
			return false
		end
	end
	return true
end

local function is_havoc()
	return Spawners.havoc_data() ~= nil
end

local markers_up = false

local function teardown()
	if active then
		Markers.teardown_all()
		markers_up = false
		Spawners.reset()
		Boundary.reset()
		current_list = nil
		announced_for = nil
		active = false
	end
end

-- keeps progress so passed triggers stay passed when shown again
local function hide_markers()
	if markers_up then
		Markers.teardown_all()
		markers_up = false
	end
end

local function range_text(r)
	if not r then
		return "?"
	end
	if r[1] == r[2] then
		return tostring(r[1])
	end
	return string.format("%d-%d", r[1], r[2])
end

local function summary(list, sections)
	local counts = { monsters = 0, witches = 0 }
	for i = 1, #list do
		local t = list[i].spawn_type
		counts[t] = (counts[t] or 0) + 1
	end
	local lines = {}
	local hd = Spawners.havoc_data()
	lines[#lines + 1] = string.format("Boss spawns%s: %d spawners / %d sections, daemonhosts: %d / %d",
		hd and hd.havoc_rank and (" (Havoc " .. tostring(hd.havoc_rank) .. ")") or "",
		counts.monsters, sections.monsters or 0, counts.witches, sections.witches or 0)
	local exp = Spawners.expected()
	if exp then
		local text = string.format("Rolls %s bosses%s, %s daemonhosts",
			range_text(exp.monsters),
			(exp.add_num_monsters or 0) > 0 and string.format(" (+%d from modifiers)", exp.add_num_monsters) or "",
			range_text(exp.witches))
		if exp.patrols then
			text = text .. string.format(", %s patrols", range_text(exp.patrols))
		end
		lines[#lines + 1] = text
	else
		lines[#lines + 1] = "Couldn't read the boss roll (see /hbt_info)"
	end
	return lines
end

mod.update = function(dt)
	if not in_gameplay() then
		teardown()
		return
	end
	if not mod:is_enabled() then
		hide_markers()
		return
	end
	if mod:get("only_havoc") ~= false and not is_havoc() then
		teardown()
		return
	end

	clock = clock + dt
	Markers.render_frame()

	if current_list and not hidden and mod:get("draw_lines") ~= false and mod:get("draw_side_lines") ~= false then
		Boundary.update(dt, current_list)
	end

	if cooldown > 0 then
		cooldown = cooldown - dt
		return
	end
	cooldown = TICK_INTERVAL

	local list, sections = Spawners.list()
	if not list then
		return
	end
	active = true
	current_list = list
	Spawners.track()
	if hidden then
		hide_markers()
		return
	end

	if announced_for ~= list and #list > 0 then
		announced_for = list
		local lines = summary(list, sections)
		for i = 1, #lines do
			mod:info(lines[i])
			if mod:get("announce") ~= false then
				mod:echo(lines[i])
			end
		end
	end

	Markers.sync(list, Spawners.furthest(), clock)
	markers_up = true
end

mod.toggle_markers = function()
	hidden = not hidden
	if hidden then
		hide_markers()
	end
	cooldown = 0
	mod:notify(hidden and "Boss triggers hidden" or "Boss triggers shown")
end

mod.on_setting_changed = function()
	cooldown = 0
end

mod.on_disabled = function()
	hide_markers()
end

mod.on_unload = function()
	teardown()
end

pcall(function()
	local function report(line)
		mod:echo(line)
		mod:info(line)
	end

	mod:command("hbt_info", "HavocBossTriggers: summary and diagnostics", function()
		report(string.format("HBT: in_gameplay=%s havoc=%s hidden=%s", tostring(in_gameplay()), tostring(is_havoc()), tostring(hidden)))
		local list, sections = Spawners.list()
		if not list then
			report("HBT: no spawners yet (main path not ready)")
			return
		end
		local lines = summary(list, sections)
		for i = 1, #lines do
			report(lines[i])
		end
		local spawn_distance, patrol_extra = Spawners.constants()
		local ahead, furthest = Spawners.ahead(), Spawners.furthest()
		report(string.format("HBT: trigger offset %d, patrol +%d, ahead=%s furthest=%s",
			spawn_distance, patrol_extra,
			ahead and string.format("%.1f", ahead) or "nil", furthest and string.format("%.1f", furthest) or "nil"))
		report("HBT: progress " .. tostring(Spawners.progress_method()))
		report("HBT: side path scan " .. Boundary.status())
		local exp = Spawners.expected()
		report(string.format("HBT: havoc data=%s, pacing template=%s%s",
			tostring(is_havoc()), tostring(exp and exp.template),
			Spawners.expected_error() and (", roll error: " .. Spawners.expected_error()) or ""))
		local placed, with_id = Markers.count()
		report(string.format("HBT: markers %d (%d on hud)", placed, with_id))
		local ld = Markers.lines_diagnostics()
		report(string.format("HBT: lines world=%s object=%s drawing=%s%s", tostring(ld.has_world),
			tostring(ld.has_line_object), tostring(ld.have_content), ld.last_error and (" error=" .. ld.last_error) or ""))
	end)

	mod:command("hbt_list", "HavocBossTriggers: list every spawner with its trigger distance", function()
		local list = Spawners.list()
		if not list then
			report("HBT: no spawner list yet.")
			return
		end
		local furthest = Spawners.furthest()
		for i = 1, #list do
			local r = list[i]
			local togo = furthest and (r.trigger - furthest) or nil
			report(string.format("HBT %2d: %-8s S%-2s at %.0f, trigger %.0f %s",
				r.index, r.spawn_type, tostring(r.section or "?"), r.travel, r.trigger,
				togo and (togo > 0 and string.format("%.0fm", togo) or "passed") or ""))
		end
	end)
end)

mod:info("HavocBossTriggers loaded.")
