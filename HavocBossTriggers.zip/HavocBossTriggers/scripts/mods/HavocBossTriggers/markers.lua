local mod = get_mod("HavocBossTriggers")

local Markers = {}

local BASE = "HavocBossTriggers/scripts/mods/HavocBossTriggers/"
local Lines = mod:io_dofile(BASE .. "lines")
local MARKER_TEMPLATE = mod:io_dofile(BASE .. "HavocBossTriggers_marker")
local MARKER_TYPE = MARKER_TEMPLATE.name

local COLORS = {
	monsters = { 255, 255, 90, 60 },
	witches  = { 255, 190, 110, 255 },
	patrols  = { 255, 255, 210, 80 },
	next     = { 255, 255, 255, 255 },
	passed   = { 150, 140, 140, 140 },
}
local TYPE_NAMES = { monsters = "Boss", witches = "Daemonhost" }
local LINE_WIDTH = 8

local ICONS = {
	skull      = "content/ui/materials/icons/difficulty/difficulty_skull_uprising",
	assistance = "content/ui/materials/hud/icons/player_assistance/player_assistance_icon",
	location   = "content/ui/materials/hud/interactions/icons/location",
	attention  = "content/ui/materials/hud/interactions/icons/attention",
	objective  = "content/ui/materials/hud/interactions/icons/objective_main",
	default    = "content/ui/materials/hud/interactions/icons/default",
}

local function ensure_template(world_markers)
	if world_markers and world_markers._marker_templates then
		world_markers._marker_templates[MARKER_TYPE] = MARKER_TEMPLATE
	end
end

mod:hook_safe(CLASS.HudElementWorldMarkers, "init", function(self)
	ensure_template(self)
end)

-- only called when a marker is added, cheaper than hooking update
mod:hook(CLASS.HudElementWorldMarkers, "_template_by_type", function(func, self, marker_type, clone)
	local templates = self._marker_templates
	if templates and marker_type == MARKER_TYPE and not templates[marker_type] then
		ensure_template(self)
	end
	return func(self, marker_type, clone)
end)

local function setting(id, default)
	local v = mod:get(id)
	if v == nil then
		return default
	end
	return v
end

local function appearance()
	return {
		size = setting("marker_size", 40),
		max_distance = setting("max_distance", 150),
		show_distance = setting("show_distance", true),
		opacity = math.max(0, math.min(100, setting("opacity", 100))) / 100,
		spawn_icon = ICONS[setting("spawn_icon", "skull")] or ICONS.skull,
		trigger_icon = ICONS[setting("trigger_icon", "attention")] or ICONS.attention,
	}
end

local state = {}

local function trigger_event(...)
	if Managers.event then
		pcall(Managers.event.trigger, Managers.event, ...)
	end
end

local function remove(key)
	local entry = state[key]
	if entry then
		if entry.id then
			trigger_event("remove_world_marker", entry.id)
		else
			entry.pending_remove = true
		end
	end
	state[key] = nil
end

-- adds sent before the HUD exists never get an id, so retry them
local RETRY_AFTER = 3.0

local function add(key, position, data, now)
	local entry = { id = nil, data = data, added_at = now }
	state[key] = entry
	local pos = Vector3(Vector3.x(position), Vector3.y(position), Vector3.z(position))
	trigger_event("add_world_marker_position", MARKER_TYPE, pos, function(marker_id)
		entry.id = marker_id
		if entry.pending_remove then
			trigger_event("remove_world_marker", marker_id)
		end
	end, data)
end

local function upsert(key, position_box, fields, look, now)
	local entry = state[key]
	if entry and not entry.id and now - (entry.added_at or now) > RETRY_AFTER then
		entry.pending_remove = true
		state[key] = nil
		entry = nil
	end
	if entry then
		local d = entry.data
		d.text, d.color, d.icon = fields.text, fields.color, fields.icon
		d.size, d.max_distance, d.show_distance = look.size, look.max_distance, look.show_distance
		d.opacity = look.opacity
		return
	end
	if not position_box then
		return
	end
	add(key, position_box:unbox(), {
		text = fields.text, color = fields.color, icon = fields.icon,
		size = look.size, max_distance = look.max_distance, show_distance = look.show_distance,
		opacity = look.opacity,
	}, now)
end

local function label(rec, what)
	local name = TYPE_NAMES[rec.spawn_type] or rec.spawn_type
	local section = rec.section and (" S" .. rec.section) or ""
	if what == "spawn" then
		return name .. section
	elseif what == "patrol" then
		return "Patrol trigger" .. section
	end
	return name .. " trigger" .. section
end

local function camera_distance_ok(pos_box, player_pos, max_distance)
	if not (pos_box and player_pos) then
		return false
	end
	local ok, d = pcall(Vector3.distance, pos_box:unbox(), player_pos)
	return ok and d <= max_distance + 30
end

local function local_player_position()
	local pm = Managers.player
	local player = pm and pm.local_player and pm:local_player(1)
	local unit = player and player.player_unit
	if unit and Unit.alive(unit) then
		local ok, pos = pcall(Unit.world_position, unit, 1)
		if ok then
			return pos
		end
	end
	return nil
end

-- user colours from the settings, defaults from COLORS
local COLOR_SETTINGS = { monsters = "color_boss", witches = "color_dh", patrols = "color_patrol", next = "color_next" }

local function channel(id, default)
	local v = tonumber(mod:get(id))
	if not v then
		return default
	end
	return math.max(0, math.min(255, math.floor(v + 0.5)))
end

local function faded(opacity)
	local out = {}
	for name, c in pairs(COLORS) do
		local prefix = COLOR_SETTINGS[name]
		local r, g, b = c[2], c[3], c[4]
		if prefix then
			r, g, b = channel(prefix .. "_r", r), channel(prefix .. "_g", g), channel(prefix .. "_b", b)
		end
		out[name] = { math.floor(c[1] * opacity + 0.5), r, g, b }
	end
	return out
end

local Boundary = nil

function Markers.set_boundary(boundary)
	Boundary = boundary
end

local current_list = nil

function Markers.sync(list, furthest, now)
	now = now or 0
	-- new mission
	if list ~= current_list then
		Markers.teardown()
		current_list = list
	end
	local look = appearance()
	local want = {
		monsters = setting("show_monsters", true),
		witches = setting("show_witches", true),
	}
	local want_patrols = setting("show_patrols", false)
	local want_spawns = setting("show_spawn_points", true)
	local want_triggers = setting("show_trigger_points", true)
	local want_lines = setting("draw_lines", true)
	local hide_passed = setting("hide_passed", true)
	local mode = setting("show_mode", "all")
	local only_next = mode == "next_each" or mode == "next_any"
	local colors = faded(look.opacity)

	-- next trigger overall, and per type for only_next
	local next_index, next_of_type, next_patrol = nil, {}, nil
	for i = 1, #list do
		local rec = list[i]
		if want[rec.spawn_type] then
			if not furthest or rec.trigger > furthest then
				next_index = next_index or rec.index
				next_of_type[rec.spawn_type] = next_of_type[rec.spawn_type] or rec.index
			end
			if want_patrols and rec.patrol_trigger and not next_patrol and (not furthest or rec.patrol_trigger > furthest) then
				next_patrol = rec.index
			end
		end
	end
	if mode == "next_any" then
		-- keep only whichever of the next trigger / next patrol trigger comes first
		local t = next_index and list[next_index].trigger
		local p = next_patrol and list[next_patrol].patrol_trigger
		next_of_type = {}
		if t and (not p or t <= p) then
			next_of_type[list[next_index].spawn_type] = next_index
			next_patrol = nil
		else
			next_index = nil
		end
	end
	if only_next then
		next_index = nil
	end

	local keep = {}
	local lines = {}
	local player_pos = want_lines and local_player_position() or nil
	local want_side = want_lines and Boundary and setting("draw_side_lines", true)
	local boundaries = {}
	local function add_boundary(key, color)
		local segs = want_side and Boundary.segments(key)
		if segs and #segs > 0 then
			boundaries[#boundaries + 1] = { segments = segs, color = color }
		end
	end

	for i = 1, #list do
		local rec = list[i]
		if want[rec.spawn_type] then
			local passed = furthest ~= nil and rec.trigger <= furthest
			local base_color = colors[rec.spawn_type] or colors.monsters
			local shown = not (passed and hide_passed)
			if only_next then
				shown = rec.index == next_of_type[rec.spawn_type]
			end
			if shown then
				local color = passed and colors.passed or base_color
				if want_spawns then
					local key = "s" .. rec.index
					keep[key] = true
					upsert(key, rec.spawn_pos, { text = label(rec, "spawn"), color = color, icon = look.spawn_icon }, look, now)
				end
				if want_triggers and rec.trigger_pos then
					local key = "t" .. rec.index
					keep[key] = true
					local is_next = rec.index == next_index
					local text = label(rec, "trigger")
					if is_next then
						text = "NEXT " .. text
					end
					upsert(key, rec.trigger_pos, {
						text = text, color = is_next and colors.next or color, icon = look.trigger_icon,
					}, look, now)
				end
				if want_lines and rec.trigger_pos and rec.trigger_dir and not passed
					and camera_distance_ok(rec.trigger_pos, player_pos, look.max_distance) then
					lines[#lines + 1] = {
						pos = rec.trigger_pos:unbox(), dir = rec.trigger_dir:unbox(),
						color = rec.index == next_index and colors.next or base_color, width = LINE_WIDTH,
					}
				end
				if not passed then
					add_boundary("t" .. rec.index, rec.index == next_index and colors.next or base_color)
				end
			end
			if want_patrols and rec.patrol_pos then
				local patrol_passed = furthest ~= nil and rec.patrol_trigger <= furthest
				local patrol_shown = not (patrol_passed and hide_passed)
				if only_next then
					patrol_shown = rec.index == next_patrol
				end
				if patrol_shown then
					local key = "p" .. rec.index
					keep[key] = true
					upsert(key, rec.patrol_pos, {
						text = label(rec, "patrol"), color = patrol_passed and colors.passed or colors.patrols,
						icon = look.trigger_icon,
					}, look, now)
					if want_lines and not patrol_passed and rec.patrol_dir
						and camera_distance_ok(rec.patrol_pos, player_pos, look.max_distance) then
						lines[#lines + 1] = {
							pos = rec.patrol_pos:unbox(), dir = rec.patrol_dir:unbox(),
							color = colors.patrols, width = LINE_WIDTH,
						}
					end
					if not patrol_passed then
						add_boundary("p" .. rec.index, colors.patrols)
					end
				end
			end
		end
	end

	for key in pairs(state) do
		if not keep[key] then
			remove(key)
		end
	end

	if #lines > 0 or #boundaries > 0 then
		Lines.set(lines, boundaries, player_pos, look.max_distance)
	else
		Lines.clear()
	end
end

function Markers.count()
	local placed, with_id = 0, 0
	for _, entry in pairs(state) do
		placed = placed + 1
		if entry.id then
			with_id = with_id + 1
		end
	end
	return placed, with_id
end

function Markers.render_frame()
	Lines.render_frame()
end

function Markers.lines_diagnostics()
	return Lines.diagnostics()
end

function Markers.teardown()
	for key in pairs(state) do
		remove(key)
	end
	Lines.clear()
end

function Markers.teardown_all()
	Markers.teardown()
	Lines.teardown()
end

return Markers
