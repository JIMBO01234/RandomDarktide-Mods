-- Team progress along the main path, done the same way the server does it
-- (path_type_linear.lua update_progress_on_path): find the nav triangle group the player
-- stands in, take the main path node that group maps to, and project between that node and
-- the next. That's what makes side routes and crossroads count properly.
--
-- The server doesn't send any of this to clients, so we build the same triangle group from
-- the client's navmesh once per mission (MainPathManager.generate_spawn_points is server only).
-- If that fails we fall back to plain projection with a jump filter.

local mod = get_mod("HavocBossTriggers")

local Progress = {}

local function try_require(path)
	local ok, m = pcall(require, path)
	return ok and m or nil
end

local MainPathQueries = try_require("scripts/utilities/main_path_queries")
local SpawnPointQueries = try_require("scripts/managers/main_path/utilities/spawn_point_queries")
local MainPathSettings = try_require("scripts/settings/main_path/main_path_settings")

local nav = nil         -- { world, group, spawn_points, map }
local nav_failed = false
local last_error = nil

local progress = {}     -- player -> last travel distance
local last_group = {}   -- player -> last nav group
local furthest = nil

local function is_finite_number(n)
	return type(n) == "number" and n == n and n ~= math.huge and n ~= -math.huge
end

local function destroy_nav()
	if nav then
		if nav.spawn_points then
			pcall(GwNavSpawnPoints.destroy, nav.spawn_points)
		end
		if nav.group then
			pcall(GwNavTriangleGroup.destroy, nav.group)
		end
	end
	nav = nil
end

-- free the nav objects before the game tears down the nav world
pcall(function()
	mod:hook(CLASS.MainPathManager, "destroy", function(func, self, ...)
		destroy_nav()
		nav_failed = false
		return func(self, ...)
	end)
end)

local function build_nav()
	if not (MainPathQueries and SpawnPointQueries and MainPathSettings) then
		last_error = "missing game modules"
		return nil
	end
	local nm = Managers.state and Managers.state.nav_mesh
	if not nm or not nm.nav_world then
		return nil
	end
	local ok, result = pcall(function()
		local nav_world = nm:nav_world()
		if not nav_world then
			return nil
		end
		local cost_table = GwNavTagLayerCostTable.create()
		local layers = MainPathSettings.triangle_group_forbidden_nav_tag_layers or {}
		for i = 1, #layers do
			local id = nm:nav_tag_layer_id(layers[i])
			if id then
				GwNavTagLayerCostTable.forbid_layer(cost_table, id)
			end
		end
		local group, _, map = SpawnPointQueries.generate_nav_triangle_group(nav_world,
			MainPathSettings.triangle_group_distance, MainPathSettings.triangle_group_cutoff_values, cost_table)
		GwNavTagLayerCostTable.destroy(cost_table)
		local spawn_points = GwNavSpawnPoints.create(nav_world, group)
		return { world = nav_world, group = group, spawn_points = spawn_points, map = map, owner = Managers.state.main_path }
	end)
	if not ok then
		last_error = tostring(result)
		return nil
	end
	return result
end

-- server method; nil if the player can't be placed in a group
local function nav_distance(player, pos)
	local ok, group = pcall(SpawnPointQueries.group_from_position, nav.world, nav.spawn_points, pos)
	if ok and group then
		last_group[player] = group
	else
		group = last_group[player]
	end
	local node = group and nav.map[group]
	if not node then
		return nil
	end
	local ok_p, _, dist = pcall(MainPathQueries.closest_position_between_nodes, pos, node, node + 1)
	if ok_p and is_finite_number(dist) then
		return dist
	end
	return nil
end

-- server-style distance for any point on the navmesh, nil if it isn't in a group
function Progress.point_distance(pos)
	if not nav then
		return nil
	end
	local ok, group = pcall(SpawnPointQueries.group_from_position, nav.world, nav.spawn_points, pos)
	local node = ok and group and nav.map[group]
	if not node then
		return nil
	end
	local ok_p, _, dist = pcall(MainPathQueries.closest_position_between_nodes, pos, node, node + 1)
	if ok_p and is_finite_number(dist) then
		return dist
	end
	return nil
end

-- nav world when the navmesh method is active (identity also tells a new mission apart)
function Progress.nav_world()
	return nav and nav.world or nil
end

-- fallback: plain projection, ignoring big jumps that happen off the route
local ON_PATH_MAX_OFFSET = 20
local MAX_STEP = 10

local function projected_distance(player, pos)
	local ok, projected, dist = pcall(MainPathQueries.closest_position, pos)
	if not ok or not is_finite_number(dist) then
		return nil
	end
	local offset = nil
	if projected then
		local ok_o, d = pcall(Vector3.distance, pos, projected)
		offset = ok_o and d or nil
	end
	local credited = progress[player]
	local on_route = (not offset) or offset <= ON_PATH_MAX_OFFSET
	local continuous = credited and math.abs(dist - credited) <= MAX_STEP
	if on_route or continuous or not credited then
		return dist
	end
	return nil
end

function Progress.track()
	if not MainPathQueries then
		return
	end
	-- built for another mission and the destroy hook didn't catch it: drop it (don't destroy,
	-- the nav world it belonged to is gone)
	if nav and nav.owner ~= (Managers.state and Managers.state.main_path) then
		nav, nav_failed = nil, false
	end
	if not nav and not nav_failed then
		nav = build_nav()
		nav_failed = nav == nil
		mod:info("progress: %s", nav and "navmesh groups" or ("fallback (" .. tostring(last_error) .. ")"))
	end
	local players = Managers.player and Managers.player:players()
	if not players then
		return
	end
	for _, player in pairs(players) do
		local unit = player.player_unit
		if unit and Unit.alive(unit) then
			local ok, pos = pcall(Unit.world_position, unit, 1)
			if ok and pos then
				local dist = nav and nav_distance(player, pos) or nil
				if not dist then
					dist = projected_distance(player, pos)
				end
				if dist then
					progress[player] = dist
					if not furthest or dist > furthest then
						furthest = dist
					end
				end
			end
		end
	end
end

function Progress.ahead()
	local players = Managers.player and Managers.player:players()
	if not players then
		return nil
	end
	local best = nil
	for _, player in pairs(players) do
		local unit = player.player_unit
		if unit and Unit.alive(unit) then
			local v = progress[player]
			if v and (not best or v > best) then
				best = v
			end
		end
	end
	return best
end

function Progress.furthest()
	return furthest
end

function Progress.method()
	if nav then
		return "navmesh"
	end
	return nav_failed and ("fallback: " .. tostring(last_error)) or "not built"
end

-- new mission or leaving gameplay
function Progress.reset()
	progress, last_group, furthest = {}, {}, nil
end

return Progress
