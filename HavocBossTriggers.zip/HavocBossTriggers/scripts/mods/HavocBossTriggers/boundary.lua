-- Where each trigger distance crosses side routes and rooms, not just the main path.
--
-- Mission navmeshes don't expose their triangle list on clients, so we crawl the walkable
-- floor with GwNavQueries.flood_fill_from_position (like Strikemap's expedition scanner),
-- bucket it into a 2m grid and give every cell the server-style path distance. A trigger's
-- boundary is every pair of neighbouring cells on opposite sides of its distance.
-- Runs a few flood calls per frame so there's no hitch.

local Boundary = {}

local Progress = nil -- set by Boundary.init, shared with spawners.lua

function Boundary.init(progress)
	Progress = progress
end

local CELL = 2.0
local Z_CELL = 2.5
local MAX_DZ = 1.5              -- neighbours further apart in height are different floors
local FLOOD_ABOVE, FLOOD_BELOW = 3, 3
local FLOOD_MAX_PER_CALL = 150
local FLOOD_CALLS_PER_FRAME = 6
local MAX_SKIPS_PER_FRAME = 400
local EXTRACT_PER_FRAME = 3000
local MAX_CELLS = 150000
local SEED_SPACING = 10
local RESEED_INTERVAL = 5

local state = nil

local function key_of(i, j, k)
	return ((k + 512) * 65536 + (j + 32768)) * 65536 + (i + 32768)
end

-- engine temp vectors pile up within a frame; reset them like the game's own nav loops do
local ScriptApi = rawget(_G, "Script")
local get_temp = ScriptApi and ScriptApi.temp_byte_count
local set_temp = ScriptApi and ScriptApi.set_temp_byte_count

local function temp_mark()
	if not get_temp then
		return nil
	end
	local ok, n = pcall(get_temp)
	return ok and n or nil
end

local function temp_reset(n)
	if n and set_temp then
		pcall(set_temp, n)
	end
end

local function new_state(nav_world, list)
	-- sorted thresholds: { value, key }
	local thresholds = {}
	for i = 1, #list do
		local r = list[i]
		thresholds[#thresholds + 1] = { r.trigger, "t" .. r.index }
		if r.patrol_trigger then
			thresholds[#thresholds + 1] = { r.patrol_trigger, "p" .. r.index }
		end
	end
	table.sort(thresholds, function(a, b)
		return a[1] < b[1]
	end)
	return {
		nav_world = nav_world,
		list = list,
		thresholds = thresholds,
		cells = {},        -- key -> cell
		order = {},        -- cells in insertion order
		frontier_head = 1, -- index into order
		extracted = 0,     -- cells checked for crossings
		segments = {},     -- threshold key -> flat { x1, y1, z1, x2, y2, z2, ... }
		seeded = false,
		reseed_t = 0,
		flood_ok = nil,
		num_segments = 0,
	}
end

-- adds a sampled floor point; the distance is read while the vector is still valid
local function visit(s, pos)
	local x, y, z = pos.x, pos.y, pos.z
	local i, j, k = math.floor(x / CELL), math.floor(y / CELL), math.floor(z / Z_CELL)
	local key = key_of(i, j, k)
	if s.cells[key] then
		return
	end
	if #s.order >= MAX_CELLS then
		return
	end
	local cell = { x = x, y = y, z = z, i = i, j = j, k = k, d = Progress.point_distance(pos) }
	s.cells[key] = cell
	s.order[#s.order + 1] = cell
	cell.idx = #s.order
end

local function seed(s)
	local mpq = require("scripts/utilities/main_path_queries")
	local ok, total = pcall(mpq.total_path_distance)
	if ok and type(total) == "number" then
		local d = 0
		while d <= total do
			local mark = temp_mark()
			local ok_p, pos = pcall(mpq.position_from_distance, d)
			if ok_p and pos then
				visit(s, pos)
			end
			temp_reset(mark)
			d = d + SEED_SPACING
		end
	end
	s.seeded = true
end

local function reseed_from_players(s)
	local players = Managers.player and Managers.player:players()
	if not players then
		return
	end
	for _, player in pairs(players) do
		local unit = player.player_unit
		if unit and Unit.alive(unit) then
			local mark = temp_mark()
			local ok, pos = pcall(Unit.world_position, unit, 1)
			if ok and pos then
				visit(s, pos)
			end
			temp_reset(mark)
		end
	end
end

-- flooding from a cell whose neighbours are all known finds nothing new
local function is_interior(s, cell)
	local cells = s.cells
	for dk = -1, 1 do
		local k = cell.k + dk
		if cells[key_of(cell.i + 1, cell.j, k)] and cells[key_of(cell.i - 1, cell.j, k)]
			and cells[key_of(cell.i, cell.j + 1, k)] and cells[key_of(cell.i, cell.j - 1, k)] then
			return true
		end
	end
	return false
end

local flood_out = {}

local function flood_step(s)
	local queries = rawget(_G, "GwNavQueries")
	local flood_fill = queries and queries.flood_fill_from_position
	if not flood_fill then
		s.flood_ok = false
		return
	end
	local calls, skips = 0, 0
	while calls < FLOOD_CALLS_PER_FRAME and skips < MAX_SKIPS_PER_FRAME do
		local cell = s.order[s.frontier_head]
		if not cell then
			return
		end
		s.frontier_head = s.frontier_head + 1
		if is_interior(s, cell) then
			skips = skips + 1
			goto continue
		end
		calls = calls + 1
		for n = #flood_out, 1, -1 do
			flood_out[n] = nil
		end
		local mark = temp_mark()
		local ok, count = pcall(flood_fill, s.nav_world,
			Vector3(cell.x, cell.y, cell.z), FLOOD_ABOVE, FLOOD_BELOW, FLOOD_MAX_PER_CALL, flood_out)
		if ok and count then
			s.flood_ok = true
			for n = 1, count do
				local p = flood_out[n]
				if p then
					visit(s, p)
				end
			end
		elseif s.flood_ok == nil then
			s.flood_ok = false
		end
		temp_reset(mark)
		::continue::
	end
end

-- first threshold index with value > v
local function first_above(thresholds, v)
	local lo, hi = 1, #thresholds + 1
	while lo < hi do
		local mid = math.floor((lo + hi) / 2)
		if thresholds[mid][1] > v then
			hi = mid
		else
			lo = mid + 1
		end
	end
	return lo
end

local function add_crossings(s, a, b)
	local da, db = a.d, b.d
	if not (da and db) or da == db then
		return
	end
	-- no smoothness check: the server's distance also jumps at nav group borders, and a
	-- trigger inside a jump really does fire at that border
	local lo, hi = math.min(da, db), math.max(da, db)
	local thresholds = s.thresholds
	local n = first_above(thresholds, lo)
	while n <= #thresholds and thresholds[n][1] <= hi do
		local t = thresholds[n]
		-- segment across the gap between the two cells, where the distance equals t
		local f = (t[1] - da) / (db - da)
		local mx, my, mz = a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f, a.z + (b.z - a.z) * f
		local dx, dy = b.x - a.x, b.y - a.y
		local len = math.sqrt(dx * dx + dy * dy)
		if len > 0.01 then
			local half = CELL * 0.5 / len
			local px, py = -dy * half, dx * half
			local segs = s.segments[t[2]]
			if not segs then
				segs = {}
				s.segments[t[2]] = segs
			end
			local c = #segs
			segs[c + 1], segs[c + 2], segs[c + 3] = mx - px, my - py, mz
			segs[c + 4], segs[c + 5], segs[c + 6] = mx + px, my + py, mz
			s.num_segments = s.num_segments + 1
		end
		n = n + 1
	end
end

-- the neighbour one cell over in (di, dj) on the same floor, if it was added before this cell
local function earlier_neighbour(s, cell, di, dj)
	local best, best_dz = nil, MAX_DZ
	for dk = -1, 1 do
		local other = s.cells[key_of(cell.i + di, cell.j + dj, cell.k + dk)]
		if other and other.idx < cell.idx then
			local dz = math.abs(other.z - cell.z)
			if dz < best_dz then
				best, best_dz = other, dz
			end
		end
	end
	return best
end

local DIRS = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } }

local function extract_step(s)
	local limit = math.min(#s.order, s.extracted + EXTRACT_PER_FRAME)
	for n = s.extracted + 1, limit do
		local cell = s.order[n]
		if cell.d then
			for _, dir in ipairs(DIRS) do
				local other = earlier_neighbour(s, cell, dir[1], dir[2])
				if other then
					add_crossings(s, cell, other)
				end
			end
		end
	end
	s.extracted = limit
end

-- every frame while enabled
function Boundary.update(dt, list)
	local nav_world = Progress and Progress.nav_world()
	if not nav_world or not list then
		return
	end
	if not state or state.nav_world ~= nav_world or state.list ~= list then
		state = new_state(nav_world, list)
	end
	local s = state
	if s.flood_ok == false then
		return
	end
	if not s.seeded then
		seed(s)
	end
	s.reseed_t = s.reseed_t - dt
	if s.reseed_t <= 0 then
		s.reseed_t = RESEED_INTERVAL
		reseed_from_players(s)
	end
	flood_step(s)
	if s.extracted < #s.order then
		extract_step(s)
	end
end

function Boundary.segments(key)
	return state and state.segments[key] or nil
end

function Boundary.status()
	if not state then
		return "not started"
	end
	if state.flood_ok == false then
		return "flood fill not available"
	end
	local crawling = state.frontier_head <= #state.order
	return string.format("%s, %d cells, %d segments", crawling and "scanning" or "done",
		#state.order, state.num_segments)
end

function Boundary.reset()
	state = nil
end

return Boundary
