local mod = get_mod("HavocBossTriggers")

local function icon_options()
	return {
		{ text = "icon_skull",      value = "skull" },
		{ text = "icon_attention",  value = "attention" },
		{ text = "icon_location",   value = "location" },
		{ text = "icon_objective",  value = "objective" },
		{ text = "icon_assistance", value = "assistance" },
		{ text = "icon_default",    value = "default" },
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{ setting_id = "only_havoc", type = "checkbox", default_value = true },
			{
				setting_id = "toggle_key", type = "keybind", default_value = {},
				keybind_trigger = "pressed", keybind_type = "function_call", function_name = "toggle_markers",
			},
			{
				setting_id = "what_group", type = "group",
				sub_widgets = {
					{ setting_id = "show_monsters",    type = "checkbox", default_value = true },
					{ setting_id = "show_witches",     type = "checkbox", default_value = true },
					{ setting_id = "show_patrols",     type = "checkbox", default_value = false },
					{ setting_id = "show_spawn_points", type = "checkbox", default_value = true },
					{ setting_id = "show_trigger_points", type = "checkbox", default_value = true },
					{ setting_id = "draw_lines",       type = "checkbox", default_value = true },
					{ setting_id = "hide_passed",      type = "checkbox", default_value = true },
					{
						setting_id = "show_mode", type = "dropdown", default_value = "all",
						options = {
							{ text = "mode_all",       value = "all" },
							{ text = "mode_next_each", value = "next_each" },
							{ text = "mode_next_any",  value = "next_any" },
						},
					},
					{ setting_id = "announce",         type = "checkbox", default_value = true },
				},
			},
			{
				setting_id = "look_group", type = "group",
				sub_widgets = {
					{ setting_id = "max_distance",  type = "numeric",  default_value = 150, range = { 20, 400 } },
					{ setting_id = "marker_size",   type = "numeric",  default_value = 40,  range = { 8, 124 } },
					{ setting_id = "opacity",       type = "numeric",  default_value = 100, range = { 10, 100 } },
					{ setting_id = "show_distance", type = "checkbox", default_value = true },
					{ setting_id = "spawn_icon",    type = "dropdown", default_value = "skull",     options = icon_options() },
					{ setting_id = "trigger_icon",  type = "dropdown", default_value = "attention", options = icon_options() },
				},
			},
		},
	},
}
