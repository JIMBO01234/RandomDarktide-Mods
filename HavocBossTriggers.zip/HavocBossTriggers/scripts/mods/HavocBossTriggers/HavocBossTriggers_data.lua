local mod = get_mod("HavocBossTriggers")

-- regular missions from the game's own templates, named with the game's own text (same approach as SoloPlay)
local function mission_list()
	local ok, templates = pcall(require, "scripts/settings/mission/mission_templates")
	if not ok or type(templates) ~= "table" then
		return {}
	end
	local havoc = {}
	local ok_h, havoc_settings = pcall(require, "scripts/settings/havoc_settings")
	if ok_h and havoc_settings and havoc_settings.missions then
		for _, ids in pairs(havoc_settings.missions) do
			for _, id in ipairs(ids) do
				havoc[id] = true
			end
		end
	end
	local list = {}
	for id, mission in pairs(templates) do
		if mission.game_mode_name == "coop_complete_objective" then
			local ok_n, name = pcall(Localize, mission.mission_name)
			if not ok_n or type(name) ~= "string" or name == "" or name:find("^<") then
				name = id
			end
			list[#list + 1] = { id = id, name = name, havoc = havoc[id] == true }
		end
	end
	table.sort(list, function(a, b)
		if a.havoc ~= b.havoc then
			return a.havoc
		end
		return a.name:lower() < b.name:lower()
	end)
	return list
end

local function map_toggles()
	local out = {}
	for _, m in ipairs(mission_list()) do
		out[#out + 1] = { setting_id = "map_" .. m.id, type = "checkbox", default_value = true }
	end
	return out
end

local function icon_options()
	return {
		{ text = "icon_skull",      value = "skull" },
		{ text = "icon_attention",  value = "attention" },
		{ text = "icon_location",   value = "location" },
		{ text = "icon_objective",  value = "objective" },
		{ text = "icon_assistance", value = "assistance" },
		{ text = "icon_default",    value = "default" },
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{ setting_id = "only_havoc", tab = "General", type = "checkbox", default_value = true },
			{
				setting_id = "toggle_key", tab = "General", type = "keybind", default_value = {},
				keybind_trigger = "pressed", keybind_type = "function_call", function_name = "toggle_markers",
			},
			{
				setting_id = "what_group", tab = "Show", type = "group",
				sub_widgets = {
					{ setting_id = "show_monsters",    type = "checkbox", default_value = true },
					{ setting_id = "show_witches",     type = "checkbox", default_value = true },
					{ setting_id = "show_patrols",     type = "checkbox", default_value = false },
					{ setting_id = "show_spawn_points", type = "checkbox", default_value = true },
					{ setting_id = "show_trigger_points", type = "checkbox", default_value = true },
					{ setting_id = "draw_lines",       type = "checkbox", default_value = true },
					{ setting_id = "draw_side_lines",  type = "checkbox", default_value = true },
					{ setting_id = "hide_passed",      type = "checkbox", default_value = true },
					{
						setting_id = "show_mode", type = "dropdown", default_value = "all",
						options = {
							{ text = "mode_all",       value = "all" },
							{ text = "mode_next_each", value = "next_each" },
							{ text = "mode_next_any",  value = "next_any" },
						},
					},
					{ setting_id = "announce",         type = "checkbox", default_value = false },
				},
			},
			{
				setting_id = "look_group", tab = "Appearance", type = "group",
				sub_widgets = {
					{ setting_id = "max_distance",  type = "numeric",  default_value = 150, range = { 20, 400 } },
					{ setting_id = "marker_size",   type = "numeric",  default_value = 40,  range = { 8, 124 } },
					{ setting_id = "opacity",       type = "numeric",  default_value = 100, range = { 10, 100 } },
					{ setting_id = "show_distance", type = "checkbox", default_value = true },
					{ setting_id = "spawn_icon",    type = "dropdown", default_value = "skull",     options = icon_options() },
					{ setting_id = "trigger_icon",  type = "dropdown", default_value = "attention", options = icon_options() },
				},
			},
			{
				setting_id = "color_boss", tab = "Colours", type = "group",
				sub_widgets = {
					{ setting_id = "color_boss_r", type = "numeric", default_value = 255, range = { 0, 255 } },
					{ setting_id = "color_boss_g", type = "numeric", default_value = 90, range = { 0, 255 } },
					{ setting_id = "color_boss_b", type = "numeric", default_value = 60, range = { 0, 255 } },
				},
			},
			{
				setting_id = "color_dh", tab = "Colours", type = "group",
				sub_widgets = {
					{ setting_id = "color_dh_r", type = "numeric", default_value = 190, range = { 0, 255 } },
					{ setting_id = "color_dh_g", type = "numeric", default_value = 110, range = { 0, 255 } },
					{ setting_id = "color_dh_b", type = "numeric", default_value = 255, range = { 0, 255 } },
				},
			},
			{
				setting_id = "color_patrol", tab = "Colours", type = "group",
				sub_widgets = {
					{ setting_id = "color_patrol_r", type = "numeric", default_value = 255, range = { 0, 255 } },
					{ setting_id = "color_patrol_g", type = "numeric", default_value = 210, range = { 0, 255 } },
					{ setting_id = "color_patrol_b", type = "numeric", default_value = 80, range = { 0, 255 } },
				},
			},
			{
				setting_id = "color_next", tab = "Colours", type = "group",
				sub_widgets = {
					{ setting_id = "color_next_r", type = "numeric", default_value = 255, range = { 0, 255 } },
					{ setting_id = "color_next_g", type = "numeric", default_value = 255, range = { 0, 255 } },
					{ setting_id = "color_next_b", type = "numeric", default_value = 255, range = { 0, 255 } },
				},
			},
			{ setting_id = "maps_group", tab = "Maps", type = "group", sub_widgets = map_toggles() },
		},
	},
}
