-- the template is cloned per marker, so max_distance can be set per marker from data
local UIWidget = require("scripts/managers/ui/ui_widget")

local template = {}

local DEFAULT_ICON = "content/ui/materials/icons/difficulty/difficulty_skull_uprising"
local DEFAULT_ICON_COLOR = { 255, 255, 90, 60 }
local DEFAULT_TEXT_COLOR = { 255, 255, 255, 255 }

template.name = "havoc_boss_triggers"
template.size = { 40, 40 }
template.unit_node = 1
template.max_distance = 150
template.min_distance = 0
template.position_offset = { 0, 0, 1.5 }
template.check_line_of_sight = false
template.screen_clamp = false
template.screen_margins = { 0.05, 0.05 }

-- (sic) the game's spelling
template.create_widget_defintion = function(self, scenegraph_id)
	local size = self.size
	return UIWidget.create_definition({
		{
			pass_type = "texture",
			style_id = "icon",
			value = DEFAULT_ICON,
			value_id = "icon",
			style = {
				horizontal_alignment = "center",
				vertical_alignment = "center",
				size = { size[1], size[2] },
				default_size = { size[1], size[2] },
				offset = { 0, 0, 0 },
				color = DEFAULT_ICON_COLOR,
			},
			visibility_function = function(content)
				return content.icon ~= nil
			end,
		},
		{
			pass_type = "text",
			style_id = "label",
			value_id = "label",
			value = "",
			style = {
				horizontal_alignment = "center",
				vertical_alignment = "top",
				text_horizontal_alignment = "center",
				text_vertical_alignment = "center",
				font_type = "proxima_nova_bold",
				font_size = 18,
				text_color = DEFAULT_TEXT_COLOR,
				default_text_color = DEFAULT_TEXT_COLOR,
				offset = { 0, size[2] * 0.5 + 4, 1 },
				size = { 280, 24 },
			},
		},
	}, scenegraph_id)
end

local function apply_size(widget, size)
	local icon_style = widget.style.icon
	local current = icon_style.size
	if current[1] == size and current[2] == size then
		return
	end
	current[1], current[2] = size, size
	if icon_style.default_size then
		icon_style.default_size[1], icon_style.default_size[2] = size, size
	end
	local label_offset = widget.style.label.offset
	if label_offset then
		label_offset[2] = size * 0.5 + 4
	end
end

local function apply_data(widget, marker, instance)
	local data = marker.data or {}
	widget.content.icon = data.icon or DEFAULT_ICON
	widget.style.icon.color = data.color or DEFAULT_ICON_COLOR
	if type(data.size) == "number" then
		apply_size(widget, data.size)
	end
	if instance and type(data.max_distance) == "number" then
		instance.max_distance = data.max_distance
	end
	local opacity = type(data.opacity) == "number" and data.opacity or 1
	local label_style = widget.style.label
	if label_style.text_color == DEFAULT_TEXT_COLOR then
		label_style.text_color = { 255, 255, 255, 255 }
	end
	label_style.text_color[1] = math.floor(255 * opacity + 0.5)
	local text = data.text or ""
	local d = marker.distance
	if data.show_distance and type(d) == "number" then
		text = string.format("%s | %.0fm", text, d)
	end
	widget.content.label = text
end

template.on_enter = function(widget, marker, instance)
	apply_data(widget, marker, instance or marker.template)
end

template.update_function = function(_parent, _ui_renderer, widget, marker, instance, _dt, _t)
	apply_data(widget, marker, instance)
	return false
end

return template
