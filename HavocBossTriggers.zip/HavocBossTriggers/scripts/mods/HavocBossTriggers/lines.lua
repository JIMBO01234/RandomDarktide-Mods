-- trigger gates drawn with LineObject

local Lines = {}

local line_object, line_world = nil, nil
local have_content = false
local last_error = nil

local function record_error(where, err)
	last_error = string.format("%s: %s", where, tostring(err))
end

local function get_world()
	local pm = Managers.player
	local player = pm and pm.local_player and pm:local_player(1)
	local unit = player and player.player_unit
	if not (unit and Unit.alive(unit)) then
		return nil
	end
	local ok, world = pcall(Unit.world, unit)
	return ok and world or nil
end

local function ensure()
	local world = get_world()
	if not world then
		return nil
	end
	if line_object and line_world == world then
		return line_object
	end
	if line_object and line_world then
		pcall(World.destroy_line_object, line_world, line_object)
	end
	local ok, obj = pcall(World.create_line_object, world)
	if not ok or not obj then
		record_error("World.create_line_object", obj)
		line_object, line_world, have_content = nil, nil, false
		return nil
	end
	line_object, line_world, have_content = obj, world, false
	return obj
end

local MAX_BOUNDARY_SEGMENTS = 2500

-- engine temp vectors pile up within a frame; reset them like the game's own nav loops do
local ScriptApi = rawget(_G, "Script")
local get_temp = ScriptApi and ScriptApi.temp_byte_count
local set_temp = ScriptApi and ScriptApi.set_temp_byte_count

local function temp_mark()
	if not get_temp then
		return nil
	end
	local ok, n = pcall(get_temp)
	return ok and n or nil
end

local function temp_reset(n)
	if n and set_temp then
		pcall(set_temp, n)
	end
end

-- boundary segments: flat { x1, y1, z1, x2, y2, z2, ... } drawn on the floor and 1m up
local function add_boundaries(obj, boundaries, center, max_distance)
	local cx, cy, cz = center.x, center.y, center.z
	local max_sq = max_distance * max_distance
	local drawn = 0
	for i = 1, #boundaries do
		local b = boundaries[i]
		local segs, c = b.segments, b.color
		local col = Color(c[1], c[2], c[3], c[4])
		for n = 1, #segs, 6 do
			local x1, y1, z1, x2, y2, z2 = segs[n], segs[n + 1], segs[n + 2], segs[n + 3], segs[n + 4], segs[n + 5]
			local dx, dy, dz = x1 - cx, y1 - cy, z1 - cz
			if dx * dx + dy * dy + dz * dz <= max_sq then
				local mark = temp_mark()
				LineObject.add_line(obj, col, Vector3(x1, y1, z1 + 0.15), Vector3(x2, y2, z2 + 0.15))
				LineObject.add_line(obj, col, Vector3(x1, y1, z1 + 1), Vector3(x2, y2, z2 + 1))
				temp_reset(mark)
				drawn = drawn + 1
				if drawn >= MAX_BOUNDARY_SEGMENTS then
					return drawn
				end
			end
		end
	end
	return drawn
end

-- lines: { pos, dir, color, width }
-- boundaries (optional): { segments = flat array, color }, only drawn within max_distance of center
function Lines.set(lines, boundaries, center, max_distance)
	local obj = ensure()
	if not obj then
		have_content = false
		return
	end
	local ok, err = pcall(function()
		LineObject.reset(obj)
		local up = Vector3(0, 0, 1)
		local count = 0
		for i = 1, #lines do
			local l = lines[i]
			local side = Vector3.cross(l.dir, up)
			local len = Vector3.length(side)
			if len > 0.001 then
				local half = side * ((l.width * 0.5) / len)
				local c = l.color
				local col = Color(c[1], c[2], c[3], c[4])
				local base = l.pos + Vector3(0, 0, 0.1)
				local a, b = base - half, base + half
				local lift = Vector3(0, 0, 2)
				LineObject.add_line(obj, col, a, b)
				LineObject.add_line(obj, col, a + lift, b + lift)
				LineObject.add_line(obj, col, a, a + lift)
				LineObject.add_line(obj, col, b, b + lift)
				count = count + 1
			end
		end
		if boundaries and center and #boundaries > 0 then
			count = count + add_boundaries(obj, boundaries, center, max_distance or 150)
		end
		have_content = count > 0
	end)
	if not ok then
		record_error("LineObject.add_line", err)
		have_content = false
	end
end

function Lines.clear()
	if line_object then
		pcall(LineObject.reset, line_object)
	end
	have_content = false
end

function Lines.teardown()
	if line_object and line_world then
		pcall(LineObject.reset, line_object)
		pcall(World.destroy_line_object, line_world, line_object)
	end
	line_object, line_world, have_content = nil, nil, false
end

-- has to run every frame
function Lines.render_frame()
	if not (line_object and line_world and have_content) then
		return
	end
	local ok, err = pcall(LineObject.dispatch, line_world, line_object)
	if not ok then
		record_error("LineObject.dispatch", err)
	end
end

function Lines.diagnostics()
	return {
		has_world = line_world ~= nil,
		has_line_object = line_object ~= nil,
		have_content = have_content,
		last_error = last_error,
	}
end

return Lines
