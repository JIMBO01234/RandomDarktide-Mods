-- trigger gates drawn with LineObject

local Lines = {}

local line_object, line_world = nil, nil
local have_content = false
local last_error = nil

local function record_error(where, err)
	last_error = string.format("%s: %s", where, tostring(err))
end

local function get_world()
	local pm = Managers.player
	local player = pm and pm.local_player and pm:local_player(1)
	local unit = player and player.player_unit
	if not (unit and Unit.alive(unit)) then
		return nil
	end
	local ok, world = pcall(Unit.world, unit)
	return ok and world or nil
end

local function ensure()
	local world = get_world()
	if not world then
		return nil
	end
	if line_object and line_world == world then
		return line_object
	end
	if line_object and line_world then
		pcall(World.destroy_line_object, line_world, line_object)
	end
	local ok, obj = pcall(World.create_line_object, world)
	if not ok or not obj then
		record_error("World.create_line_object", obj)
		line_object, line_world, have_content = nil, nil, false
		return nil
	end
	line_object, line_world, have_content = obj, world, false
	return obj
end

-- lines: { pos, dir, color, width }
function Lines.set(lines)
	local obj = ensure()
	if not obj then
		have_content = false
		return
	end
	local ok, err = pcall(function()
		LineObject.reset(obj)
		local up = Vector3(0, 0, 1)
		local count = 0
		for i = 1, #lines do
			local l = lines[i]
			local side = Vector3.cross(l.dir, up)
			local len = Vector3.length(side)
			if len > 0.001 then
				local half = side * ((l.width * 0.5) / len)
				local c = l.color
				local col = Color(c[1], c[2], c[3], c[4])
				local base = l.pos + Vector3(0, 0, 0.1)
				local a, b = base - half, base + half
				local lift = Vector3(0, 0, 2)
				LineObject.add_line(obj, col, a, b)
				LineObject.add_line(obj, col, a + lift, b + lift)
				LineObject.add_line(obj, col, a, a + lift)
				LineObject.add_line(obj, col, b, b + lift)
				count = count + 1
			end
		end
		have_content = count > 0
	end)
	if not ok then
		record_error("LineObject.add_line", err)
		have_content = false
	end
end

function Lines.clear()
	if line_object then
		pcall(LineObject.reset, line_object)
	end
	have_content = false
end

function Lines.teardown()
	if line_object and line_world then
		pcall(LineObject.reset, line_object)
		pcall(World.destroy_line_object, line_world, line_object)
	end
	line_object, line_world, have_content = nil, nil, false
end

-- has to run every frame
function Lines.render_frame()
	if not (line_object and line_world and have_content) then
		return
	end
	local ok, err = pcall(LineObject.dispatch, line_world, line_object)
	if not ok then
		record_error("LineObject.dispatch", err)
	end
end

function Lines.diagnostics()
	return {
		has_world = line_world ~= nil,
		has_line_object = line_object ~= nil,
		have_content = have_content,
		last_error = last_error,
	}
end

return Lines
