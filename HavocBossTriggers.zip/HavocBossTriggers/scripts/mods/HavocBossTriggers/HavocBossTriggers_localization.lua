-- regular missions from the game's own templates, named with the game's own text (same approach as SoloPlay)
local function mission_list()
	local ok, templates = pcall(require, "scripts/settings/mission/mission_templates")
	if not ok or type(templates) ~= "table" then
		return {}
	end
	local havoc = {}
	local ok_h, havoc_settings = pcall(require, "scripts/settings/havoc_settings")
	if ok_h and havoc_settings and havoc_settings.missions then
		for _, ids in pairs(havoc_settings.missions) do
			for _, id in ipairs(ids) do
				havoc[id] = true
			end
		end
	end
	local list = {}
	for id, mission in pairs(templates) do
		if mission.game_mode_name == "coop_complete_objective" then
			local ok_n, name = pcall(Localize, mission.mission_name)
			if not ok_n or type(name) ~= "string" or name == "" or name:find("^<") then
				name = id
			end
			list[#list + 1] = { id = id, name = name, havoc = havoc[id] == true }
		end
	end
	table.sort(list, function(a, b)
		if a.havoc ~= b.havoc then
			return a.havoc
		end
		return a.name:lower() < b.name:lower()
	end)
	return list
end

local loc = {
	mod_name = { en = "Havoc Boss Triggers" },
	mod_description = { en = "Shows where bosses can spawn and where on the path they get triggered." },

	only_havoc = { en = "Only in Havoc" },
	toggle_key = { en = "Toggle markers" },

	what_group = { en = "Show" },
	show_monsters = { en = "Bosses" },
	show_witches = { en = "Daemonhosts" },
	show_patrols = { en = "Boss patrol triggers" },
	show_spawn_points = { en = "Spawn points" },
	show_trigger_points = { en = "Trigger points" },
	draw_lines = { en = "Trigger lines" },
	draw_side_lines = { en = "Trigger lines on side paths" },
	hide_passed = { en = "Hide passed triggers" },
	show_mode = { en = "Which triggers" },
	mode_all = { en = "All" },
	mode_next_each = { en = "Next of each type" },
	mode_next_any = { en = "Only the next one" },
	announce = { en = "Chat summary on mission start" },

	look_group = { en = "Appearance" },
	max_distance = { en = "Draw distance" },
	marker_size = { en = "Marker size" },
	opacity = { en = "Opacity (markers and lines)" },
	show_distance = { en = "Show distance" },
	spawn_icon = { en = "Spawn icon" },
	trigger_icon = { en = "Trigger icon" },
	icon_skull = { en = "Skull" },
	icon_attention = { en = "Attention" },
	icon_location = { en = "Location" },
	icon_objective = { en = "Objective" },
	icon_assistance = { en = "Assistance" },
	icon_default = { en = "Plain" },

	color_boss = { en = "Boss colour" },
	color_boss_r = { en = "Red" },
	color_boss_g = { en = "Green" },
	color_boss_b = { en = "Blue" },
	color_dh = { en = "Daemonhost colour" },
	color_dh_r = { en = "Red" },
	color_dh_g = { en = "Green" },
	color_dh_b = { en = "Blue" },
	color_patrol = { en = "Boss patrol colour" },
	color_patrol_r = { en = "Red" },
	color_patrol_g = { en = "Green" },
	color_patrol_b = { en = "Blue" },
	color_next = { en = "NEXT colour (only used with Which triggers: All)" },
	color_next_r = { en = "Red" },
	color_next_g = { en = "Green" },
	color_next_b = { en = "Blue" },

	maps_group = { en = "Maps (untick to turn the mod off on that map)" },
}

for _, m in ipairs(mission_list()) do
	loc["map_" .. m.id] = { en = m.havoc and string.format("%s (%s)", m.name, m.id) or string.format("%s (%s, not in Havoc)", m.name, m.id) }
end

return loc
