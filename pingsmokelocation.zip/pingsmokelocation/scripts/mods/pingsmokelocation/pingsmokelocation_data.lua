local mod = get_mod("PingSmokeLocation")

return {
	name = "PingSmokeLocation",
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "enabled",
				type = "checkbox",
				default_value = true,
				tooltip = "enabled_tooltip",
			},
			{
				setting_id = "ping_type",
				type = "dropdown",
				default_value = "location_attention",
				tooltip = "ping_type_tooltip",
				options = {
					{ text = "ping_type_attention", value = "location_attention" },
					{ text = "ping_type_enemy", value = "location_threat" },
					{ text = "ping_type_location", value = "location_ping" },
				},
			},
		},
	},
}
