return {
	mod_name = {
		en = "Ping Smoke Location",
	},
	mod_description = {
		en = "When the Veteran throws their Smoke Grenade, automatically drops a ping where it comes to rest - or, if it explodes before settling, where it explodes instead. Veteran and Smoke Grenade only.",
	},
	enabled_tooltip = {
		en = "Turn the automatic Smoke Grenade ping on or off.",
	},
	ping_type_tooltip = {
		en = "Which tagging-wheel marker to drop on the grenade's resting spot.",
	},
	ping_type_attention = {
		en = "Attention (eye)",
	},
	ping_type_enemy = {
		en = "Enemy (danger)",
	},
	ping_type_location = {
		en = "Location (go here)",
	},
}
