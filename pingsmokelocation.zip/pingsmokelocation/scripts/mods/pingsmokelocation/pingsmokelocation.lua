local mod = get_mod("PingSmokeLocation")

-- item_name of the Veteran's Smoke Grenade (scripts/settings/equipment/weapon_templates/grenades/smoke_grenade.lua).
-- Same regardless of skin, and different from e.g. the expedition smoke flare.
local SMOKE_GRENADE_ITEM_NAME = "content/items/weapons/player/grenade_smoke"
local VETERAN_ARCHETYPE_NAME = "veteran"

-- Give up watching a throw after this long, in case neither signal ever fires.
local WATCH_TIMEOUT = 6

-- Speed (m/s) below which we consider the grenade to have stopped.
local REST_SPEED = 0.15
-- Frames it has to stay under that speed before we trust it (avoids pinging
-- mid-bounce, at the top of an arc etc).
local REST_FRAMES = 3

local LOCOMOTION_CLASSES = {
	ProjectileUnitLocomotionExtension = true,
	ProjectileHuskLocomotionExtension = true,
}

-- One throw at a time:
--   since         - gameplay-clock time the throw was committed
--   owner_unit    - the Veteran's player unit (for set_tag's tagger and the smoke's owner_unit)
--   owner_player  - the Player object (what PlayerUnitSpawnManager:owner() returns)
--   before        - projectile units we already owned at throw time, so the fresh one can be told apart
--   smoke_before  - smoke-fog extensions we already owned at throw time, same idea
--   phase         - "seek" (grenade not found yet) or "rest" (found it, watching its speed)
--   unit/extension/rest_frames - set once phase is "rest"
local pending = nil

local function extension_system(name)
	local extension_manager = Managers.state and Managers.state.extension
	local ok, system = pcall(extension_manager and extension_manager.system, extension_manager, name)

	return ok and system or nil
end

local function owner_of(unit)
	local spawn_manager = Managers.state and Managers.state.player_unit_spawn
	local ok, owner = pcall(spawn_manager and spawn_manager.owner, spawn_manager, unit)

	return ok and owner or nil
end

local function locomotion_map()
	local system = extension_system("locomotion_system")
	local ok, map = pcall(system and system.unit_to_extension_map, system)

	return ok and map or nil
end

-- owner_player is the Player object, which is what candidate units get compared against.
local function owned_projectile_units(owner_player)
	local set = {}
	local map = locomotion_map()

	if not map then
		return set
	end

	for unit, extension in pairs(map) do
		if LOCOMOTION_CLASSES[extension.__class_name] and owner_of(unit) == owner_player then
			set[unit] = true
		end
	end

	return set
end

local function find_new_projectile(owner_player, before)
	local map = locomotion_map()

	if not map then
		return nil, nil
	end

	for unit, extension in pairs(map) do
		if LOCOMOTION_CLASSES[extension.__class_name] and not before[unit] and owner_of(unit) == owner_player then
			return unit, extension
		end
	end

	return nil, nil
end

-- Smoke-fog extensions, keyed by owner_unit (a plain Unit, unlike the locomotion
-- lookup above) - this is SmokeFogSystem's own API, not something we build.
local function owned_smoke_extensions(owner_unit)
	local system = extension_system("smoke_fog_system")
	local ok, extensions = pcall(system and system.get_extensions_by_owner_unit, system, owner_unit)

	return ok and extensions or nil
end

local function owned_smoke_set(owner_unit)
	local set = {}
	local extensions = owned_smoke_extensions(owner_unit)

	if extensions then
		for i = 1, #extensions do
			set[extensions[i]] = true
		end
	end

	return set
end

local function find_new_smoke(owner_unit, before)
	local extensions = owned_smoke_extensions(owner_unit)

	if not extensions then
		return nil
	end

	for i = 1, #extensions do
		local extension = extensions[i]

		if not before[extension] then
			return extension
		end
	end

	return nil
end

local function place_ping(owner_unit, position)
	local system = extension_system("smart_tag_system")

	if not system then
		return
	end

	local template_name = mod:get("ping_type") or "location_attention"

	-- Same call the tagging wheel itself makes: tagger = us, no target unit,
	-- just a position. Server-authoritative, so the whole team sees it.
	pcall(system.set_tag, system, template_name, owner_unit, nil, position)
end

-- The throw is committed here, item already resolved - this is where we decide
-- whether to bother watching this throw at all.
mod:hook_safe("ActionThrowGrenade", "start", function(self, action_settings, t)
	if mod:get("enabled") == false then
		return
	end

	if rawget(self, "_is_local_unit") ~= true then
		return
	end

	local weapon_template = rawget(self, "_weapon_template")
	local projectile_template = weapon_template and weapon_template.projectile_template
	local item_name = projectile_template and projectile_template.item_name

	if item_name ~= SMOKE_GRENADE_ITEM_NAME then
		return
	end

	local player = rawget(self, "_player")
	local archetype_name = player and player.archetype_name and player:archetype_name()

	if archetype_name ~= VETERAN_ARCHETYPE_NAME then
		return
	end

	local player_unit = rawget(self, "_player_unit")
	local now = Managers.time and Managers.time:time("gameplay")

	if not player_unit or not now then
		return
	end

	pending = {
		phase = "seek",
		since = now,
		owner_unit = player_unit,
		owner_player = player,
		before = owned_projectile_units(player),
		smoke_before = owned_smoke_set(player_unit),
	}
end)

-- Rest check: true if it fired a ping (caller should stop touching `pending`).
local function check_rest()
	local unit = pending.unit

	if not ALIVE[unit] then
		-- Gone without ever settling (likely blown up mid-flight/mid-bounce) -
		-- leave it to check_explosion below instead of giving up here.
		return false
	end

	local speed_ok, speed = pcall(pending.extension.current_speed, pending.extension)

	if not speed_ok or not speed then
		return false
	end

	if speed <= REST_SPEED then
		pending.rest_frames = pending.rest_frames + 1
	else
		pending.rest_frames = 0
	end

	if pending.rest_frames < REST_FRAMES then
		return false
	end

	local position_ok, position = pcall(Unit.world_position, unit, 1)

	if position_ok and position then
		place_ping(pending.owner_unit, position)
	end

	return true
end

-- Fallback: only ever runs when check_rest hasn't already pinged for this
-- throw. Catches the (common) case where the fuse goes off before the
-- grenade settles.
local function check_explosion()
	local extension = find_new_smoke(pending.owner_unit, pending.smoke_before)

	if not extension then
		return false
	end

	local unit = rawget(extension, "_unit")

	if unit then
		local position_ok, position = pcall(Unit.world_position, unit, 1)

		if position_ok and position then
			place_ping(pending.owner_unit, position)
		end
	end

	return true
end

function mod.update(dt)
	if not pending then
		return
	end

	local now = Managers.time and Managers.time:time("gameplay")

	if not now then
		return
	end

	if now - pending.since > WATCH_TIMEOUT then
		pending = nil

		return
	end

	if pending.phase == "seek" then
		local unit, extension = find_new_projectile(pending.owner_player, pending.before)

		if unit then
			pending.phase = "rest"
			pending.unit = unit
			pending.extension = extension
			pending.rest_frames = 0
		end
	elseif check_rest() then
		pending = nil

		return
	end

	if pending and check_explosion() then
		pending = nil
	end
end

function mod.on_disabled()
	pending = nil
end

function mod.on_unload()
	pending = nil
end
