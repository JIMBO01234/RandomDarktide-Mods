return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`PingSmokeLocation` encountered an error loading the Darktide Mod Framework.")

		new_mod("PingSmokeLocation", {
			mod_script       = "pingsmokelocation/scripts/mods/pingsmokelocation/pingsmokelocation",
			mod_data         = "pingsmokelocation/scripts/mods/pingsmokelocation/pingsmokelocation_data",
			mod_localization = "pingsmokelocation/scripts/mods/pingsmokelocation/pingsmokelocation_localization",
		})
	end,
	packages = {},
}
