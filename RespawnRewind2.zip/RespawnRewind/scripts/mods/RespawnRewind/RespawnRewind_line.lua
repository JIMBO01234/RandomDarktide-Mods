-- Draws the hold-back threshold as an actual line across the main path, instead of only a point.
--
-- Unlike the rest of this mod's main-path/beacon math, LineObject isn't pinned against decompiled
-- Darktide source -- it's confirmed against the public Stingray engine reference only. Everything
-- here is pcall-guarded and degrades to "no line drawn" rather than erroring. Run `rr_line` in a live
-- mission to check what actually happened.
--
-- Additive to the world marker in markers.lua (through-wall, long-range signal); this line only
-- reads clearly up close.

local mod = get_mod("RespawnRewind")

local Line = {}

local line_object = nil
local line_world = nil
local have_content = false -- true once add_line has succeeded for the current position/direction
local last_error = nil

local function record_error(where, err)
	last_error = string.format("%s: %s", where, tostring(err))
end

-- World from the local player's unit -- re-resolved on demand, since the unit (and its world) is
-- replaced on every mission load and respawn.
local function get_world()
	local players = Managers.player
	local player = players and players.local_player and players:local_player(1)
	local unit = player and player.player_unit
	if not (unit and Unit.alive(unit)) then
		return nil
	end
	local ok, world = pcall(Unit.world, unit)
	if ok and world then
		return world
	end
	if not ok then
		record_error("Unit.world", world)
	end
	return nil
end

local function is_finite_number(n)
	return type(n) == "number" and n == n and n ~= math.huge and n ~= -math.huge
end

local function is_finite_vector(v)
	if not v or not Vector3 or not Vector3.x then
		return false
	end
	local ok, x = pcall(Vector3.x, v)
	if not ok then
		return false
	end
	return is_finite_number(x) and is_finite_number(Vector3.y(v)) and is_finite_number(Vector3.z(v))
end

-- Recreates the line object if the world changed under us (mission change swaps it out).
local function ensure_line_object()
	local world = get_world()
	if not world then
		return nil
	end
	if line_object and line_world == world then
		return line_object
	end
	if line_object and line_world then
		pcall(World.destroy_line_object, line_world, line_object)
	end
	local ok, obj = pcall(World.create_line_object, world)
	if not ok or not obj then
		if not ok then
			record_error("World.create_line_object", obj)
		end
		line_object, line_world, have_content = nil, nil, false
		return nil
	end
	line_object, line_world, have_content = obj, world, false
	return line_object
end

-- Endpoints of a line centred on `position`, spanning `width` metres, perpendicular to `direction`
-- (path direction of travel; doesn't need to be normalized). Perpendicular = direction x up.
local function endpoints(position, direction, width)
	if not (is_finite_vector(position) and is_finite_vector(direction) and type(width) == "number" and width > 0) then
		return nil, nil
	end
	local ok_cross, side = pcall(Vector3.cross, direction, Vector3(0, 0, 1))
	if not ok_cross or not is_finite_vector(side) then
		return nil, nil
	end
	local ok_len, side_len = pcall(Vector3.length, side)
	if not ok_len or not is_finite_number(side_len) or side_len < 0.001 then
		return nil, nil -- direction was vertical (or unreadable): no meaningful "across" axis
	end
	local scale = (width * 0.5) / side_len
	local ok_half, half = pcall(function()
		return Vector3(Vector3.x(side) * scale, Vector3.y(side) * scale, Vector3.z(side) * scale)
	end)
	if not ok_half or not is_finite_vector(half) then
		return nil, nil
	end
	local ok_pts, from, to = pcall(function()
		return position - half, position + half
	end)
	if not ok_pts or not is_finite_vector(from) or not is_finite_vector(to) then
		return nil, nil
	end
	return from, to
end

-- Sets (or moves) the line. Cheap to rebuild; only called on the throttled tick, not every frame.
function Line.set(position, direction, color, width)
	local obj = ensure_line_object()
	if not obj then
		have_content = false
		return
	end
	local from, to = endpoints(position, direction, width)
	if not from or not to then
		pcall(LineObject.reset, obj)
		have_content = false
		return
	end
	color = color or { 255, 120, 220, 120 } -- { alpha, r, g, b }, matching the rest of the mod
	local ok = pcall(function()
		LineObject.reset(obj)
		local col = Color(color[1], color[2], color[3], color[4])
		LineObject.add_line(obj, col, from, to)
	end)
	if not ok then
		record_error("LineObject.add_line", "see log")
		have_content = false
		return
	end
	have_content = true
end

function Line.clear()
	if line_object then
		pcall(LineObject.reset, line_object)
	end
	have_content = false
end

-- Full teardown for mod-disable/mission-end only; Line.clear() handles the ordinary per-episode clear.
function Line.teardown()
	if line_object and line_world then
		pcall(LineObject.reset, line_object)
		pcall(World.destroy_line_object, line_world, line_object)
	end
	line_object, line_world, have_content = nil, nil, false
end

-- A line object needs dispatching every frame it should be visible; called from the real per-frame
-- update, not the throttled tick.
function Line.render_frame()
	if not (line_object and line_world and have_content) then
		return
	end
	local ok, err = pcall(LineObject.dispatch, line_world, line_object)
	if not ok then
		record_error("LineObject.dispatch", err)
	end
end

function Line.diagnostics()
	return {
		has_world = line_world ~= nil,
		has_line_object = line_object ~= nil,
		have_content = have_content,
		last_error = last_error,
	}
end

return Line
