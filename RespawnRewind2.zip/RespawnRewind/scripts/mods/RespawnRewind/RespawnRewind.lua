local mod = get_mod("RespawnRewind")

local BASE = "RespawnRewind/scripts/mods/RespawnRewind/"
local Beacons = mod:io_dofile(BASE .. "beacons")
local Markers = mod:io_dofile(BASE .. "markers")
local Line = mod:io_dofile(BASE .. "RespawnRewind_line")

local TICK_INTERVAL = 0.3
local cooldown = 0.0
local episode_active = false
local awaiting_last = {}
local last_predicted = nil

-- In gameplay once the extension systems exist and we are not on the Mourningstar hub.
local function in_gameplay()
	if not (Managers.state and Managers.state.extension) then
		return false
	end
	local game_mode = Managers.state.game_mode
	if game_mode and game_mode.game_mode_name then
		local ok, name = pcall(game_mode.game_mode_name, game_mode)
		if ok and name == "hub" then
			return false
		end
	end
	return true
end

-- What the game itself says a player is doing, off the replicated character_state component --
-- respawn_beacon_system reads the same field for its hogtied check. Nil means "no opinion", caller
-- falls back.
local function player_state_name(player)
	local unit = player and player.player_unit
	if not (unit and Unit.alive(unit)) then
		return nil
	end
	if not ScriptUnit.has_extension(unit, "unit_data_system") then
		return nil
	end
	local ok_ext, extension = pcall(ScriptUnit.extension, unit, "unit_data_system")
	if not ok_ext or not extension or not extension.read_component then
		return nil
	end
	local ok_comp, component = pcall(extension.read_component, extension, "character_state")
	if not ok_comp or not component then
		return nil
	end
	local ok_name, name = pcall(function()
		return component.state_name
	end)
	if ok_name and type(name) == "string" then
		return name
	end
	return nil
end

-- Awaiting respawn: game state is "dead", or failing that, no live unit. State catches it
-- immediately; the unit lingers alive for a moment after death. Knocked-down/hogtied don't count --
-- they're waiting for a rescue, not a beacon.
--
-- seen_alive[player]: a bot backfilling a leaver's slot can exist before its unit spawns, which
-- looked identical to a dead teammate through the unit test and put markers up for nobody. Requiring
-- we've seen the player alive once separates a genuine death from a not-yet-spawned backfill.
local seen_alive = {}

local function player_awaiting_respawn(player)
	if not player then
		return false
	end
	if not seen_alive[player] then
		return false
	end
	local state = player_state_name(player)
	if state then
		return state == "dead"
	end
	local ok, alive = pcall(function()
		return player:unit_is_alive()
	end)
	if ok then
		return not alive
	end
	local unit = player.player_unit
	return not (unit and Unit.alive(unit))
end

-- The game's own answer to "is anyone waiting to spawn" -- the exact condition respawn_beacon_system
-- gates on. Strictly better than inferring from missing units when readable. Returns nil for
-- unreadable, which the caller treats as no opinion.
local function game_says_waiting_to_spawn()
	local spawn_manager = Managers.state and Managers.state.player_unit_spawn
	if not spawn_manager or not spawn_manager.has_players_waiting_to_spawn then
		return nil
	end
	local ok, waiting = pcall(spawn_manager.has_players_waiting_to_spawn, spawn_manager)
	if not ok then
		return nil
	end
	return waiting and true or false
end

-- Show only during a real mid-mission respawn wait. The unit-based test ("player with no live unit")
-- is an INFERENCE -- a leaver also has no unit, and reported behaviour was markers staying up for
-- their empty slot for the rest of the run. So the game's own signal is asked first; the inference is
-- only a fallback when it can't be read. Either source saying yes wins for now, since the signal is
-- confirmed readable but not yet confirmed to flip true on a client (rr_players can settle this on a
-- real death).
local function should_show()
	local players = Managers.player and Managers.player:players()
	if not players then
		return false
	end

	local awaiting, alive = false, false
	for _, player in pairs(players) do
		if player_awaiting_respawn(player) then
			awaiting = true
		else
			alive = true
		end
	end
	if not alive then
		return false
	end

	local waiting = game_says_waiting_to_spawn()
	if waiting then
		return true
	end
	return awaiting
end

local function teardown_all()
	Markers.teardown_all()
	Beacons.teardown()
	seen_alive = {}
end

mod.update = function(dt)
	if not mod:is_enabled() or not in_gameplay() then
		teardown_all()
		return
	end

	-- Re-queue the drawn line every real frame; the rest of this function only runs on the throttled tick.
	Markers.render_frame()

	if cooldown > 0 then
		cooldown = cooldown - dt
		return
	end
	cooldown = TICK_INTERVAL

	-- Track who's been seen alive, before any check that depends on it.
	local players_alive = Managers.player and Managers.player:players()
	if players_alive then
		for _, player in pairs(players_alive) do
			local unit = player.player_unit
			if unit and Unit.alive(unit) then
				seen_alive[player] = true
			end
		end
	end

	-- Sample progress every tick, before the should_show gate -- history needs to be continuous, or
	-- the first sample after a death could land inside an objective room and credit exactly the
	-- projection that guard exists to reject.
	Beacons.track()

	-- Watch for a player reappearing and log the model's prediction against what actually happened.
	-- Passive calibration data; changes nothing.
	local players_now = Managers.player and Managers.player:players()
	if players_now then
		for _, player in pairs(players_now) do
			local was_waiting = awaiting_last[player]
			local is_waiting = player_awaiting_respawn(player)
			if was_waiting and not is_waiting then
				local unit = player.player_unit
				if unit and Unit.alive(unit) then
					local ok, pos = pcall(Unit.world_position, unit, 1)
					if ok then
						local m = Beacons.measure_respawn(pos)
						if m then
							mod:info("RR respawn: actual=%s predicted=%s ahead=%s margin=%s implied_margin=%s off_beacon=%s",
								tostring(m.actual), tostring(m.predicted),
								m.ahead and string.format("%.1f", m.ahead) or "nil",
								tostring(m.margin),
								m.implied and string.format("%+.1f", m.implied) or "agreed",
								m.distance_to_beacon and string.format("%.1f", m.distance_to_beacon) or "nil")
						end
					end
				end
			end
			awaiting_last[player] = is_waiting
		end
	end

	-- Practice markers stand on their own, so run before the respawn-wait gate.
	Markers.sync_practice()

	if not should_show() then
		if episode_active then
			episode_active = false
			last_predicted = nil
			mod:info("RR episode end")
		end
		-- Drop our latched beacon at episode end, same as the game drops its own.
		Beacons.end_episode()
		Markers.teardown_live()
		return
	end

	local model = Beacons.compute()
	if not model then
		Markers.teardown_live()
		return
	end

	-- Log the first tick of each episode and every tick the prediction moves, so a commit-time
	-- prediction can be compared against where the player actually reappeared.
	local active_distance = model.active and model.active.distance
	if episode_active == false then
		episode_active = true
		mod:info("RR episode start: ahead=%s predicted_beacon_at=%s",
			tostring(Beacons.ahead_snapshot()), tostring(active_distance))
	elseif active_distance ~= last_predicted then
		mod:info("RR episode moved: ahead=%s predicted_beacon_at=%s",
			tostring(Beacons.ahead_snapshot()), tostring(active_distance))
	end
	last_predicted = active_distance

	Markers.sync(model)
end

mod.on_setting_changed = function()
	if not mod:is_enabled() then
		teardown_all()
		return
	end
	Markers.on_setting_changed()
end

mod.on_unload = function()
	teardown_all()
end

mod.on_disabled = function()
	teardown_all()
end

-- Diagnostic commands. 1.0.0's failure was invisible (every main-path call nil, nothing logged) and
-- only passed testing because SoloPlay makes the local machine the server. Run rr_beacons in a LIVE
-- mission (SoloPlay off) to check the client-safe path model is resolving without waiting for a death.
--
-- pcall'd so an API drift in mod:command can't abort the rest of the file.
pcall(function()
	-- mod:echo reaches in-game chat only; mod:info also lands in console_logs for reading afterwards.
	local function report(line)
		mod:echo(line)
		mod:info(line)
	end

	mod:command("rr_players", "RespawnRewind: dump the player list and the spawn-wait signal", function()
		local spawn_manager = Managers.state and Managers.state.player_unit_spawn
		local signal = "unreachable"
		if spawn_manager and spawn_manager.has_players_waiting_to_spawn then
			local ok, waiting = pcall(spawn_manager.has_players_waiting_to_spawn, spawn_manager)
			signal = ok and tostring(waiting and true or false) or "call failed"
		end
		report("RR players: has_players_waiting_to_spawn=" .. signal ..
			"  (a value here means the mod is using it and ignoring the unit inference)")

		local players = Managers.player and Managers.player:players()
		if not players then
			report("RR players: no player list")
			return
		end
		local function safe(fn, default)
			local ok, value = pcall(fn)
			if ok and value ~= nil then
				return tostring(value)
			end
			return default
		end
		local index = 0
		for _, player in pairs(players) do
			index = index + 1
			local unit = player.player_unit
			report(string.format(
				"RR player %d: name=%s type=%s human=%s slot=%s unit=%s awaiting=%s",
				index,
				safe(function() return player:name() end, "?"),
				safe(function() return player:type() end, "?"),
				safe(function() return player:is_human_controlled() end, "?"),
				safe(function() return player:slot() end, "?"),
				(unit and Unit.alive(unit)) and "alive" or "none",
				tostring(player_awaiting_respawn(player))) ..
				"  state=" .. tostring(player_state_name(player)))
		end
	end)

	mod:command("rr_practice", "RespawnRewind: why the map-practice markers are or are not showing", function()
		local d = Beacons.practice_debug()
		report(string.format("RR practice: setting=%s want_safe_zone=%s", tostring(mod:get("practice_enabled")), tostring(d.want_safe_zone)))
		report(string.format("RR practice: module=%s path_registered=%s position_from_distance=%s",
			tostring(d.module), tostring(d.path_registered), tostring(d.has_position_from_distance)))
		report(string.format("RR practice: beacons=%d matching_safe_zone=%d points=%d with_line=%d",
			d.total_beacons, d.matching, d.points, d.lines))
		local slots, placed, with_id = Markers.practice_state()
		report(string.format("RR practice: slots=%d markers_created=%d markers_with_id=%d", slots, placed, with_id))
		if d.points == 0 and d.total_beacons > 0 and d.matching == 0 then
			report("RR practice: every beacon is the other safe-zone class, so nothing matched.")
		end
	end)

	-- A hold-back line lands at (beacon distance - 25); a large offset means an untrustworthy distance.
	mod:command("rr_layout", "RespawnRewind: dump every beacon with its distance and projection offset", function()
		local cap = Beacons.snap_capability()
		report(string.format("RR layout: nav_queries=%s position_on_mesh_with_outside_position=%s nav_world=%s",
			tostring(cap.module), tostring(cap.has_function), tostring(cap.nav_world)))
		if not (cap.module and cap.has_function and cap.nav_world) then
			report("RR layout: the nav-mesh snap CANNOT run here, so every snap value below is a fallback, not a result.")
		end
		local beacons, ahead = Beacons.layout()
		report(string.format("RR layout: beacons=%d ahead=%s", #beacons,
			ahead and string.format("%.1f", ahead) or "nil"))
		for i = 1, #beacons do
			local b = beacons[i]
			report(string.format("RR beacon %d: distance=%.1f line_at=%.1f offset=%s snap=%s safe_zone=%s",
				i, b.distance, b.distance - 25,
				b.offset and string.format("%.1f", b.offset) or "nil",
				b.snap_delta and string.format("%+.1f", b.snap_delta) or "nil",
				tostring(b.safe_zone)))
		end
	end)

	-- os.clock resolves to 1ms, so each phase runs N times and the total is divided.
	mod:command("rr_perf", "RespawnRewind: time the per-refresh work", function()
		-- rawget is the only way to check the sandbox exposed a clock without erroring if it didn't.
		-- selene: allow(global_usage)
		local mods_global = rawget(_G, "Mods")
		-- selene: allow(global_usage)
		local os_lib = (mods_global and mods_global.lua and mods_global.lua.os) or rawget(_G, "os")
		local clock = os_lib and os_lib.clock
		if type(clock) ~= "function" then
			report("RR perf: os.clock unavailable")
			return
		end
		local N = 200
		local function bench(label, fn)
			pcall(fn)
			local t0 = clock()
			for _ = 1, N do
				pcall(fn)
			end
			local ms = (clock() - t0) * 1000 / N
			report(string.format("RR perf  %-26s %8.4f ms/call", label, ms))
			return ms
		end

		local players = Managers.player and Managers.player:players()
		local living = 0
		if players then
			for _, player in pairs(players) do
				local unit = player.player_unit
				if unit and Unit.alive(unit) then
					living = living + 1
				end
			end
		end
		report(string.format("RR perf  living players: %d (track projects each one every refresh)", living))

		local one = bench("one projection (full sweep)", Beacons.time_one_projection)
		local window = Beacons.track_window()
		bench(string.format("one projection, windowed (%d nodes)", window), function()
			Beacons.time_one_windowed_projection(window)
		end)
		local track = bench("Beacons.track", Beacons.track)
		bench("should_show", should_show)
		bench("Beacons.compute", Beacons.compute)
		report(string.format("RR perf  one projection x %d living = %.4f ms, track measures %.4f ms",
			living, one * living, track))
	end)

	mod:command("rr_beacons", "RespawnRewind: dump respawn beacon diagnostics", function()
		local d = Beacons.diagnose()
		report(string.format(
			"RR: module=%s path_registered=%s beacons=%d ahead=%s active_at=%s runback=%s",
			tostring(d.module_loaded), tostring(d.path_registered), d.beacon_count,
			d.ahead and string.format("%.1f", d.ahead) or "nil",
			d.active_distance and string.format("%.1f", d.active_distance) or "nil",
			tostring(d.has_runback)))
		-- path_type picks the rule: "linear" is the ahead+25 main-path rule, else the euclidean
		-- midpoint rule (no hold-back marker). latched = held for this episode, matching the game.
		report(string.format("RR: path_type=%s safe_zone=%s latched=%s latch_in_force=%s",
			tostring(d.path_type), tostring(d.safe_zone), tostring(d.latched), tostring(d.latch_in_force)))
		local lp = Beacons.local_progress()
		if lp then
			report(string.format("RR: you live=%s credited=%s off=%s (progress freezes above %d)",
				lp.live_distance and string.format("%.1f", lp.live_distance) or "nil",
				lp.credited and string.format("%.1f", lp.credited) or "nil",
				lp.offset and string.format("%.1f", lp.offset) or "nil",
				lp.max_offset))
		end
		local owner, is_local = Beacons.ahead_owner()
		report(string.format("RR: ahead set by %s%s", tostring(owner),
			is_local and " (you)" or " (NOT you: retreating alone will not move the respawn)"))
		if not d.path_registered then
			report("RR: main path not registered. Markers cannot compute.")
		elseif d.beacon_count == 0 then
			report("RR: no beacons resolved. This is the 1.0.0 client failure signature.")
		elseif not d.ahead then
			report("RR: no ahead distance. No living player unit projected onto the path.")
		else
			report("RR: path model is resolving on this client.")
		end
		report(string.format("RR: runback_direction=%s (needed to draw the hold-back LINE; position alone is not enough)",
			tostring(d.has_runback_direction)))
	end)

	-- Least-confirmed part of the mod (see RespawnRewind_line.lua). Run while the line should be
	-- showing to see whether the engine calls it needs are actually behaving on this client.
	mod:command("rr_line", "RespawnRewind: diagnose the drawn hold-back line", function()
		local d = Line.diagnostics()
		report(string.format("RR line: has_world=%s has_line_object=%s have_content=%s",
			tostring(d.has_world), tostring(d.has_line_object), tostring(d.have_content)))
		if d.last_error then
			report("RR line: last error: " .. d.last_error)
		end
		if not d.has_world then
			report("RR line: no world resolved from the local player unit yet. Are you in a mission?")
		elseif not d.has_line_object then
			report("RR line: World.create_line_object did not return an object. This engine build may not expose it to mods the way expected; the point marker still works regardless.")
		elseif not d.have_content then
			report("RR line: line object exists but nothing is currently drawn. Normal outside a respawn wait, or if runback_direction failed (check rr_beacons).")
		else
			report("RR line: a line is set and should be dispatching every frame.")
		end
	end)
end)

mod:info("RespawnRewind loaded.")
