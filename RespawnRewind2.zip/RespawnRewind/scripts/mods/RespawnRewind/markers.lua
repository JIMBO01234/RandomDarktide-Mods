local mod = get_mod("RespawnRewind")

local Markers = {}

local Beacons = mod:io_dofile("RespawnRewind/scripts/mods/RespawnRewind/beacons")
local Line = mod:io_dofile("RespawnRewind/scripts/mods/RespawnRewind/RespawnRewind_line")
local MARKER_TEMPLATE = mod:io_dofile("RespawnRewind/scripts/mods/RespawnRewind/RespawnRewind_marker")
local MARKER_TYPE = MARKER_TEMPLATE.name -- "respawn_rewind"

local ACTIVE_COLOR  = { 255, 120, 200, 255 } -- light blue: where the respawn is now
local RUNBACK_COLOR = { 255, 120, 220, 120 } -- green: where to hold back to

-- Drawn hold-back line width, either side of the path centreline. Not tuned per map -- Line.set just
-- draws nothing if it can't fit, so an oversized default is free on a narrow corridor.
local RUNBACK_LINE_WIDTH = 8

-- state.active  = { id, data, unit, pending_remove }
-- state.runback = { id, data, unit, pending_remove } (unit = the prev beacon this run-back point belongs to)
local state = { active = nil, runback = nil }

local function through_walls()
	local v = mod:get("through_walls")
	if v == nil then
		return true
	end
	return v
end

local function apply_template_settings()
	local size = mod:get("marker_size")
	if type(size) == "number" then
		MARKER_TEMPLATE.size = { size, size }
	end
	MARKER_TEMPLATE.check_line_of_sight = not through_walls()
end

local function ensure_marker_templates(world_markers)
	if not world_markers or not world_markers._marker_templates then
		return
	end
	world_markers._marker_templates[MARKER_TYPE] = MARKER_TEMPLATE
end

mod:hook_safe(CLASS.HudElementWorldMarkers, "init", function(self)
	apply_template_settings()
	ensure_marker_templates(self)
end)

-- Don't wrap HudElementWorldMarkers.update to re-inject the template -- that hook runs every frame
-- and calls through to the base update, which walks every world marker in the game, so a profiler
-- charges all of that to this mod (reported as 0.7ms/frame vs. ~25us of actual work). Hook
-- _template_by_type instead: called only at marker-add time, costs nothing per frame.
mod:hook(CLASS.HudElementWorldMarkers, "_template_by_type", function(func, self, marker_type, clone)
	local templates = self._marker_templates
	if templates and marker_type == MARKER_TYPE and not templates[marker_type] then
		apply_template_settings()
		ensure_marker_templates(self)
	end
	return func(self, marker_type, clone)
end)

-- Every path here is a real shipped world-marker template, not guessed. Skull is the original and
-- stays default.
local MARKER_ICONS = {
	skull      = "content/ui/materials/icons/difficulty/difficulty_skull_uprising",
	assistance = "content/ui/materials/hud/icons/player_assistance/player_assistance_icon",
	location   = "content/ui/materials/hud/interactions/icons/location",
	attention  = "content/ui/materials/hud/interactions/icons/attention",
	objective  = "content/ui/materials/hud/interactions/icons/objective_main",
	resupply   = "content/ui/materials/hud/interactions/icons/resupply",
	default    = "content/ui/materials/hud/interactions/icons/default",
}

local function marker_icon()
	local choice = mod:get("marker_icon")
	return MARKER_ICONS[choice] or MARKER_ICONS.skull
end

-- Read live: the template has no scale_settings, so the base HUD never resizes an existing marker.
-- marker.data is the only route back to a marker already on screen, re-read every frame.
local function marker_size()
	local size = mod:get("marker_size")
	if type(size) == "number" then
		return size
	end
	return MARKER_TEMPLATE.size[1]
end

-- Pushes icon/size into a live entry's data; the template only touches the widget when a value
-- actually differs.
local function refresh_appearance(entry, icon, size)
	entry.data.icon = icon
	entry.data.size = size
end

local function new_marker_data(text, colour)
	return { icon = marker_icon(), size = marker_size(), text = text, color = colour }
end

local function distance_enabled()
	local v = mod:get("show_distance")
	if v == nil then
		return true
	end
	return v
end

local function distance_text(target_position)
	if not distance_enabled() or not target_position then
		return nil
	end
	local pp = Beacons.player_position()
	if not pp then
		return nil
	end
	local ok, d = pcall(Vector3.distance, pp, target_position)
	if ok and type(d) == "number" then
		return string.format("%.0fm", d)
	end
	return nil
end

local function label(prefix, target_position)
	local dt = distance_text(target_position)
	if dt then
		return prefix .. " | " .. dt
	end
	return prefix
end

-- Threshold label, not a distance-to-walk-to: "Run back | 29m" past it (give up 29m), "Stay behind |
-- -12m" behind it (12m of room left). Falls back to a plain distance label on a non-linear path.
local function runback_label(model)
	local offset = model and model.runback_offset
	if type(offset) ~= "number" then
		return label("Hold back", model and model.runback_position)
	end
	if not distance_enabled() then
		return (offset > 0) and "Run back" or "Stay behind"
	end
	if offset > 0 then
		return string.format("Run back | %.0fm", offset)
	end
	return string.format("Stay behind | %.0fm", offset)
end

-- pcall-guarded so a dispatch into a tearing-down world/HUD (mission end) can't fault the tick.
local function trigger_event(...)
	if not Managers.event then
		return
	end
	pcall(Managers.event.trigger, Managers.event, ...)
end

local function remove_marker(slot)
	local entry = state[slot]
	if entry then
		if entry.id then
			trigger_event("remove_world_marker", entry.id)
		else
			-- Callback hasn't fired yet: flag for removal once it has an id, instead of orphaning it.
			entry.pending_remove = true
		end
	end
	state[slot] = nil
end

-- Called from the add-marker callback; stores the id, or removes immediately if we were superseded.
local function on_marker_added(entry, marker_id)
	entry.id = marker_id
	if entry.pending_remove then
		trigger_event("remove_world_marker", marker_id)
	end
end

-- The whole respawn layout at once, for learning a map. Off by default, not gated on being dead.
-- Two markers per point: the beacon itself ("Respawn 3") and the line 25m short of it ("3 ends").
-- Placed once; geometry never moves (position markers can't move after adding), only icon/size
-- refresh each tick.
local BEACON_PRACTICE_COLOR = { 255, 130, 170, 200 } -- muted blue: the place
local LINE_PRACTICE_COLOR   = { 255, 175, 175, 175 } -- grey: the boundary
local practice_slots = 0

local function clear_practice()
	for i = 1, practice_slots do
		remove_marker("practice_beacon_" .. i)
		remove_marker("practice_line_" .. i)
	end
	practice_slots = 0
end

local function add_practice_marker(slot, text, colour, unit, position)
	local data = new_marker_data(text, colour)
	local new_entry = { id = nil, data = data }
	state[slot] = new_entry
	local function added(marker_id)
		on_marker_added(new_entry, marker_id)
	end
	if unit then
		trigger_event("add_world_marker_unit", MARKER_TYPE, unit, added, data)
	else
		local fresh_pos = Vector3(Vector3.x(position), Vector3.y(position), Vector3.z(position))
		trigger_event("add_world_marker_position", MARKER_TYPE, fresh_pos, added, data)
	end
end

local function practice_setting(id, default)
	local value = mod:get(id)
	if value == nil then
		return default
	end
	return value
end

-- Rebuilt on toggle change rather than diffed -- geometry is placed once and never touched, so a
-- diff would never pay for itself.
local practice_signature = nil

-- The add event is fire-and-forget through a callback; if HudElementWorldMarkers doesn't exist yet
-- it goes nowhere and nothing ever answers. That's the normal case here since practice markers are
-- placed on the first gameplay tick, before the HUD is up. So "placed" != "accepted" -- retry until
-- at least one id comes back.
local function practice_took()
	for i = 1, practice_slots do
		local beacon_entry = state["practice_beacon_" .. i]
		if beacon_entry and beacon_entry.id then
			return true
		end
		local line_entry = state["practice_line_" .. i]
		if line_entry and line_entry.id then
			return true
		end
	end
	return false
end

-- Geometry never changes once placed, but icon/size are settings someone may tune with this set on
-- screen.
local function refresh_practice_appearance()
	local icon, size = marker_icon(), marker_size()
	for i = 1, practice_slots do
		local beacon_entry = state["practice_beacon_" .. i]
		if beacon_entry then
			refresh_appearance(beacon_entry, icon, size)
		end
		local line_entry = state["practice_line_" .. i]
		if line_entry then
			refresh_appearance(line_entry, icon, size)
		end
	end
end

local function sync_practice()
	if not practice_setting("practice_enabled", false) then
		if practice_slots > 0 then
			clear_practice()
			practice_signature = nil
		end
		return
	end

	local want_beacons = practice_setting("practice_beacons", true)
	local want_lines = practice_setting("practice_lines", true)
	local want_numbers = practice_setting("practice_numbers", true)
	-- Margin is part of the signature: it moves every line, and position markers can't move once added.
	local signature = tostring(want_beacons) .. tostring(want_lines) .. tostring(want_numbers) ..
		"|" .. tostring(Beacons.runback_margin())
	if practice_slots > 0 and signature == practice_signature and practice_took() then
		-- Already placed for this mission, with these toggles, and the HUD accepted them.
		refresh_practice_appearance()
		return
	end
	if practice_slots > 0 then
		clear_practice()
	end

	local list = Beacons.practice_points()
	for i = 1, #list do
		local entry = list[i]
		local number = want_numbers and tostring(i) or nil
		if want_beacons and entry.unit and Unit.alive(entry.unit) then
			local text = number and ("Respawn " .. number) or "Respawn"
			add_practice_marker("practice_beacon_" .. i, text, BEACON_PRACTICE_COLOR, entry.unit, nil)
		end
		if want_lines and entry.line_position then
			local text = number and (number .. " ends") or "Line"
			add_practice_marker("practice_line_" .. i, text, LINE_PRACTICE_COLOR, nil, entry.line_position)
		end
	end
	practice_slots = #list
	practice_signature = signature
end

-- Add/refresh the active-beacon marker (anchored to the beacon unit).
local function sync_active(active)
	if not active or not active.unit or not Unit.alive(active.unit) then
		remove_marker("active")
		return
	end
	local text = label("Respawn", active.position)
	local entry = state.active
	if entry and entry.unit == active.unit then
		entry.data.text = text
		entry.data.color = ACTIVE_COLOR
		refresh_appearance(entry, marker_icon(), marker_size())
		return
	end
	remove_marker("active")
	local data = new_marker_data(text, ACTIVE_COLOR)
	local new_entry = { id = nil, data = data, unit = active.unit }
	state.active = new_entry
	trigger_event("add_world_marker_unit", MARKER_TYPE, active.unit, function(marker_id)
		on_marker_added(new_entry, marker_id)
	end, data)
end

-- Keyed by beacon AND line distance (position markers can't move once added), since the margin
-- moves the line without changing which beacon it belongs to. Epsilon-compared so float noise on the
-- margin can't cause a flicker-inducing re-add every tick.
local LINE_MOVED_EPSILON = 0.5

local function line_moved(a, b)
	if type(a) ~= "number" or type(b) ~= "number" then
		return a ~= b
	end
	return math.abs(a - b) >= LINE_MOVED_EPSILON
end

local function sync_runback(model)
	local show = mod:get("show_runback")
	if show == nil then
		show = true
	end
	local pos = show and model.runback_position or nil
	local key_unit = show and model.runback_beacon_unit or nil
	if not pos or not key_unit then
		remove_marker("runback")
		Line.clear()
		return
	end

	-- Drawn line across the path at the threshold, alongside the point marker below (through-wall,
	-- long-range signal; the line only reads clearly up close).
	Line.set(pos, model.runback_direction, RUNBACK_COLOR, RUNBACK_LINE_WIDTH)

	local text = runback_label(model)
	local line_distance = model.runback_line_distance
	local entry = state.runback
	if entry and entry.unit == key_unit and not line_moved(entry.line_distance, line_distance) then
		entry.data.text = text
		entry.data.color = RUNBACK_COLOR
		refresh_appearance(entry, marker_icon(), marker_size())
		return
	end
	remove_marker("runback")
	local fresh_pos = Vector3(Vector3.x(pos), Vector3.y(pos), Vector3.z(pos))
	local data = new_marker_data(text, RUNBACK_COLOR)
	local new_entry = { id = nil, data = data, unit = key_unit, line_distance = line_distance }
	state.runback = new_entry
	trigger_event("add_world_marker_position", MARKER_TYPE, fresh_pos, function(marker_id)
		on_marker_added(new_entry, marker_id)
	end, data)
end

function Markers.sync(model)
	if not Managers.event then
		return
	end
	if not model or not model.active then
		Markers.teardown_all()
		return
	end
	sync_active(model.active)
	sync_runback(model)
end

function Markers.sync_practice()
	sync_practice()
end

-- Markers already on screen pick up new size/icon through their data next tick; this just keeps the
-- shared template current for new markers and the through-walls flag, which lives only there.
function Markers.on_setting_changed()
	apply_template_settings()
end

-- Practice slots placed vs. how many actually got a live marker id back from the HUD.
function Markers.practice_state()
	local placed, with_id = 0, 0
	for i = 1, practice_slots do
		for _, prefix in ipairs({ "practice_beacon_", "practice_line_" }) do
			local entry = state[prefix .. i]
			if entry then
				placed = placed + 1
				if entry.id then
					with_id = with_id + 1
				end
			end
		end
	end
	return practice_slots, placed, with_id
end

-- Re-queues the drawn line for this frame (cheap re-submit; geometry is already built by
-- sync_runback). Has to run every real frame, not the throttled tick, or it goes dark between ticks.
function Markers.render_frame()
	Line.render_frame()
end

-- The two live markers only -- what the respawn-episode path calls most ticks. Practice markers
-- aren't part of an episode and must survive it.
function Markers.teardown_live()
	remove_marker("active")
	remove_marker("runback")
	Line.clear()
end

-- Everything, practice included. Only for leaving gameplay or disabling the mod.
function Markers.teardown_all()
	clear_practice()
	Markers.teardown_live()
	Line.teardown()
end

return Markers
