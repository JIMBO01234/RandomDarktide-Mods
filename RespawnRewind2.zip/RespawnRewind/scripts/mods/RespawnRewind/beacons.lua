local mod = get_mod("RespawnRewind")

local Beacons = {}

-- Pinned from respawn_beacon_system.lua: the active beacon is the nearest one whose main-path
-- distance exceeds the furthest-ahead player's distance + this.
local BEACON_AHEAD_DISTANCE = 25

-- All main-path math goes through MainPathQueries (EngineOptimized, client-safe). NOT
-- MainPathManager (ahead_unit, travel_distance_from_position) -- those need server-only
-- _nav_spawn_points and just return nil on a client, which is why 1.0.0 only worked in SoloPlay.
local MainPathQueries = nil
local function main_path_queries()
	if MainPathQueries == nil then
		local ok, m = pcall(require, "scripts/utilities/main_path_queries")
		MainPathQueries = ok and m or false
	end
	return MainPathQueries or nil
end

-- Static beacon world positions do not move; cache distance per beacon unit for the mission.
local distance_cache = {}

local function is_finite_number(n)
	-- The type check is load-bearing: without it nil passes (nil == nil and nil ~= math.huge).
	return type(n) == "number" and n == n and n ~= math.huge and n ~= -math.huge
end

local function is_finite_vector(v)
	if not v or not Vector3 or not Vector3.x then
		return false
	end
	local ok, x = pcall(Vector3.x, v)
	if not ok then
		return false
	end
	return is_finite_number(x) and is_finite_number(Vector3.y(v)) and is_finite_number(Vector3.z(v))
end

local function path_registered(mpq)
	if not mpq or not mpq.is_main_path_registered then
		return false
	end
	local ok, registered = pcall(mpq.is_main_path_registered)
	return (ok and registered) and true or false
end

-- Project a world position onto the main path. Returns (travel_distance, offset, node); offset is
-- how far pos sits from the point it snapped to, node is the landing node (used to window later
-- searches). Sweeps the whole path -- the expensive one.
local function project_full(mpq, pos)
	local ok, projected, dist, _, node = pcall(mpq.closest_position, pos)
	if not ok or not is_finite_number(dist) then
		return nil, nil, nil
	end
	local offset = nil
	if projected then
		local ok_offset, d = pcall(Vector3.distance, pos, projected)
		if ok_offset and is_finite_number(d) then
			offset = d
		end
	end
	return dist, offset, node
end

-- Same, but constrained to `window` nodes either side of `node`. Much cheaper, and closer to what
-- the game itself does (PathTypeLinear projects between two specific nodes, not the whole route).
-- Returns nil on failure so callers fall back to a full sweep instead of trusting a bad window.
local function project_windowed(mpq, pos, node, window)
	if not mpq.closest_position_between_nodes then
		return nil, nil, nil
	end
	local lo = math.max(1, node - window)
	local hi = node + window
	local ok, projected, dist, _, new_node = pcall(mpq.closest_position_between_nodes, pos, lo, hi)
	if not ok or not is_finite_number(dist) then
		return nil, nil, nil
	end
	local offset = nil
	if projected then
		local ok_offset, d = pcall(Vector3.distance, pos, projected)
		if ok_offset and is_finite_number(d) then
			offset = d
		end
	end
	return dist, offset, new_node
end

-- Plain unconstrained projection for one-off/cached callers (beacon distances, diagnostics) where a
-- single full sweep is cheap and there's no node history to window against.
local function project(mpq, pos)
	return project_full(mpq, pos)
end

-- ##### Player progress ##############################################################################
-- The game's rule keys off ahead_unit (server-only, real travel distance). Projection onto the path
-- is the client-side stand-in, but it answers "which bit of the route is nearest", not "how far have
-- you got" -- those diverge inside an objective room off the route, where the nearest path point can
-- be well ahead of where the player actually is, jumping the predicted beacon forward early.
--
-- A projection is trusted if it's near the route OR continuous with the last credited value; nearness
-- alone was too strict (measured 22m off just past beacon 1 on one map, which froze progress at 91.4
-- while the player walked to 127.0). Continuity is checked against the last CREDITED value, not the
-- last seen one, so a bad jump stays rejected instead of being readmitted a tick later. A respawn
-- teleport fails continuity but lands you on a beacon, which passes the nearness test.

-- A player on the route sits a few metres from centreline even hugging a wall; an off-route side
-- room is much further than that.
local ON_PATH_MAX_OFFSET = 20

-- progress[player] = last distance recorded while demonstrably on the route. Keyed by the player
-- object, which survives the unit being replaced on respawn.
local progress = {}

-- last_node[player] = the path node their last accepted projection landed on, so the next tick can
-- search a small window around it instead of sweeping the whole path again.
local last_node = {}

-- Nodes either side of the last known one to search. Spacing isn't fixed per map, so this is sized
-- well above the actual per-tick movement it needs to cover (a couple of metres, see MAX_STEP).
local TRACK_WINDOW = 40

function Beacons.track_window()
	return TRACK_WINDOW
end

-- Largest jump in projected distance that can still be one player walking, per tick. Refresh is
-- 0.3s (real movement: a couple of metres); an objective-room jump moves the projection tens or
-- hundreds of metres in one sample, so 10m separates the two cleanly.
local MAX_STEP = 10

-- Samples every living player. Call every tick regardless of whether markers are shown -- the
-- progress history needs to be continuous, or the first sample after a death could land inside an
-- objective room and credit the exact value this exists to reject.
--
-- Windowed: once a player has a known node, search stays local to it instead of sweeping the whole
-- path. Falls back to a full sweep whenever there's no node history yet.
function Beacons.track()
	local mpq = main_path_queries()
	if not path_registered(mpq) then
		return
	end
	local players = Managers.player and Managers.player:players()
	if not players then
		return
	end
	for _, player in pairs(players) do
		local unit = player.player_unit
		if unit and Unit.alive(unit) then
			local ok, pos = pcall(Unit.world_position, unit, 1)
			if ok and is_finite_vector(pos) then
				local node = last_node[player]
				local dist, offset, new_node
				if node then
					dist, offset, new_node = project_windowed(mpq, pos, node, TRACK_WINDOW)
				end
				if not dist then
					dist, offset, new_node = project_full(mpq, pos)
				end
				if dist then
					local credited = progress[player]
					-- A nil offset means no usable projected point came back. Credit it rather than
					-- freezing: falling back to the old behaviour beats going blind.
					local on_route = (not offset) or offset <= ON_PATH_MAX_OFFSET
					local continuous = credited and math.abs(dist - credited) <= MAX_STEP
					if on_route or continuous or not credited then
						progress[player] = dist
						last_node[player] = new_node or last_node[player]
					end
				end
			end
		end
	end
end

-- Furthest-ahead living player's progress, the input the game's beacon rule uses.
--
-- Deliberately NOT monotonic: the whole hold-back mechanic depends on this falling again when the
-- team moves back, which is what pulls the respawn to an earlier beacon. Only living players count,
-- matching the game, so a dead player's last progress cannot pin the team to where they fell.
local function ahead_distance()
	local players = Managers.player and Managers.player:players()
	if not players then
		return nil
	end
	local best = nil
	for _, player in pairs(players) do
		local unit = player.player_unit
		if unit and Unit.alive(unit) then
			local value = progress[player]
			if value and (not best or best < value) then
				best = value
			end
		end
	end
	return best
end

-- The nav world the respawn beacon system itself uses, for snapping beacon positions the way it does.
local function nav_world()
	local ext = Managers.state and Managers.state.extension
	local rbs = ext and ext:system("respawn_beacon_system")
	local ok, value = pcall(function()
		return rbs and rbs._nav_world
	end)
	return (ok and value) or nil
end

local NavQueries = nil
local function nav_queries()
	if NavQueries == nil then
		local ok, m = pcall(require, "scripts/utilities/nav_queries")
		NavQueries = ok and m or false
	end
	return NavQueries or nil
end

-- Snap a beacon's world position onto the nav mesh, same as _create_respawn_beacons:
--   target = NavQueries.position_on_mesh_with_outside_position(nav_world, nil, position, 1, 1, 1)
--   distance = main_path_manager:travel_distance_from_position(target)
-- travel_distance_from_position is server-only, but the snap itself isn't -- and the snap is where
-- distances diverged (beacon 1 read 146.1 unsnapped vs. the game's 138.9 or less on one map).
-- Falls back to the raw position when the nav world is unreachable.
local function on_mesh(position)
	local nq = nav_queries()
	local world = nav_world()
	if not nq or not nq.position_on_mesh_with_outside_position or not world or not position then
		return position
	end
	local ok, snapped = pcall(nq.position_on_mesh_with_outside_position, world, nil, position, 1, 1, 1)
	if ok and snapped and is_finite_vector(snapped) then
		return snapped
	end
	return position
end

-- Beacon positions don't move, so the projection is cached per unit for the mission. Offset is how
-- far the beacon's own position sits from its projection -- the tell for an untrustworthy distance.
local function beacon_distance(mpq, unit)
	local cached = distance_cache[unit]
	if cached then
		return cached.distance, cached.offset, cached.snap_delta
	end
	local ok, pos = pcall(Unit.world_position, unit, 1)
	if not ok or not is_finite_vector(pos) then
		return nil, nil
	end
	local snapped = on_mesh(pos)
	local dist, offset = project(mpq, snapped)
	if not dist then
		return nil, nil
	end
	local raw_dist = project(mpq, pos)
	distance_cache[unit] = {
		distance = dist,
		offset = offset,
		snap_delta = (raw_dist and dist) and (dist - raw_dist) or nil,
	}
	return dist, offset
end

-- Every spawn beacon as { unit, position, distance, safe_zone }, ascending by distance. Enumerated
-- from the unit map ExtensionSystemBase populates on every client -- the system's own derived
-- tables (_sorted_beacons etc.) are built behind an is_server gate and are empty here.
--
-- Safe-zone beacons aren't filtered out; the game matches them, not excludes them (safe_zone_spawn()).
local function list_beacons(mpq)
	local ext = Managers.state and Managers.state.extension
	local rbs = ext and ext:system("respawn_beacon_system")
	local unit_map = rbs and rbs._unit_to_extension_map
	if not unit_map then
		return {}
	end
	local out = {}
	for unit, extension in pairs(unit_map) do
		if Unit.alive(unit) then
			local safe_zone = false
			local ok_sz, sz = pcall(function()
				return extension:safe_zone()
			end)
			if ok_sz then
				safe_zone = sz and true or false
			end
			local dist, offset, snap_delta = beacon_distance(mpq, unit)
			local ok_pos, pos = pcall(Unit.world_position, unit, 1)
			if dist and ok_pos and is_finite_vector(pos) then
				out[#out + 1] = { unit = unit, position = pos, distance = dist, offset = offset, snap_delta = snap_delta, safe_zone = safe_zone }
			end
		end
	end
	table.sort(out, function(a, b)
		return a.distance < b.distance
	end)
	return out
end

-- Which safe_zone class the game is currently selecting from (flipped by scripted safe-zone
-- sections). Compared with ==, not excluded, so it's a match not a filter. No is_server gate.
local function safe_zone_spawn()
	local ext = Managers.state and Managers.state.extension
	local rbs = ext and ext:system("respawn_beacon_system")
	local ok, value = pcall(function()
		return rbs and rbs._safe_zone_spawn
	end)
	return (ok and value) and true or false
end

-- "linear" or "open". Readable on a client (plain getter, no gate). Decides which of the game's two
-- selection rules applies: linear measures along the main path, open measures straight-line from the
-- middle of the living squad.
local function path_type()
	local main_path = Managers.state and Managers.state.main_path
	if not main_path or not main_path.path_type then
		return nil
	end
	local ok, value = pcall(main_path.path_type, main_path)
	return ok and value or nil
end

local function matching_beacons(beacons, want_safe_zone)
	local out = {}
	for i = 1, #beacons do
		if beacons[i].safe_zone == want_safe_zone then
			out[#out + 1] = beacons[i]
		end
	end
	return out
end

local function index_of(list, unit)
	for i = 1, #list do
		if list[i].unit == unit then
			return i
		end
	end
	return nil
end

-- Assumed overshoot of our beacon distances vs. the game's, in metres. The game constrains its
-- projection to the nav spawn-point group a position sits in (server-only); our fallback searches
-- the whole path and lands further along -- measured 146.1 vs. a game value of at most 138.9 on one
-- map. Applied to both the selection threshold and the hold-back line, so they always agree.
--
-- Defaults to 0: out of the box this reports what it actually computes. Raise it if the hold-back
-- marker sits past the point that works for you.
local function runback_margin()
	local value = mod:get("runback_margin")
	if type(value) ~= "number" then
		return 0
	end
	return value
end

-- Exposed for the marker layer, which needs to know when a margin change should re-place its
-- position markers (they bake position at add time and can't be moved after).
function Beacons.runback_margin()
	return runback_margin()
end

-- Mirrors _find_nearest_beacon_with_mainpath: first beacon past ahead + 25, else the last one.
local function select_index_with_mainpath(matching, ahead)
	local min_distance = ahead + BEACON_AHEAD_DISTANCE + runback_margin()
	for i = 1, #matching do
		if matching[i].distance > min_distance then
			return i
		end
	end
	return #matching > 0 and #matching or nil
end

-- Mirrors _find_nearest_beacon_with_distance (the non-linear rule): beacon closest to the midpoint
-- of the living squad, straight-line. A beacon of the other safe_zone class is a backup.
local function select_with_distance(beacons, want_safe_zone)
	local players = Managers.player and Managers.player:players()
	if not players then
		return nil
	end
	local sx, sy, sz, count = 0, 0, 0, 0
	for _, player in pairs(players) do
		local unit = player.player_unit
		if unit and Unit.alive(unit) then
			local ok, pos = pcall(Unit.world_position, unit, 1)
			if ok and is_finite_vector(pos) then
				sx, sy, sz = sx + Vector3.x(pos), sy + Vector3.y(pos), sz + Vector3.z(pos)
				count = count + 1
			end
		end
	end
	if count == 0 then
		return nil
	end
	local mx, my, mz = sx / count, sy / count, sz / count

	local best, best_d2
	local backup, backup_d2
	for i = 1, #beacons do
		local b = beacons[i]
		local dx, dy, dz = Vector3.x(b.position) - mx, Vector3.y(b.position) - my, Vector3.z(b.position) - mz
		local d2 = dx * dx + dy * dy + dz * dz
		if b.safe_zone == want_safe_zone then
			if not best_d2 or d2 < best_d2 then
				best, best_d2 = b, d2
			end
		elseif not backup_d2 or d2 < backup_d2 then
			backup, backup_d2 = b, d2
		end
	end
	return best or backup
end

-- Local (or currently observed) player position, for distance labels.
function Beacons.player_position()
	local players = Managers.player
	local player = players and players.local_player and players:local_player(1)
	local unit = player and player.player_unit
	if unit and Unit.alive(unit) then
		local ok, pos = pcall(Unit.world_position, unit, 1)
		if ok and is_finite_vector(pos) then
			return pos
		end
	end
	return nil
end

-- Whether the game is currently holding a latched beacon.
--
-- fixed_update reads `self._priority_respawn_beacon or self._current_active_respawn_beacon` and only
-- calls _find_optimal_beacon when both are nil -- looks like a full-respawn latch, but isn't: later
-- in the same tick, _update_hogtied_players clears _current_active_respawn_beacon once nobody's
-- hogtied. So the hold survives only while someone is hogtied; an ordinary death re-picks every tick
-- from the live ahead-distance, and that live re-pick IS the hold-back mechanic. (1.2.0 latched
-- unconditionally and froze it -- wrong.) Hogtied state reads off the same character_state component
-- as "dead".
--
-- _priority_respawn_beacon itself stays unreachable (make_respawn_beacon_priority is server-gated),
-- so a scripted forced beacon is invisible here and will be mispredicted.
local function anyone_hogtied()
	local players = Managers.player and Managers.player:players()
	if not players then
		return false
	end
	for _, player in pairs(players) do
		local unit = player.player_unit
		if unit and Unit.alive(unit) and ScriptUnit.has_extension(unit, "unit_data_system") then
			local ok_ext, extension = pcall(ScriptUnit.extension, unit, "unit_data_system")
			if ok_ext and extension and extension.read_component then
				local ok_comp, component = pcall(extension.read_component, extension, "character_state")
				if ok_comp and component then
					local ok_name, name = pcall(function()
						return component.state_name
					end)
					if ok_name and name == "hogtied" then
						return true
					end
				end
			end
		end
	end
	return false
end

local latched_unit = nil

-- active = nearest beacon past ahead + 25 (else the furthest). runback = the beacon just before it;
-- its hold-back point is (prev.distance - 25), where the furthest player must stay behind to make
-- prev active instead.
function Beacons.compute()
	local mpq = main_path_queries()
	if not path_registered(mpq) then
		return nil
	end
	local beacons = list_beacons(mpq)
	if #beacons == 0 then
		return nil
	end

	local want_safe_zone = safe_zone_spawn()
	local active, previous
	local team_ahead

	-- Unreadable path_type defaults to linear: the common case, and safer than silently losing the
	-- hold-back marker on every map if this getter drifts.
	local kind = path_type()
	if kind == nil or kind == "linear" then
		local matching = matching_beacons(beacons, want_safe_zone)
		if #matching == 0 then
			return nil -- game logs "No respawn beacon found" and returns nil here too
		end
		-- No living player to project means the game's rule has no input either.
		team_ahead = ahead_distance()
		if not team_ahead then
			return nil
		end
		local hold = anyone_hogtied()
		local index = hold and latched_unit and Unit.alive(latched_unit) and index_of(matching, latched_unit)
		if not index then
			index = select_index_with_mainpath(matching, team_ahead)
			if not index then
				return nil
			end
		end
		active = matching[index]
		previous = matching[index - 1]
	else
		-- Non-linear: euclidean rule, no point on a route to stand behind, so no hold-back marker.
		if anyone_hogtied() and latched_unit and Unit.alive(latched_unit) then
			local index = index_of(beacons, latched_unit)
			active = index and beacons[index]
		end
		active = active or select_with_distance(beacons, want_safe_zone)
	end

	if not active then
		return nil
	end
	latched_unit = active.unit

	local model = { active = { unit = active.unit, position = active.position, distance = active.distance } }

	if previous then
		model.runback_beacon_unit = previous.unit
		model.runback_beacon_position = previous.position

		-- The game projects onto the segment owned by the nav spawn-point group a position sits in
		-- (server-only); our fallback searches the whole path and lands further along -- measured
		-- 146.1 vs. 138.9 on one map. The error only ever overshoots, so the margin only moves the
		-- line back, never forward.
		local want = previous.distance - BEACON_AHEAD_DISTANCE - runback_margin()
		-- Signed: positive = team is past the threshold and must fall back that far; negative = room
		-- left before losing this beacon. Measured against team_ahead, same input the game's rule uses.
		model.runback_line_distance = want
		if team_ahead then
			model.runback_offset = team_ahead - want
		end
		if mpq.position_from_distance and want > 0 then
			local ok, pos = pcall(mpq.position_from_distance, want)
			if ok and is_finite_vector(pos) then
				model.runback_position = pos

				-- No direct tangent accessor, so sample a point 1m further along and take the
				-- difference -- good enough at 1m scale. Fails only right at the end of the path.
				local ok2, pos2 = pcall(mpq.position_from_distance, want + 1)
				if ok2 and is_finite_vector(pos2) then
					local ok_dir, dir = pcall(function()
						return pos2 - pos
					end)
					if ok_dir and is_finite_vector(dir) then
						model.runback_direction = dir
					end
				end
			end
		end
		-- Fallback position: the earlier beacon's own world position, if the path point failed.
		if not model.runback_position then
			model.runback_position = previous.position
		end

		-- Fallback direction: the straight vector between the two beacons. Covers both the "want <= 0"
		-- case (no path point attempted at all) and the end-of-path tangent failure. Won't bend with a
		-- curve like the real tangent, but a line drawn from it beats no line at all.
		if not model.runback_direction then
			local ok_dir, dir = pcall(function()
				return active.position - previous.position
			end)
			if ok_dir and is_finite_vector(dir) then
				model.runback_direction = dir
				model.runback_direction_estimated = true
			end
		end
	end

	return model
end

-- Drops the latched beacon at episode end, mirroring the game clearing
-- _current_active_respawn_beacon. Kept separate from teardown(), which also drops the per-mission
-- distance cache -- expensive to rebuild, and it stays valid across episodes.
function Beacons.end_episode()
	latched_unit = nil
end

-- Every respawn point on the map plus the line that governs it, for the "learn the map" option.
-- Beacon i's line sits at distance_i - 25: cross it going forward and the respawn moves to the next
-- one. Both are returned because a marker on the line alone teaches the wrong spot. Margin-adjusted,
-- same as the live hold-back marker. Static per margin -- rebuilt only when it changes. Positions are
-- frame-temporary Vector3s; callers must not cache them across ticks.
function Beacons.practice_points()
	local mpq = main_path_queries()
	if not path_registered(mpq) or not mpq.position_from_distance then
		return {}
	end
	local want_safe_zone = safe_zone_spawn()
	local beacons = list_beacons(mpq)
	local out = {}
	for i = 1, #beacons do
		local beacon = beacons[i]
		if beacon.safe_zone == want_safe_zone then
			local at = beacon.distance - BEACON_AHEAD_DISTANCE - runback_margin()
			local line_position = nil
			if at > 0 then
				local ok, position = pcall(mpq.position_from_distance, at)
				if ok and is_finite_vector(position) then
					line_position = position
				end
			end
			out[#out + 1] = {
				unit = beacon.unit,
				line_position = line_position,
				line_distance = at,
			}
		end
	end
	return out
end

-- One unconstrained projection of the local player, for timing. This is the call the whole mod is
-- built on: track() runs it once per living player per refresh, and it searches the entire main path.
function Beacons.time_one_projection()
	local mpq = main_path_queries()
	local players = Managers.player
	local player = players and players.local_player and players:local_player(1)
	local unit = player and player.player_unit
	if not mpq or not (unit and Unit.alive(unit)) then
		return false
	end
	local ok, pos = pcall(Unit.world_position, unit, 1)
	if not ok or not is_finite_vector(pos) then
		return false
	end
	project(mpq, pos)
	return true
end

-- The same projection, windowed -- exercises the exact function track() calls every tick, so this
-- benchmark reflects the real per-tick cost rather than a similar-looking stand-in.
function Beacons.time_one_windowed_projection(window)
	local mpq = main_path_queries()
	if not mpq or not mpq.closest_position_between_nodes then
		return false
	end
	local players = Managers.player
	local player = players and players.local_player and players:local_player(1)
	local unit = player and player.player_unit
	if not (unit and Unit.alive(unit)) then
		return false
	end
	local ok, pos = pcall(Unit.world_position, unit, 1)
	if not ok or not is_finite_vector(pos) then
		return false
	end
	local _, _, node = project_full(mpq, pos)
	if type(node) ~= "number" then
		return false
	end
	project_windowed(mpq, pos, node, window)
	return true
end

-- Whether the nav-mesh snap can actually run, reported separately from its result.
--
-- on_mesh() falls back to the unsnapped position when anything is unreachable, which produces a delta
-- of exactly 0.0 and is indistinguishable from a snap that moved nothing. This says which it was.
function Beacons.snap_capability()
	local nq = nav_queries()
	local world = nav_world()
	return {
		module = nq ~= nil,
		has_function = (nq ~= nil) and (nq.position_on_mesh_with_outside_position ~= nil) or false,
		nav_world = world ~= nil,
	}
end

-- Compares where a player actually respawned against the model's prediction, and derives what margin
-- would have made them agree. Can't read the game's beacon distances, so the margin has to be
-- measured rather than calculated: if the game picked a LATER beacon than we did, the smallest margin
-- that would also reject ours is (our_distance - ahead - BEACON_AHEAD_DISTANCE); take the largest such
-- value across several respawns. A game pick EARLIER than ours means the margin's already too big
-- (negative). `position` is where the player reappeared; nearest beacon to it is what the game used.
function Beacons.measure_respawn(position)
	local mpq = main_path_queries()
	if not mpq or not path_registered(mpq) or not position then
		return nil
	end
	local beacons = list_beacons(mpq)
	if #beacons == 0 then
		return nil
	end
	local want_safe_zone = safe_zone_spawn()
	local matching = matching_beacons(beacons, want_safe_zone)
	if #matching == 0 then
		return nil
	end

	local actual_index, best_d2
	for i = 1, #matching do
		local p = matching[i].position
		local dx = Vector3.x(p) - Vector3.x(position)
		local dy = Vector3.y(p) - Vector3.y(position)
		local dz = Vector3.z(p) - Vector3.z(position)
		local d2 = dx * dx + dy * dy + dz * dz
		if not best_d2 or d2 < best_d2 then
			actual_index, best_d2 = i, d2
		end
	end
	if not actual_index then
		return nil
	end

	local ahead = ahead_distance()
	local predicted_index = ahead and select_index_with_mainpath(matching, ahead) or nil

	local implied = nil
	if ahead and predicted_index and predicted_index < actual_index then
		-- Our pick was too early. This is how much margin would have rejected it too.
		implied = matching[predicted_index].distance - ahead - BEACON_AHEAD_DISTANCE
	elseif ahead and predicted_index and predicted_index > actual_index then
		-- We picked later than the game: the margin is already overshooting.
		implied = matching[actual_index].distance - ahead - BEACON_AHEAD_DISTANCE
	end

	return {
		actual = actual_index,
		predicted = predicted_index,
		ahead = ahead,
		margin = runback_margin(),
		implied = implied,
		distance_to_beacon = best_d2 and math.sqrt(best_d2) or nil,
	}
end

-- The current ahead-distance, rounded, for episode logging.
function Beacons.ahead_snapshot()
	local value = ahead_distance()
	if not value then
		return nil
	end
	return math.floor(value * 10 + 0.5) / 10
end

-- Local player's live projection vs. their credited progress. track() only credits within
-- ON_PATH_MAX_OFFSET of the route; if credited is stuck above live_distance while falling back, that
-- hold is why running back isn't doing anything.
function Beacons.local_progress()
	local mpq = main_path_queries()
	local players = Managers.player
	local player = players and players.local_player and players:local_player(1)
	if not mpq or not player then
		return nil
	end
	local unit = player.player_unit
	if not (unit and Unit.alive(unit)) then
		return nil
	end
	local ok, pos = pcall(Unit.world_position, unit, 1)
	if not ok or not is_finite_vector(pos) then
		return nil
	end
	local live_distance, offset = project(mpq, pos)
	return {
		live_distance = live_distance,
		offset = offset,
		credited = progress[player],
		max_offset = ON_PATH_MAX_OFFSET,
	}
end

-- Every beacon with the numbers behind it, so a wrong hold-back line can be traced to a wrong beacon
-- distance rather than guessed at. A large offset means that beacon sits well off the route and its
-- projected distance should not be trusted.
function Beacons.layout()
	local mpq = main_path_queries()
	if not path_registered(mpq) then
		return {}, nil
	end
	return list_beacons(mpq), ahead_distance()
end

-- Why practice_points() returned what it did. Every stage it can fall out of, in order.
function Beacons.practice_debug()
	local mpq = main_path_queries()
	local out = {
		module = mpq ~= nil,
		path_registered = path_registered(mpq),
		has_position_from_distance = (mpq ~= nil) and (mpq.position_from_distance ~= nil) or false,
		total_beacons = 0,
		want_safe_zone = safe_zone_spawn(),
		matching = 0,
		points = 0,
		lines = 0,
	}
	if not out.path_registered then
		return out
	end
	local beacons = list_beacons(mpq)
	out.total_beacons = #beacons
	for i = 1, #beacons do
		if beacons[i].safe_zone == out.want_safe_zone then
			out.matching = out.matching + 1
		end
	end
	local list = Beacons.practice_points()
	out.points = #list
	for i = 1, #list do
		if list[i].line_position then
			out.lines = out.lines + 1
		end
	end
	return out
end

-- Who's setting the ahead-distance. The rule reads the FURTHEST-AHEAD player, so a knocked-down
-- teammate further up the path pins the number in place even though retreating yourself does nothing.
function Beacons.ahead_owner()
	local players = Managers.player and Managers.player:players()
	if not players then
		return nil, nil
	end
	local best, best_player = nil, nil
	for _, player in pairs(players) do
		local unit = player.player_unit
		if unit and Unit.alive(unit) then
			local value = progress[player]
			if value and (not best or best < value) then
				best, best_player = value, player
			end
		end
	end
	if not best_player then
		return nil, nil
	end
	local name = "?"
	local ok, value = pcall(function()
		return best_player:name()
	end)
	if ok and value then
		name = tostring(value)
	end
	local is_local = false
	local players_manager = Managers.player
	local local_player = players_manager and players_manager.local_player and players_manager:local_player(1)
	is_local = (local_player == best_player)
	return name, is_local
end

-- Diagnostic snapshot of everything compute() depends on. 1.0.0's failure mode was total silence
-- (every main-path call nil, mod drew nothing, no log), so this is the cheap way to tell the client
-- path model is actually resolving. Backs the rr_beacons command.
function Beacons.diagnose()
	local mpq = main_path_queries()
	local out = {
		module_loaded = mpq ~= nil,
		path_registered = path_registered(mpq),
		beacon_count = 0,
		ahead = nil,
		active_distance = nil,
		has_runback = false,
		path_type = path_type(),
		safe_zone = safe_zone_spawn(),
		latched = latched_unit ~= nil,
		latch_in_force = anyone_hogtied(),
	}
	if not out.path_registered then
		return out
	end
	local beacons = list_beacons(mpq)
	out.beacon_count = #beacons
	out.ahead = ahead_distance()
	local model = Beacons.compute()
	if model and model.active then
		out.active_distance = nil
		for i = 1, #beacons do
			if beacons[i].unit == model.active.unit then
				out.active_distance = beacons[i].distance
				break
			end
		end
		out.has_runback = model.runback_position ~= nil
		out.has_runback_direction = model.runback_direction ~= nil
		out.runback_direction_estimated = model.runback_direction_estimated == true
	end
	return out
end

function Beacons.teardown()
	distance_cache = {}
	latched_unit = nil
	progress = {}
	last_node = {}
end

return Beacons
