# Respawn Rewind

A client-side Darktide (DMF) mod. While a teammate is dead or awaiting respawn, it marks where they
will respawn and the point on the path to stay behind to pull that respawn to a closer beacon. Reads
only client-available data (respawn beacon units, the main path, player state), so it works in a live
mission — Darktide runs on dedicated servers, so every player is a client except in solo play.

## What it shows (only while a teammate is down/dead)

- **Respawn marker** (light blue, through walls): the beacon where a dead teammate will respawn, with
  distance. Computed from the game's own selection rule, so it's correct in a live mission, not only
  under solo play.
- **Hold-back marker** (green, through walls): the main-path point living players should stay behind
  to pull the respawn to the nearest earlier beacon — shown as a point+label (distance, through walls)
  and a line drawn across the path at that point (up close, exact width). No marker when the active
  beacon is already the earliest one.

## Settings (F4 mod menu)

Enabled, Show run-back point, Safety margin, Map practice (layout / points / lines / numbering),
Marker size, Markers through walls, Show distance on markers, Marker icon.

## How it works

Dead players respawn at a beacon the game picks by main-path distance: the nearest beacon at least 25m
ahead of the furthest-ahead living player. The mod reads the beacon units and main path on the client
and applies the same rule. Holding the party back lowers that furthest-ahead distance, which can pull
the respawn to an earlier beacon — the hold-back marker is the line to stay behind for that.

Three details of the game's rule, all confirmed against `respawn_beacon_system.lua`:

- **The choice is latched, not recomputed.** `fixed_update` reads
  `self._priority_respawn_beacon or self._current_active_respawn_beacon` and only calls
  `_find_optimal_beacon` when both are nil — frozen for the rest of the episode once a respawn
  happens. The mod latches the same way, clearing on its own episode boundary.
- **Two rules, chosen by path type.** `_find_optimal_beacon` branches on `path_type()`. Only
  `"linear"` uses the main-path rule above; anything else uses the beacon closest to the midpoint of
  the living squad, straight-line, with no hold-back marker.
- **Safe-zone beacons are matched, not excluded.** Compared against the system's `_safe_zone_spawn`
  flag, which scripted safe-zone sections flip.

All main-path math goes through `MainPathQueries` (client-safe `EngineOptimized`), not
`MainPathManager` (`ahead_unit`, `travel_distance_from_position`) — those need server-only nav spawn
points and just return nil on a client. The furthest-ahead distance is computed locally by projecting
every living player onto the path and taking the max.

### Known blind spot

`_priority_respawn_beacon` overrides everything when a mission forces a specific beacon, but its
setter is server-gated, so on a client it's always nil. A scripted forced beacon will be mispredicted
with no client-side signal that it happened.

## Notes

- Refresh cadence is ~0.3s for markers and their labels; the drawn hold-back line is re-queued every
  real frame so it doesn't flicker between ticks. Everything clears on rescue/respawn and mission end.
- **Markers always draw through walls — the "Markers through walls" checkbox doesn't turn that off.**
  `template.check_line_of_sight` only makes the HUD queue a raycast; nothing reads the result to hide
  the marker. Left alone in 1.4.0 since the default is the behaviour everyone wants and the fix is
  untested.
- World markers are hidden while the F4 mod menu is open. A settings change lands on the first frame
  after the menu closes, not while it's up.
- No pacing prediction, no full path drawing, no offline cache. Through-wall world markers for the
  long-range signal, plus a real drawn line at the hold-back threshold.
- **Client-side and non-cheat.**

## Changelog

- **Local: perf + cleanup**: `track()` (runs every 0.3s per living player) used to sweep the entire
  main path with an unconstrained `closest_position` call every time — the mod's own `rr_perf`
  flagged this as the actual cost centre. It now caches each player's last known path node and
  searches only a ±40-node window around it via `closest_position_between_nodes`, falling back to a
  full sweep whenever there's no cached node yet (first sample, or the windowed call fails). Same
  offset/continuity guards apply on top, so the objective-room protection is unchanged — just cheaper
  to get there. `rr_perf`'s windowed benchmark now uses the real window size instead of a stale `10`.
  Also a general comment pass across every file: cut the long rationale blocks down to the load-bearing
  facts (numbers, function names, gotchas) without changing any behaviour.
- **Local merge (1.4.0 + line)**: Upstream 1.4.0 dropped the drawn hold-back line, which upstream
  never carried forward from this fork's own 1.3.2. Reintroduced on top of everything upstream added
  in 1.4.0 (live icon/size, margin-aware marker/practice-line keying, the backfilled-bot fix, respawn
  calibration logging). The line's direction also gained a fallback: previously it only drew when
  `position_from_distance` could sample a real tangent, which silently left a bare point marker
  whenever the threshold fell behind the start of the path or right at the end of it. Both cases now
  fall back to the straight vector between the two beacons as an approximate direction —
  won't bend through a curve like the true tangent, but a real line beats no line. `rr_beacons` now
  reports `runback_direction_estimated` so it's visible which kind is showing.
- **1.4.0**: Marker size and the new marker icon setting now reach markers already on screen — both
  used to be baked in at add time, and this template has no `scale_settings` so the base HUD never
  touched them again. Both now travel through `marker.data` and get applied live. Added the icon
  setting (seven choices, all real shipped icon paths) and lowered the size floor from 24 to 8.
  The safety margin is now visible when it changes: the hold-back marker is keyed by the line's
  distance along the path as well as the beacon, with a half-metre tolerance against float flicker.
  Practice lines now carry the same margin and are part of the practice signature. Stopped treating a
  backfilled bot as a dead player — a bot replacing a leaver can exist before its unit spawns, which
  looked identical to a teammate awaiting respawn; awaiting-respawn now requires having seen the
  player alive at least once. Also logs a comparison of predicted vs. actual beacon per respawn;
  twelve samples say a single margin can't fully correct for it since the error is per-beacon
  geometry, not a constant.
- **1.3.2** *(local fork only — upstream never carried this forward)*: The hold-back marker also
  draws as a line across the main path at the threshold, not just a point. Uses the engine's
  `LineObject` debug-line primitive, confirmed against the public Stingray engine reference but,
  unlike the rest of the mod, not against Darktide's own decompiled scripts. Pcall-guarded throughout,
  falls back to no line rather than erroring. Run `rr_line` to check what actually drew.
- **1.3.1**: Stopped wrapping `HudElementWorldMarkers.update` to re-register the marker template —
  that hook ran every frame and a profiler charged the whole base update to this mod (0.7ms/frame vs.
  ~25us of real work). Hooks `_template_by_type` instead, which only runs at marker-add time. Added a
  run-back safety margin setting, defaulted to 0: our beacon distances can't match the game's
  (`nav_spawn_points()` is server-only), measured 146.1 vs. a game value of at most 138.9 on one map.
- **1.3.0**: Added the map-practice layout — every respawn point and the line that governs it, off by
  default. Fixed the run-back point being wrong where the route runs wide: progress was only credited
  within `ON_PATH_MAX_OFFSET` of the route centre, and one map's offset past beacon 1 reads 22m,
  freezing progress at 91.4 while the player walked to 127.0. A projection is now credited if it's
  near the route OR continuous with the last credited value.
- **1.2.1**: Corrected the 1.2.0 latch — `_update_hogtied_players` clears the game's own latch once
  nobody's hogtied, so an ordinary death re-picks every tick and that live re-pick IS the hold-back
  mechanic; 1.2.0 froze it unconditionally. Latch is now conditional on a hogtied player. Hold-back
  marker now reports a signed offset with a switching label ("Run back | 29m" / "Stay behind | -12m").
- **1.2.0**: Matched three parts of the game's beacon rule the mod was missing: the latch, `path_type`
  (linear vs. euclidean selection), and safe-zone beacons matched rather than excluded. `rr_beacons`
  now reports `path_type`, `safe_zone`, `latched`.
- **1.1.1**: Fixed the predicted beacon jumping forward early on maps with a locked objective room —
  projecting onto the nearest path point answers "which bit of the route is closest", not "how far
  have you got", and an objective room off-route breaks that. Progress now only credited when
  demonstrably near the path.
- **1.1.0**: Fixed the mod doing nothing in live missions. 1.0.0 read distances through
  `MainPathManager`, which returns nil on clients; only worked under SoloPlay, which is how it passed
  testing. Switched to the client-safe `MainPathQueries`.
- **1.0.0**: Initial build.

## Credits

The respawn beacon model (beacon fields, the ahead-distance selection rule) was understood by reading
**RitualZones** (Nexus 687, LAUR3HTE). Implementation is original and built on the game's own systems.
If ever published, credit LAUR3HTE, check Nexus permissions, and consider a courtesy note (the same
gate as RitualDangerZones).
