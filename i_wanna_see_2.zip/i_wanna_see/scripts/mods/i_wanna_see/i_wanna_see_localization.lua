return {
	mod_name = {
		en = "I Wanna See",
	},
	mod_description = {
		en = "Remove sources of VFX that block vision",
	},
	remove_purgatus_effect = {
		en = "Remove Inferno Staff Effects"
	},
	remove_flamer_effect = {
		en = "Remove Zealot Flamer Effects"
	},
	flamer_sound_volume = {
		en = "Flame Sound Volume"
	},
	flamer_sound_volume_tooltip = {
		en = "Lowers the flamer/flamestaff loop sound volume (Zealot Flamer and Purgatus Staff), independent of the effect removal toggle above. 100 is unmodified, 0 mutes it. Works by pushing the sound further away since there's no direct volume control for it, so it won't be perfectly linear."
	},
	remove_smite_effect = {
		en = "Remove Smite Lightning Effects"
	},
	remove_electro_effect = {
		en = "Remove Electro Staff Lightning Effects"
	},
	remove_shield_effect = {
		en = "Remove Psyker shield effects"
	},
	remove_shield_sound = {
		en = "Remove Psyker shield sounds"
	},
	display_shield_radius = {
		en = "Display an AoE radius on the floor"
	},
	shield_group = {
		en = "Psyker Shield Settings"
	},
	R = {
		en = "Shield AoE radius (Red)"
	},
	G = {
		en = "Shield AoE radius (Green)"
	},
	B = {
		en = "Shield AoE radius (Blue)"
	},
}
