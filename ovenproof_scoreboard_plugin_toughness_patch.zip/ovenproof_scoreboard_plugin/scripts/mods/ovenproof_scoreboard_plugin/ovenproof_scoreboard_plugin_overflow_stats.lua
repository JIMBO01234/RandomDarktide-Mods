-- Toughness sharing estimate: running totals.
-- Adapted from Overflow Meter's stats module so we don't need that mod installed.
-- Just accumulates whatever sources/pulses feed it, no game knowledge in here.
local Stats = {}

local share_fraction = 0

Stats.generated = 0
Stats.replenished = 0
Stats.overflowed = 0
Stats.shared = 0
Stats.shared_total = 0
Stats.archetype = nil

Stats.reset = function()
	Stats.generated = 0
	Stats.replenished = 0
	Stats.overflowed = 0
	Stats.shared = 0
	Stats.shared_total = 0
end

Stats.set_context = function(archetype, talent_share_fraction)
	share_fraction = talent_share_fraction or 0

	if archetype ~= Stats.archetype then
		Stats.archetype = archetype
		Stats.reset()
	end
end

-- recovered: toughness you personally regained this sample
-- overflowed: toughness that would've been wasted if not for sharing
-- shareable: toughness value on offer to allies this sample (already accounts for is-full gating upstream)
-- allies: how many allies were in coherency to receive a share
Stats.add_event = function(recovered, overflowed, shareable, allies)
	if recovered > 0 then
		Stats.replenished = Stats.replenished + recovered
		Stats.generated = Stats.generated + recovered
	end

	if overflowed > 0 then
		Stats.overflowed = Stats.overflowed + overflowed
		Stats.generated = Stats.generated + overflowed
	end

	if shareable > 0 and allies > 0 then
		local shared = share_fraction * shareable
		Stats.shared = Stats.shared + shared
		Stats.shared_total = Stats.shared_total + shared * allies
	end
end

return Stats
